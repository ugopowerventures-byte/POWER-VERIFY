var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/supabase.ts
function cleanSupabaseUrl(raw) {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
    try {
      const u = new URL(trimmed);
      return `${u.protocol}//${u.host}`;
    } catch {
      return trimmed.replace(/\/rest\/v1\/?$/, "").replace(/\/+$/, "");
    }
  }
  return null;
}
function isValidSupabaseKey(key) {
  if (!key) return false;
  const trimmed = key.trim();
  if (trimmed.length < 20) return false;
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return false;
  if (trimmed.includes("/") || trimmed.includes("\\") || trimmed.includes(" ")) return false;
  if (trimmed.includes("your-anon-public-key") || trimmed.includes("your-service-role-key")) return false;
  return true;
}
function extractServiceRoleKey() {
  const candidates = [
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    process.env.VITE_SUPABASE_URL,
    process.env.SUPABASE_URL
  ];
  for (const c of candidates) {
    if (!c || typeof c !== "string") continue;
    const trimmed = c.trim();
    if (trimmed.split(".").length === 3) {
      try {
        const payload = JSON.parse(Buffer.from(trimmed.split(".")[1], "base64").toString("utf8"));
        if (payload.role === "service_role") {
          return trimmed;
        }
      } catch {
      }
    }
  }
  return null;
}
function extractSupabaseProjectUrl() {
  const directUrl = cleanSupabaseUrl(process.env.SUPABASE_URL) || cleanSupabaseUrl(process.env.VITE_SUPABASE_URL);
  if (directUrl) return directUrl;
  const candidates = [
    process.env.VITE_SUPABASE_URL,
    process.env.VITE_SUPABASE_ANON_KEY,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    process.env.SUPABASE_ANON_KEY
  ];
  for (const c of candidates) {
    if (!c || typeof c !== "string") continue;
    const trimmed = c.trim();
    if (trimmed.split(".").length === 3) {
      try {
        const payload = JSON.parse(Buffer.from(trimmed.split(".")[1], "base64").toString("utf8"));
        if (payload.ref) {
          return `https://${payload.ref}.supabase.co`;
        }
      } catch {
      }
    }
  }
  return defaultUrl;
}
function isSupabaseServiceRoleActive() {
  const key = extractServiceRoleKey();
  return Boolean(key && isValidSupabaseKey(key));
}
async function testSupabaseConnection() {
  const tryTestWithClient = async (client, isServiceRole) => {
    if (!client) return null;
    try {
      const [servicesRes, settingsRes] = await Promise.all([
        client.from("services").select("id, code, name", { count: "exact" }),
        client.from("platform_settings").select("*").limit(1)
      ]);
      if (servicesRes.error) {
        return {
          connected: false,
          url: supabaseUrl,
          servicesCount: 0,
          settingsFound: false,
          isServiceRole,
          error: servicesRes.error.message
        };
      }
      let usersCount = 0;
      try {
        const usersRes = await client.from("users").select("id", { count: "exact", head: true });
        if (!usersRes.error && typeof usersRes.count === "number") {
          usersCount = usersRes.count;
        }
      } catch {
      }
      return {
        connected: true,
        url: supabaseUrl,
        servicesCount: servicesRes.count || (servicesRes.data ? servicesRes.data.length : 0),
        settingsFound: Boolean(settingsRes.data && settingsRes.data.length > 0),
        usersCount,
        isServiceRole
      };
    } catch (err) {
      return {
        connected: false,
        url: supabaseUrl,
        servicesCount: 0,
        settingsFound: false,
        isServiceRole,
        error: err.message || String(err)
      };
    }
  };
  let primaryResult = await tryTestWithClient(supabaseServer, isSupabaseServiceRoleActive());
  if (primaryResult && primaryResult.connected) {
    return primaryResult;
  }
  if (supabaseAnonServer && supabaseAnonServer !== supabaseServer) {
    const anonResult = await tryTestWithClient(supabaseAnonServer, false);
    if (anonResult && anonResult.connected) {
      return anonResult;
    }
  }
  return primaryResult || {
    connected: false,
    url: supabaseUrl,
    servicesCount: 0,
    settingsFound: false,
    isServiceRole: false,
    error: "Supabase client not initialized."
  };
}
function mapUserToSupabaseRow(u) {
  return {
    id: u.id,
    email: (u.email || "").toLowerCase().trim(),
    username: u.username || u.email.split("@")[0],
    full_name: u.fullName || "UGOPAWAVERIFY User",
    phone: u.phone || "+2348000000000",
    phone2: u.phone2 || null,
    password_hash: u.passwordHash || null,
    salt: u.salt || null,
    transaction_pin_hash: u.transactionPinHash || null,
    pin_salt: u.pinSalt || null,
    role: u.role || "USER",
    status: u.status || "ACTIVE",
    avatar_url: u.avatarUrl || null,
    onboarding_status: u.onboardingStatus || (u.role === "MEGA_ADMIN" ? "approved" : "not_started"),
    onboarding_approved_at: u.onboardingApprovedAt || null,
    onboarding_approved_by: u.onboardingApprovedBy || null,
    role_at_approval: u.roleAtApproval || null,
    assigned_services: u.assignedServices || [],
    satisfaction_title: u.satisfactionTitle || "Accredited Operator",
    dob: u.dob || null,
    nin: u.nin || null,
    profile_photo: u.avatarUrl || null,
    certificates: u.certificates || [],
    created_at: u.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapSupabaseRowToUser(row) {
  return {
    id: row.id,
    email: row.email,
    username: row.username,
    fullName: row.full_name,
    phone: row.phone,
    phone2: row.phone2 || void 0,
    passwordHash: row.password_hash || "",
    salt: row.salt || "",
    transactionPinHash: row.transaction_pin_hash || "",
    pinSalt: row.pin_salt || "",
    role: row.role || "USER",
    status: row.status || "ACTIVE",
    avatarUrl: row.avatar_url || row.profile_photo || "",
    onboardingStatus: row.onboarding_status || (row.role === "MEGA_ADMIN" ? "approved" : "not_started"),
    onboardingApprovedAt: row.onboarding_approved_at || void 0,
    onboardingApprovedBy: row.onboarding_approved_by || void 0,
    roleAtApproval: row.role_at_approval || void 0,
    assignedServices: Array.isArray(row.assigned_services) ? row.assigned_services : [],
    satisfactionTitle: row.satisfaction_title || void 0,
    dob: row.dob || void 0,
    nin: row.nin || void 0,
    certificates: Array.isArray(row.certificates) ? row.certificates : [],
    createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: row.updated_at || (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapWalletToSupabaseRow(w) {
  return {
    id: w.id,
    user_id: w.userId,
    available_balance: Number(w.availableBalance || 0),
    pending_balance: Number(w.pendingBalance || 0),
    total_deposited: Number(w.totalDeposited || 0),
    total_spent: Number(w.totalSpent || 0),
    created_at: w.updatedAt || (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapSupabaseRowToWallet(row) {
  return {
    id: row.id,
    userId: row.user_id,
    availableBalance: Number(row.available_balance || 0),
    pendingBalance: Number(row.pending_balance || 0),
    totalDeposited: Number(row.total_deposited || 0),
    totalSpent: Number(row.total_spent || 0),
    updatedAt: row.updated_at || (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapTransactionToSupabaseRow(t) {
  return {
    id: t.id,
    wallet_id: t.walletId,
    user_id: t.userId,
    reference: t.reference,
    type: t.type,
    amount: Number(t.amount || 0),
    fee: Number(t.fee || 0),
    balance_before: Number(t.balanceBefore || 0),
    balance_after: Number(t.balanceAfter || 0),
    status: t.status || "SUCCESS",
    description: t.description || "Transaction",
    metadata: t.metadata || {},
    created_at: t.createdAt || (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapFundingRequestToSupabaseRow(r) {
  let methodEnum = "CARD";
  if (r.method === "BANK_TRANSFER" || r.method === "MANUAL") {
    methodEnum = r.method;
  }
  return {
    id: r.id,
    user_id: r.userId,
    user_name: r.userName,
    user_email: r.userEmail,
    reference: r.reference,
    amount: Number(r.amount || 0),
    method: methodEnum,
    status: r.status || "PENDING",
    receipt_url: r.receiptUrl || null,
    receipt_name: r.receiptName || null,
    admin_note: r.adminNote || null,
    reviewed_by: r.reviewedBy || null,
    reviewed_at: r.reviewedAt || null,
    created_at: r.createdAt || (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function createSupabaseAuthUser(user) {
  if (!supabaseServer) return null;
  try {
    if (supabaseServer.auth && supabaseServer.auth.admin) {
      const { data, error } = await supabaseServer.auth.admin.createUser({
        email: user.email,
        password: user.password || "Temporary@2026!",
        email_confirm: true,
        user_metadata: {
          full_name: user.fullName,
          phone: user.phone,
          role: "USER"
        }
      });
      if (!error && data?.user?.id) {
        return data.user.id;
      }
    }
  } catch {
  }
  return null;
}
function mapServiceRequestToSupabaseRow(s) {
  return {
    id: s.id,
    ticket_id: s.ticketId,
    user_id: s.userId,
    service_code: s.serviceCode,
    service_name: s.serviceName,
    status: s.status || "PENDING",
    form_data: s.submittedData || {},
    result_data: {
      adminResultText: s.adminResultText,
      adminResultFiles: s.adminResultFiles,
      timeline: s.timeline
    },
    created_at: s.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: s.updatedAt || (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function fetchSupabaseUsers() {
  if (!supabaseServer) return null;
  try {
    const { data, error } = await supabaseServer.from("users").select("*").order("created_at", { ascending: false });
    if (!error && Array.isArray(data) && data.length > 0) {
      return data.map(mapSupabaseRowToUser);
    }
  } catch (err) {
    console.warn("[Supabase DB] fetchSupabaseUsers notice:", err.message || err);
  }
  return null;
}
async function fetchSupabaseUserById(userId) {
  const tryFetch = async (client) => {
    if (!client) return null;
    try {
      const { data, error } = await client.from("users").select("*").eq("id", userId).maybeSingle();
      if (!error && data) {
        return mapSupabaseRowToUser(data);
      }
    } catch (err) {
      console.warn("[Supabase DB] fetchSupabaseUserById notice:", err.message || err);
    }
    return null;
  };
  let user = await tryFetch(supabaseServer);
  if (!user && supabaseAnonServer && supabaseAnonServer !== supabaseServer) {
    user = await tryFetch(supabaseAnonServer);
  }
  return user;
}
async function fetchSupabaseUserByIdentifier(identifier) {
  const clean = identifier.trim().toLowerCase();
  const tryFetch = async (client) => {
    if (!client) return null;
    try {
      const { data, error } = await client.from("users").select("*").or(`email.eq.${clean},username.eq.${clean}`).maybeSingle();
      if (!error && data) {
        return mapSupabaseRowToUser(data);
      }
    } catch (err) {
      console.warn("[Supabase DB] fetchSupabaseUserByIdentifier notice:", err.message || err);
    }
    return null;
  };
  let user = await tryFetch(supabaseServer);
  if (!user && supabaseAnonServer && supabaseAnonServer !== supabaseServer) {
    user = await tryFetch(supabaseAnonServer);
  }
  return user;
}
async function saveUserToSupabase(user) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] saveUserToSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured in server environment; record persisted to server authoritative store.");
    return {
      success: true,
      warning: "SUPABASE_SERVICE_ROLE_KEY is not configured. Persisted to server database."
    };
  }
  try {
    const row = mapUserToSupabaseRow(user);
    const { data, error } = await supabaseServer.from("users").upsert(row, { onConflict: "id" }).select("id, email, role, status");
    if (error) {
      console.error("[Supabase DB] saveUserToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      return { success: false, error: `Supabase did not return confirmed record for user ${user.id}.` };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] saveUserToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function updateUserRoleInSupabase(userId, role, onboardingStatus, email) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] updateUserRoleInSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured in server environment; role saved authoritatively in server database.");
    return {
      success: true,
      warning: "SUPABASE_SERVICE_ROLE_KEY is not configured in server environment. Role saved in server database."
    };
  }
  try {
    const updatePayload = {
      role,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (onboardingStatus) {
      updatePayload.onboarding_status = onboardingStatus;
    }
    if (onboardingStatus === "not_started") {
      updatePayload.onboarding_approved_at = null;
      updatePayload.onboarding_approved_by = null;
      updatePayload.role_at_approval = null;
    }
    const { data, error } = await supabaseServer.from("users").update(updatePayload).eq("id", userId).select("id, role, onboarding_status");
    if (error) {
      console.error("[Supabase DB] updateUserRoleInSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      if (email) {
        const emailRes = await supabaseServer.from("users").update(updatePayload).eq("email", email.toLowerCase().trim()).select("id, role, onboarding_status");
        if (emailRes.error) {
          return { success: false, error: emailRes.error.message };
        }
        if (emailRes.data && emailRes.data.length > 0) {
          return { success: true };
        }
      }
      const { data: upsertData, error: upsertErr } = await supabaseServer.from("users").upsert({
        id: userId,
        email: email ? email.toLowerCase().trim() : `${userId}@placeholder.local`,
        ...updatePayload
      }, { onConflict: "id" }).select("id, role, onboarding_status");
      if (!upsertErr && upsertData && upsertData.length > 0) {
        return { success: true };
      }
      return { success: false, error: upsertErr?.message || `User with ID ${userId} was not found or updated in Supabase users table.` };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] updateUserRoleInSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function updateUserStatusInSupabase(userId, status) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] updateUserStatusInSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; updated in server database.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY not configured. Saved in server database." };
  }
  try {
    const { data, error } = await supabaseServer.from("users").update({
      status,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", userId).select("id, status");
    if (error) {
      console.error("[Supabase DB] updateUserStatusInSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      return { success: false, error: `User with ID ${userId} was not found in Supabase.` };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] updateUserStatusInSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function updateUserAvatarInSupabase(userId, avatarUrl) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] updateUserAvatarInSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; updated in server database.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY not configured. Saved in server database." };
  }
  try {
    const { data, error } = await supabaseServer.from("users").update({
      avatar_url: avatarUrl,
      profile_photo: avatarUrl,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", userId).select("id, avatar_url");
    if (error) {
      console.error("[Supabase DB] updateUserAvatarInSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      return { success: false, error: `User with ID ${userId} was not found in Supabase.` };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] updateUserAvatarInSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function updateUserOnboardingInSupabase(userId, onboardingStatus, approvedBy, roleAtApproval, email) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] updateUserOnboardingInSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; updated in server database.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY not configured. Saved in server database." };
  }
  try {
    const updatePayload = {
      onboarding_status: onboardingStatus,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (onboardingStatus === "approved") {
      updatePayload.onboarding_approved_at = (/* @__PURE__ */ new Date()).toISOString();
      if (approvedBy) updatePayload.onboarding_approved_by = approvedBy;
      if (roleAtApproval) updatePayload.role_at_approval = roleAtApproval;
    } else if (onboardingStatus === "not_started" || onboardingStatus === "correction_required" || onboardingStatus === "pending") {
      updatePayload.onboarding_approved_at = null;
      updatePayload.onboarding_approved_by = null;
      updatePayload.role_at_approval = null;
    }
    const { data, error } = await supabaseServer.from("users").update(updatePayload).eq("id", userId).select("id, onboarding_status");
    if (error) {
      console.error("[Supabase DB] updateUserOnboardingInSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      if (email) {
        const emailRes = await supabaseServer.from("users").update(updatePayload).eq("email", email.toLowerCase().trim()).select("id, onboarding_status");
        if (emailRes.error) {
          return { success: false, error: emailRes.error.message };
        }
        if (emailRes.data && emailRes.data.length > 0) {
          return { success: true };
        }
      }
      return { success: false, error: `User with ID ${userId} was not found or updated in Supabase users table.` };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] updateUserOnboardingInSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function deleteUserFromSupabase(userId) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] deleteUserFromSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; deleted from server database.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY not configured. Deleted from server database." };
  }
  try {
    await Promise.allSettled([
      supabaseServer.from("wallets").delete().eq("user_id", userId),
      supabaseServer.from("transactions").delete().eq("user_id", userId),
      supabaseServer.from("funding_requests").delete().eq("user_id", userId),
      supabaseServer.from("service_requests").delete().eq("user_id", userId),
      supabaseServer.from("agent_onboarding").delete().eq("user_id", userId)
    ]);
    const { error } = await supabaseServer.from("users").delete().eq("id", userId);
    if (error) {
      console.error("[Supabase DB] deleteUserFromSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] deleteUserFromSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function fetchSupabaseWalletByUserId(userId) {
  const tryFetch = async (client) => {
    if (!client) return null;
    try {
      const { data, error } = await client.from("wallets").select("*").eq("user_id", userId).maybeSingle();
      if (!error && data) {
        return mapSupabaseRowToWallet(data);
      }
    } catch (err) {
      console.warn("[Supabase DB] fetchSupabaseWalletByUserId notice:", err.message || err);
    }
    return null;
  };
  let wallet = await tryFetch(supabaseServer);
  if (!wallet && supabaseAnonServer && supabaseAnonServer !== supabaseServer) {
    wallet = await tryFetch(supabaseAnonServer);
  }
  return wallet;
}
async function saveWalletToSupabase(wallet) {
  const client = supabaseServer || supabaseAnonServer;
  if (!client) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] saveWalletToSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; wallet persisted to server authoritative store.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY is not configured. Persisted to server database." };
  }
  try {
    const row = mapWalletToSupabaseRow(wallet);
    const { error } = await client.from("wallets").upsert(row, { onConflict: "user_id" });
    if (error) {
      console.error("[Supabase DB] saveWalletToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] saveWalletToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function insertTransactionToSupabase(txn) {
  const client = supabaseServer || supabaseAnonServer;
  if (!client) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] insertTransactionToSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; transaction persisted to server authoritative store.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY is not configured. Persisted to server database." };
  }
  try {
    const row = mapTransactionToSupabaseRow(txn);
    const { error } = await client.from("transactions").upsert(row, { onConflict: "id" });
    if (error) {
      console.error("[Supabase DB] insertTransactionToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] insertTransactionToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function insertFundingRequestToSupabase(req) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    return {
      success: false,
      error: "Privileged database write rejected: SUPABASE_SERVICE_ROLE_KEY is required to record funding requests."
    };
  }
  try {
    const row = mapFundingRequestToSupabaseRow(req);
    const { error } = await supabaseServer.from("funding_requests").upsert(row, { onConflict: "reference" });
    if (error) {
      console.error("[Supabase DB] insertFundingRequestToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] insertFundingRequestToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function updateFundingRequestStatusInSupabase(reference, status, reviewedBy, adminNote) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    return {
      success: false,
      error: "Privileged database write rejected: SUPABASE_SERVICE_ROLE_KEY is required to update funding requests."
    };
  }
  try {
    const { error } = await supabaseServer.from("funding_requests").update({
      status,
      reviewed_by: reviewedBy,
      reviewed_at: (/* @__PURE__ */ new Date()).toISOString(),
      admin_note: adminNote || null
    }).eq("reference", reference);
    if (error) {
      console.error("[Supabase DB] updateFundingRequestStatusInSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] updateFundingRequestStatusInSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function saveServiceRequestToSupabase(req) {
  const client = supabaseServer || supabaseAnonServer;
  if (!client) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] saveServiceRequestToSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; request persisted to server authoritative store.");
    return {
      success: true,
      warning: "SUPABASE_SERVICE_ROLE_KEY is not configured. Persisted to server database."
    };
  }
  try {
    const row = mapServiceRequestToSupabaseRow(req);
    const { error } = await client.from("service_requests").upsert(row, { onConflict: "ticket_id" });
    if (error) {
      console.error("[Supabase DB] saveServiceRequestToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] saveServiceRequestToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function insertAuditLogToSupabase(entry) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    return {
      success: false,
      error: "Privileged database write rejected: SUPABASE_SERVICE_ROLE_KEY is required to record audit logs."
    };
  }
  try {
    const { error } = await supabaseServer.from("audit_logs").insert({
      id: entry.id,
      user_id: entry.userId || null,
      actor_name: entry.actorName,
      actor_role: entry.actorRole,
      action: entry.action,
      details: entry.details || null,
      reference: entry.reference || null,
      ip_address: entry.ipAddress || null,
      timestamp: entry.timestamp
    });
    if (error) {
      console.error("[Supabase DB] insertAuditLogToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] insertAuditLogToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
function mapSupabaseRowToService(row) {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    description: row.description || "",
    price: Number(row.price || 0),
    agentPrice: row.agent_price !== null && row.agent_price !== void 0 ? Number(row.agent_price) : void 0,
    status: row.status || "ACTIVE",
    requiredFields: Array.isArray(row.required_fields) ? row.required_fields : [],
    icon: row.icon || "ShieldCheck",
    category: row.category || "General",
    serviceType: row.service_type || "verification",
    providerMapping: row.provider_mapping || "auto",
    defaultProvider: row.default_provider || void 0,
    displayOrder: typeof row.display_order === "number" ? row.display_order : 99,
    allowedRoles: Array.isArray(row.allowed_roles) ? row.allowed_roles : ["USER", "AGENT", "ADMIN", "SUPER_ADMIN", "MEGA_ADMIN"],
    managedBy: row.managed_by || "ALL_ADMINS",
    createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: row.updated_at || (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapServiceToSupabaseRow(s) {
  return {
    id: s.id,
    code: s.code,
    name: s.name,
    description: s.description || null,
    price: Number(s.price || 0),
    agent_price: s.agentPrice !== void 0 ? Number(s.agentPrice) : null,
    status: s.status || "ACTIVE",
    required_fields: s.requiredFields || [],
    icon: s.icon || "ShieldCheck",
    category: s.category || "General",
    service_type: s.serviceType || "verification",
    provider_mapping: s.providerMapping || "auto",
    default_provider: s.defaultProvider || null,
    display_order: s.displayOrder !== void 0 ? Number(s.displayOrder) : 99,
    allowed_roles: s.allowedRoles || ["USER", "AGENT", "ADMIN", "SUPER_ADMIN", "MEGA_ADMIN"],
    managed_by: s.managedBy || "ALL_ADMINS",
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function fetchSupabaseServices() {
  const tryFetch = async (client) => {
    if (!client) return null;
    try {
      const { data, error } = await client.from("services").select("*").order("display_order", { ascending: true });
      if (!error && Array.isArray(data) && data.length > 0) {
        return data.map(mapSupabaseRowToService);
      }
      if (error) {
        console.warn("[Supabase DB] fetchSupabaseServices error with client:", error.message);
      }
    } catch (err) {
      console.warn("[Supabase DB] fetchSupabaseServices exception:", err.message || err);
    }
    return null;
  };
  let res = await tryFetch(supabaseServer);
  if (!res && supabaseAnonServer && supabaseAnonServer !== supabaseServer) {
    res = await tryFetch(supabaseAnonServer);
  }
  return res;
}
async function fetchSupabaseServiceByCodeOrId(identifier) {
  const tryFetch = async (client) => {
    if (!client) return null;
    const term = identifier.trim();
    const upper = term.toUpperCase();
    try {
      const { data, error } = await client.from("services").select("*").or(`id.eq.${term},code.eq.${upper}`).maybeSingle();
      if (!error && data) {
        return mapSupabaseRowToService(data);
      }
      if (error) {
        console.warn("[Supabase DB] fetchSupabaseServiceByCodeOrId error:", error.message);
      }
    } catch (err) {
      console.warn("[Supabase DB] fetchSupabaseServiceByCodeOrId exception:", err.message || err);
    }
    return null;
  };
  let res = await tryFetch(supabaseServer);
  if (!res && supabaseAnonServer && supabaseAnonServer !== supabaseServer) {
    res = await tryFetch(supabaseAnonServer);
  }
  return res;
}
async function updateServiceInSupabase(serviceIdOrCode, updates) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] updateServiceInSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; service updated in server authoritative database.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY is not configured. Persisted to server database." };
  }
  try {
    const updatePayload = {
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (updates.name !== void 0) updatePayload.name = String(updates.name).trim();
    if (updates.description !== void 0) updatePayload.description = String(updates.description).trim();
    if (updates.price !== void 0) updatePayload.price = Number(updates.price);
    if (updates.agentPrice !== void 0) updatePayload.agent_price = Number(updates.agentPrice);
    if (updates.status !== void 0) updatePayload.status = updates.status;
    if (updates.category !== void 0) updatePayload.category = String(updates.category).trim();
    if (updates.icon !== void 0) updatePayload.icon = updates.icon;
    if (updates.displayOrder !== void 0) updatePayload.display_order = Number(updates.displayOrder);
    if (updates.providerMapping !== void 0) updatePayload.provider_mapping = updates.providerMapping;
    if (updates.defaultProvider !== void 0) updatePayload.default_provider = updates.defaultProvider;
    if (updates.requiredFields !== void 0) updatePayload.required_fields = updates.requiredFields;
    const term = serviceIdOrCode.trim();
    const upper = term.toUpperCase();
    const { data, error } = await supabaseServer.from("services").update(updatePayload).or(`id.eq.${term},code.eq.${upper}`).select("*");
    if (error) {
      console.error("[Supabase DB] updateServiceInSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      return {
        success: false,
        error: `Service '${serviceIdOrCode}' could not be updated in Supabase (0 rows modified). Verify database permissions and identifier.`
      };
    }
    const updatedService = mapSupabaseRowToService(data[0]);
    return { success: true, service: updatedService };
  } catch (err) {
    console.error("[Supabase DB] updateServiceInSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function saveServiceToSupabase(service) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] saveServiceToSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; service persisted to server authoritative store.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY is not configured. Persisted to server database." };
  }
  try {
    const row = mapServiceToSupabaseRow(service);
    const { data, error } = await supabaseServer.from("services").upsert(row, { onConflict: "id" }).select("*");
    if (error) {
      console.error("[Supabase DB] saveServiceToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    if (!data || data.length === 0) {
      return { success: false, error: `Supabase did not return confirmed record for service ${service.code}.` };
    }
    return { success: true, service: mapSupabaseRowToService(data[0]) };
  } catch (err) {
    console.error("[Supabase DB] saveServiceToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function deleteServiceFromSupabase(serviceIdOrCode) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase server client not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    return {
      success: false,
      error: "Privileged database write rejected: SUPABASE_SERVICE_ROLE_KEY is required to delete services."
    };
  }
  try {
    const term = serviceIdOrCode.trim();
    const upper = term.toUpperCase();
    const { error } = await supabaseServer.from("services").delete().or(`id.eq.${term},code.eq.${upper}`);
    if (error) {
      console.error("[Supabase DB] deleteServiceFromSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] deleteServiceFromSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
function mapAgentOnboardingToSupabaseRow(app) {
  return {
    id: app.id,
    user_id: app.userId,
    user_email: app.userEmail,
    user_full_name: app.userFullName,
    target_role: app.targetRole,
    full_name: app.fullName,
    dob: app.dob || null,
    phone1: app.phone1,
    phone2: app.phone2 || null,
    profile_photo: app.profilePhoto,
    nin: app.nin,
    certificates: app.certificates || [],
    satisfaction_title: app.satisfactionTitle || "Accredited Operator",
    nin_verified: Boolean(app.ninVerified),
    nin_verified_at: app.ninVerifiedAt || null,
    nin_result_data: app.ninResultData || {},
    nin_photo_url: app.ninPhotoUrl || null,
    nin_full_name: app.ninFullName || null,
    nin_dob: app.ninDob || null,
    nin_comparison_match: Boolean(app.ninComparisonMatch),
    name_match: Boolean(app.nameMatch),
    dob_match: Boolean(app.dobMatch),
    verification_message: app.verificationMessage || null,
    status: app.status || "pending",
    rejection_reason: app.rejectionReason || null,
    correction_requested: Boolean(app.correctionRequested),
    correction_message: app.correctionMessage || null,
    submitted_at: app.submittedAt || (/* @__PURE__ */ new Date()).toISOString(),
    reviewed_at: app.reviewedAt || null,
    reviewed_by: app.reviewedBy || null,
    reviewed_by_name: app.reviewedByName || null,
    reviewed_by_role: app.reviewedByRole || null,
    role_at_approval: app.roleAtApproval || null,
    created_at: app.submittedAt || (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function mapSupabaseRowToAgentOnboarding(row) {
  return {
    id: row.id,
    userId: row.user_id,
    userEmail: row.user_email,
    userFullName: row.user_full_name,
    targetRole: row.target_role || "AGENT",
    fullName: row.full_name,
    dob: row.dob || "",
    phone1: row.phone1,
    phone2: row.phone2 || void 0,
    profilePhoto: row.profile_photo || "",
    nin: row.nin,
    certificates: Array.isArray(row.certificates) ? row.certificates : [],
    satisfactionTitle: row.satisfaction_title || "Accredited Operator",
    ninVerified: Boolean(row.nin_verified),
    ninVerifiedAt: row.nin_verified_at || void 0,
    ninResultData: row.nin_result_data || {},
    ninPhotoUrl: row.nin_photo_url || void 0,
    ninFullName: row.nin_full_name || void 0,
    ninDob: row.nin_dob || void 0,
    ninComparisonMatch: Boolean(row.nin_comparison_match),
    nameMatch: Boolean(row.name_match),
    dobMatch: Boolean(row.dob_match),
    verificationMessage: row.verification_message || void 0,
    status: row.status || "pending",
    rejectionReason: row.rejection_reason || void 0,
    correctionRequested: Boolean(row.correction_requested),
    correctionMessage: row.correction_message || void 0,
    submittedAt: row.submitted_at || row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
    reviewedAt: row.reviewed_at || void 0,
    reviewedBy: row.reviewed_by || void 0,
    reviewedByName: row.reviewed_by_name || void 0,
    reviewedByRole: row.reviewed_by_role || void 0,
    roleAtApproval: row.role_at_approval || void 0
  };
}
async function saveOnboardingApplicationToSupabase(app) {
  if (!supabaseServer) return { success: false, error: "Supabase client not initialized." };
  if (!isSupabaseServiceRoleActive()) {
    console.warn("[Supabase DB] saveOnboardingApplicationToSupabase notice: SUPABASE_SERVICE_ROLE_KEY is not configured; application saved to server database.");
    return { success: true, warning: "SUPABASE_SERVICE_ROLE_KEY not configured. Saved in server database." };
  }
  try {
    const row = mapAgentOnboardingToSupabaseRow(app);
    const { error } = await supabaseServer.from("agent_onboarding").upsert(row, { onConflict: "id" });
    if (error) {
      console.error("[Supabase DB] saveOnboardingApplicationToSupabase error:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.error("[Supabase DB] saveOnboardingApplicationToSupabase exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function fetchSupabaseOnboardingApplications() {
  if (!supabaseServer) return null;
  try {
    const { data, error } = await supabaseServer.from("agent_onboarding").select("*").order("submitted_at", { ascending: false });
    if (!error && Array.isArray(data) && data.length > 0) {
      return data.map(mapSupabaseRowToAgentOnboarding);
    }
  } catch (err) {
    console.warn("[Supabase DB] fetchSupabaseOnboardingApplications notice:", err.message || err);
  }
  return null;
}
async function uploadAvatarToSupabaseStorage(userId, fileName, buffer, contentType) {
  if (!supabaseServer) {
    return { success: false, error: "Supabase client is not initialized." };
  }
  if (!isSupabaseServiceRoleActive()) {
    return {
      success: false,
      error: "Privileged storage write rejected: SUPABASE_SERVICE_ROLE_KEY is required on the server to upload photos to Supabase Storage."
    };
  }
  try {
    const filePath = `avatars/${userId}/${fileName}`;
    const { error } = await supabaseServer.storage.from("avatars").upload(filePath, buffer, {
      contentType,
      upsert: true
    });
    if (error) {
      console.error("[Supabase Storage] upload error:", error.message);
      return { success: false, error: error.message };
    }
    const { data: publicUrlData } = supabaseServer.storage.from("avatars").getPublicUrl(filePath);
    if (!publicUrlData?.publicUrl) {
      return { success: false, error: "Failed to retrieve public URL from Supabase storage." };
    }
    return { success: true, url: publicUrlData.publicUrl };
  } catch (err) {
    console.error("[Supabase Storage] upload exception:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
async function ensureUserInSupabase(user) {
  await saveUserToSupabase(user);
}
async function syncWalletToSupabase(wallet) {
  await saveWalletToSupabase(wallet);
}
var import_supabase_js, defaultUrl, defaultAnonKey, supabaseUrl, rawAnonKey, effectiveServiceKey, effectiveAnonKey, supabaseKey, supabaseServer, supabaseAnonServer;
var init_supabase = __esm({
  "server/supabase.ts"() {
    import_supabase_js = require("@supabase/supabase-js");
    defaultUrl = "https://yhwtkowbvbhfmskyxtju.supabase.co";
    defaultAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlod3Rrb3didmJoZm1za3l4dGp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAxOTgwNjcsImV4cCI6MjEwNTc3NDA2N30.81ncPny9dbX5o_IO76daPt0TymIMCuVLbl60hHP7hNo";
    supabaseUrl = extractSupabaseProjectUrl();
    rawAnonKey = (process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY)?.trim();
    effectiveServiceKey = extractServiceRoleKey();
    effectiveAnonKey = rawAnonKey && isValidSupabaseKey(rawAnonKey) ? rawAnonKey : defaultAnonKey;
    supabaseKey = effectiveServiceKey || effectiveAnonKey;
    supabaseServer = null;
    supabaseAnonServer = null;
    if (supabaseUrl && supabaseKey) {
      try {
        supabaseServer = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey, {
          auth: {
            persistSession: false,
            autoRefreshToken: false
          }
        });
      } catch (err) {
        console.warn("Failed to initialize server Supabase client:", err);
      }
    }
    if (supabaseUrl && effectiveAnonKey) {
      try {
        supabaseAnonServer = (0, import_supabase_js.createClient)(supabaseUrl, effectiveAnonKey, {
          auth: {
            persistSession: false,
            autoRefreshToken: false
          }
        });
      } catch (err) {
        console.warn("Failed to initialize server Supabase anon client:", err);
      }
    }
  }
});

// server/db.ts
var db_exports = {};
__export(db_exports, {
  acquireLock: () => acquireLock,
  defaultCatalogueServices: () => defaultCatalogueServices,
  defaultEnrollmentCenters: () => defaultEnrollmentCenters,
  ensureAllServices: () => ensureAllServices,
  ensureDefaultProviders: () => ensureDefaultProviders,
  ensureOwnerExists: () => ensureOwnerExists,
  generateServiceTicketId: () => generateServiceTicketId,
  getDb: () => getDb,
  hashPassword: () => hashPassword,
  hashPin: () => hashPin,
  initDb: () => initDb,
  logAudit: () => logAudit,
  releaseLock: () => releaseLock,
  saveDb: () => saveDb,
  saveDbSync: () => saveDbSync,
  syncAuthoritativeDataFromSupabase: () => syncAuthoritativeDataFromSupabase,
  verifyPassword: () => verifyPassword,
  verifyPin: () => verifyPin
});
function hashPassword(password, salt) {
  const actualSalt = salt || import_crypto.default.randomBytes(16).toString("hex");
  const hash = import_crypto.default.pbkdf2Sync(password, actualSalt, 1e3, 64, "sha512").toString("hex");
  return { hash, salt: actualSalt };
}
function verifyPassword(password, hash, salt) {
  const cleanPass = String(password || "").trim();
  if (!cleanPass || !hash || !salt) return false;
  const check = import_crypto.default.pbkdf2Sync(cleanPass, salt, 1e3, 64, "sha512").toString("hex");
  return check === hash;
}
function hashPin(pin, salt) {
  const actualSalt = salt || import_crypto.default.randomBytes(8).toString("hex");
  const hash = import_crypto.default.pbkdf2Sync(pin, actualSalt, 1e3, 32, "sha256").toString("hex");
  return { hash, salt: actualSalt };
}
function verifyPin(pin, hash, salt) {
  const cleanPin = String(pin || "").trim();
  if (!cleanPin || !hash || !salt) return false;
  const check = import_crypto.default.pbkdf2Sync(cleanPin, salt, 1e3, 32, "sha256").toString("hex");
  return check === hash;
}
function acquireLock(key) {
  if (processingLocks.has(key)) {
    return false;
  }
  processingLocks.add(key);
  return true;
}
function releaseLock(key) {
  processingLocks.delete(key);
}
function ensureOwnerExists(db) {
  const ownerEmail = "ugochukwuoparaocha3@gmail.com";
  const megaAdminUsername = "/Mega//admin/ugopawaverify";
  const megaAdminPassword = (process.env.INITIAL_OWNER_PASSWORD || process.env.MEGA_ADMIN_PASSWORD || "Ugo@536992").trim();
  let owner = db.users.find(
    (u) => u.email && u.email.toLowerCase() === ownerEmail || u.username === megaAdminUsername || u.username?.toLowerCase() === "/mega//admin/ugopawaverify" || u.username?.toLowerCase() === "/mega/admin/ugopawaverify" || u.role === "MEGA_ADMIN"
  );
  for (const u of db.users) {
    if (owner && u.id !== owner.id && u.role === "MEGA_ADMIN") {
      u.role = "SUPER_ADMIN";
      u.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    }
  }
  const salt = owner?.salt || import_crypto.default.randomBytes(16).toString("hex");
  const { hash } = hashPassword(megaAdminPassword, salt);
  if (!owner) {
    owner = {
      id: "usr_owner_001",
      email: ownerEmail,
      username: megaAdminUsername,
      fullName: "UGOPAWAVERIFY Mega Admin",
      phone: "+2348030009988",
      passwordHash: hash,
      salt,
      transactionPinHash: "",
      pinSalt: "",
      role: "MEGA_ADMIN",
      status: "ACTIVE",
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
      onboardingStatus: "approved",
      onboardingApprovedAt: (/* @__PURE__ */ new Date()).toISOString(),
      onboardingApprovedBy: "SYSTEM OWNER / FOUNDER",
      roleAtApproval: "MEGA_ADMIN",
      assignedServices: ["ONLINE_NIN_REGISTRATION"],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.users.unshift(owner);
  } else {
    owner.id = owner.id || "usr_owner_001";
    owner.email = ownerEmail;
    owner.username = megaAdminUsername;
    owner.fullName = owner.fullName || "UGOPAWAVERIFY Mega Admin";
    owner.role = "MEGA_ADMIN";
    owner.status = "ACTIVE";
    owner.onboardingStatus = "approved";
    owner.passwordHash = hash;
    owner.salt = salt;
    if (!owner.onboardingApprovedAt) owner.onboardingApprovedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (!owner.onboardingApprovedBy) owner.onboardingApprovedBy = "SYSTEM OWNER / FOUNDER";
    owner.roleAtApproval = "MEGA_ADMIN";
    if (!owner.assignedServices || owner.assignedServices.length === 0) {
      owner.assignedServices = ["ONLINE_NIN_REGISTRATION"];
    }
    if (!owner.avatarUrl) {
      owner.avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80";
    }
    owner.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  }
  let ownerWallet = db.wallets.find((w) => w.userId === owner.id);
  if (!ownerWallet) {
    ownerWallet = {
      id: "wal_owner_001",
      userId: owner.id,
      availableBalance: 1e6,
      pendingBalance: 0,
      totalDeposited: 1e6,
      totalSpent: 0,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.wallets.unshift(ownerWallet);
  }
}
function ensureDefaultProviders(db) {
  if (!db.providers) {
    db.providers = [];
  }
  const ninjaApiKey = (process.env.NINJA_PUBLIC_KEY || "").trim();
  const ninjaSecretKey = (process.env.NINJA_SECRET_KEY || "").trim();
  const ninjaBaseUrl = process.env.NINJA_BASE_URL && process.env.NINJA_BASE_URL.startsWith("http") ? process.env.NINJA_BASE_URL.replace(/\/$/, "") : "https://api.ninja.boucloud.io";
  let ninjaProv = db.providers.find((p) => p.slug === "ninja");
  if (!ninjaProv) {
    ninjaProv = {
      id: "prov_ninja_01",
      name: "Ninja API (NIN & BVN Gateway)",
      slug: "ninja",
      baseUrl: ninjaBaseUrl,
      apiKey: "",
      secretKey: "",
      status: ninjaApiKey || ninjaSecretKey ? "CONNECTED" : "NOT_CONFIGURED",
      isDevelopmentMode: false,
      notes: "Dedicated provider for NIN Verification, BVN Verification, Driving Licence, and BVN by CRM."
    };
    db.providers.push(ninjaProv);
  } else {
    ninjaProv.baseUrl = ninjaBaseUrl;
    ninjaProv.apiKey = "";
    ninjaProv.secretKey = "";
    ninjaProv.isDevelopmentMode = false;
    ninjaProv.status = ninjaApiKey || ninjaSecretKey ? "CONNECTED" : "NOT_CONFIGURED";
  }
  db.providers = db.providers.filter((p) => p.slug !== "hk" && p.id !== "prov_hk_01" && p.slug !== "identitypass" && p.id !== "prov_prembly_01");
  const safeVeripineBaseUrl = process.env.VERIPINE_BASE_URL && process.env.VERIPINE_BASE_URL.startsWith("http") ? process.env.VERIPINE_BASE_URL.replace(/\/$/, "") : "https://veripine.com/api";
  const veripineKey = (process.env.VERIPINE_SECRET_KEY || process.env.VERIPINE_API_KEY || "").trim();
  let veripineProv = db.providers.find((p) => p.slug === "veripine");
  if (!veripineProv) {
    veripineProv = {
      id: "prov_veripine_01",
      name: "Veripine API Gateway",
      slug: "veripine",
      baseUrl: safeVeripineBaseUrl,
      apiKey: "",
      secretKey: "",
      status: veripineKey ? "CONNECTED" : "NOT_CONFIGURED",
      isDevelopmentMode: false,
      notes: "Dedicated provider for NIN & BVN Verification, NIN Phone Search, BVN Retrieval with Phone, Personalization Tracking, Demographic Verification, and NIN Modifications."
    };
    db.providers.push(veripineProv);
  } else {
    veripineProv.apiKey = "";
    veripineProv.secretKey = "";
    if (!veripineProv.baseUrl) {
      veripineProv.baseUrl = safeVeripineBaseUrl;
    }
    veripineProv.isDevelopmentMode = false;
    veripineProv.status = veripineKey ? "CONNECTED" : "NOT_CONFIGURED";
  }
  const paystackSecretKey = (process.env.PAYSTACK_SECRET_KEY || process.env.PAYSTACK_LIVE_SECRET_KEY || process.env.PAYSTACK_SECRET || process.env.PAYSTACK_KEY || "").trim();
  const paystackPublicKey = (process.env.VITE_PAYSTACK_PUBLIC_KEY || process.env.PAYSTACK_PUBLIC_KEY || process.env.VITE_PAYSTACK_LIVE_PUBLIC_KEY || "").trim();
  let paystackProv = db.providers.find((p) => p.slug === "paystack");
  if (!paystackProv) {
    paystackProv = {
      id: "prov_paystack_01",
      name: "Paystack Live Gateway",
      slug: "paystack",
      baseUrl: "https://api.paystack.co",
      apiKey: paystackPublicKey,
      secretKey: paystackSecretKey,
      status: paystackSecretKey ? "CONNECTED" : "NOT_CONFIGURED",
      isDevelopmentMode: false,
      notes: "Official live payment gateway for customer wallet card & bank account funding."
    };
    db.providers.push(paystackProv);
  } else {
    if (paystackSecretKey) paystackProv.secretKey = paystackSecretKey;
    if (paystackPublicKey) paystackProv.apiKey = paystackPublicKey;
    if (!paystackProv.baseUrl) paystackProv.baseUrl = "https://api.paystack.co";
    paystackProv.isDevelopmentMode = false;
    paystackProv.status = paystackProv.secretKey || paystackSecretKey ? "CONNECTED" : "NOT_CONFIGURED";
  }
}
function ensureAllServices(db) {
  if (!db.services) {
    db.services = [];
  }
  db.services = db.services.filter((s) => s.code !== "MODIFICATION");
  if (!db.bvnEnrollmentCenters || db.bvnEnrollmentCenters.length === 0) {
    db.bvnEnrollmentCenters = [...defaultEnrollmentCenters];
  }
  for (const defService of defaultCatalogueServices) {
    const existing = db.services.find((s) => s.code.toUpperCase() === defService.code.toUpperCase());
    if (!existing) {
      db.services.push({
        ...defService,
        agentPrice: defService.agentPrice || Math.round(defService.price * 0.75 * 100) / 100
      });
    } else {
      if (existing.agentPrice === void 0) {
        existing.agentPrice = defService.agentPrice || Math.round(existing.price * 0.75 * 100) / 100;
      }
      if (defService.managedBy) existing.managedBy = defService.managedBy;
      if (defService.allowedRoles) existing.allowedRoles = defService.allowedRoles;
      if (existing.displayOrder === void 0 || existing.displayOrder === 0 || !existing.displayOrder) {
        existing.displayOrder = defService.displayOrder;
      }
      if (!existing.providerMapping) {
        existing.providerMapping = defService.providerMapping;
      }
      if (!existing.category) {
        existing.category = defService.category;
      }
      if (!existing.serviceType) {
        existing.serviceType = defService.serviceType;
      }
      if (!existing.requiredFields || existing.requiredFields.length === 0) {
        existing.requiredFields = defService.requiredFields;
      }
      if (!existing.defaultProvider) {
        existing.defaultProvider = "default";
      }
    }
  }
  db.services.sort((a, b) => (a.displayOrder ?? 99) - (b.displayOrder ?? 99));
}
function getInitialData() {
  const defaultServices = [
    {
      id: "srv_nin_01",
      code: "NIN",
      name: "NIN Verification",
      description: "Verify National Identity Number directly via official biometric identity registry database.",
      price: 1e3,
      status: "ACTIVE",
      icon: "UserCheck",
      category: "Identity",
      providerMapping: "nin_verify",
      requiredFields: [
        {
          name: "nin",
          label: "National Identity Number (NIN)",
          type: "text",
          placeholder: "Enter 11-digit NIN",
          required: true,
          regex: "^\\d{11}$",
          helperText: "Must be exactly 11 numeric digits"
        }
      ],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "srv_bvn_02",
      code: "BVN",
      name: "BVN Verification",
      description: "Instant Bank Verification Number check and KYC identity validation.",
      price: 1200,
      status: "ACTIVE",
      icon: "CreditCard",
      category: "Banking",
      providerMapping: "bvn_verify",
      requiredFields: [
        {
          name: "bvn",
          label: "Bank Verification Number (BVN)",
          type: "text",
          placeholder: "Enter 11-digit BVN",
          required: true,
          regex: "^\\d{11}$",
          helperText: "Must be exactly 11 numeric digits"
        }
      ],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "srv_phone_03",
      code: "PHONE",
      name: "Phone Number Verification",
      description: "Validate registered subscriber information, SIM binding and carrier status.",
      price: 500,
      status: "ACTIVE",
      icon: "PhoneCall",
      category: "Telecom",
      providerMapping: "phone_verify",
      requiredFields: [
        {
          name: "phone",
          label: "Phone Number",
          type: "text",
          placeholder: "e.g. 08012345678 or 2348012345678",
          required: true,
          regex: "^(0|234)[789][01]\\d{8}$",
          helperText: "Nigerian mobile telephone number"
        }
      ],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "srv_nin_val_04",
      code: "NIN_VALIDATION",
      name: "NIN Validation & Status Lookup",
      description: "Comprehensive National Identity register check with full slip verification breakdown.",
      price: 1500,
      status: "ACTIVE",
      icon: "ShieldCheck",
      category: "Identity",
      providerMapping: "nin_validation",
      requiredFields: [
        {
          name: "nin",
          label: "National Identity Number (NIN)",
          type: "text",
          placeholder: "Enter 11-digit NIN",
          required: true,
          regex: "^\\d{11}$"
        },
        {
          name: "trackingId",
          label: "Tracking ID / Slip No. (Optional)",
          type: "text",
          placeholder: "Enter tracking reference if available",
          required: false
        }
      ],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "srv_id_lookup_05",
      code: "IDENTITY_LOOKUP",
      name: "Identity Cross Lookup",
      description: "Unified demographic search against certified governmental registry nodes.",
      price: 800,
      status: "ACTIVE",
      icon: "Search",
      category: "Cross-Match",
      providerMapping: "identity_lookup",
      defaultProvider: "veripine",
      requiredFields: [
        {
          name: "searchQuery",
          label: "Search Query (NIN, Phone or Document ID)",
          type: "text",
          placeholder: "Enter identifier",
          required: true
        }
      ],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "srv_drivers_06",
      code: "DRIVERS_LICENSE",
      name: "Drivers License Verification",
      description: "FRSC Drivers License authenticity check and driver particulars match.",
      price: 1800,
      status: "ACTIVE",
      icon: "FileBadge",
      category: "Licensing",
      providerMapping: "frsc_license",
      requiredFields: [
        {
          name: "licenseNumber",
          label: "License Number",
          type: "text",
          placeholder: "e.g. ABC12345AA",
          required: true
        },
        {
          name: "dob",
          label: "Date of Birth (YYYY-MM-DD)",
          type: "text",
          placeholder: "1990-05-15",
          required: true
        }
      ],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  ];
  return {
    users: [],
    profiles: [],
    wallets: [],
    transactions: [],
    fundingRequests: [],
    services: defaultServices,
    verificationRequests: [],
    verificationResults: [],
    providers: [
      {
        id: "prov_ninja_01",
        name: "Ninja API (NIN & BVN Gateway)",
        slug: "ninja",
        baseUrl: "https://api.ninja.boucloud.io",
        apiKey: "",
        secretKey: "",
        status: "CONNECTED",
        isDevelopmentMode: false,
        balance: 0,
        notes: "Dedicated provider for NIN Verification, BVN Verification, Driving Licence, and BVN by CRM."
      },
      {
        id: "prov_veripine_01",
        name: "Veripine API Gateway",
        slug: "veripine",
        baseUrl: "https://veripine.com/api",
        apiKey: "",
        secretKey: "",
        status: "CONNECTED",
        isDevelopmentMode: false,
        balance: 65.4,
        notes: "Dedicated provider for Identity Cross Lookup, NIN Phone Search, BVN Retrieval with Phone, Personalization Tracking, Demographic Verification, and NIN Modifications."
      }
    ],
    announcements: [
      {
        id: "ann_01",
        title: "Welcome to UGOPAWAVERIFY Enterprise Portal",
        message: "All verification queries are cryptographically encrypted. Always ensure your wallet is pre-funded before submitting bulk or individual requests.",
        type: "INFORMATION",
        isActive: true,
        startDate: (/* @__PURE__ */ new Date()).toISOString(),
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    ],
    notifications: [],
    supportTickets: [],
    serviceRequests: [],
    auditLogs: [],
    settings: {
      id: "settings_main",
      platformName: "UGOPAWAVERIFY",
      logoText: "UGOPAWAVERIFY",
      tagline: "Fast, Secure & Reliable Identity Verification Platform",
      supportWhatsapp: process.env.SUPPORT_WHATSAPP || "07071944789",
      supportEmail: process.env.SUPPORT_EMAIL || "contact@ugopawaverify.com.ng",
      whatsappNumber: "07071944789",
      phoneNumber1: "07071944789",
      phoneNumber2: "07018486189",
      businessEmail: "contact@ugopawaverify.com.ng",
      unitValueNgn: 200,
      currency: "Credits",
      currencySymbol: "Credits",
      transactionPinLength: 4,
      minWalletFunding: 1e3,
      maxWalletFunding: 1e6,
      maintenanceMode: false,
      allowManualFunding: true,
      allowCardFunding: true,
      bankDetails: {
        bankName: "Moniepoint Microfinance Bank",
        accountNumber: "8249103821",
        accountName: "UGOPAWA VERIFY SERVICES LTD"
      },
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
}
function initDb() {
  if (!import_fs.default.existsSync(DATA_DIR)) {
    import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (import_fs.default.existsSync(DB_FILE)) {
    try {
      const raw = import_fs.default.readFileSync(DB_FILE, "utf-8");
      dbCache = JSON.parse(raw);
    } catch (err) {
      console.error("Error reading db.json, generating fresh schema:", err);
      dbCache = getInitialData();
      saveDb();
    }
  } else {
    dbCache = getInitialData();
    saveDb();
  }
  ensureOwnerExists(dbCache);
  ensureAllServices(dbCache);
  ensureDefaultProviders(dbCache);
  if (!dbCache.serviceRequests) {
    dbCache.serviceRequests = [];
  }
  if (!dbCache.supportTickets) {
    dbCache.supportTickets = [];
  }
  if (!dbCache.onboardingRequests) {
    dbCache.onboardingRequests = [];
  }
  if (!dbCache.settings) {
    dbCache.settings = getInitialData().settings;
  }
  for (const u of dbCache.users) {
    if (u.role === "MEGA_ADMIN") {
      u.onboardingStatus = "approved";
      if (!u.onboardingApprovedBy) u.onboardingApprovedBy = "SYSTEM OWNER / FOUNDER";
      if (!u.assignedServices) u.assignedServices = ["ONLINE_NIN_REGISTRATION"];
    } else {
      if (!u.onboardingStatus) u.onboardingStatus = "not_started";
      if (!u.assignedServices) u.assignedServices = [];
    }
  }
  saveDb();
  syncAuthoritativeDataFromSupabase().catch((err) => {
    console.error("[Supabase Initial Sync Error]:", err?.message || err);
  });
  return dbCache;
}
async function syncAuthoritativeDataFromSupabase(migrateAll = false) {
  if (!dbCache) return;
  try {
    const supaServices = await fetchSupabaseServices();
    if (supaServices && supaServices.length > 0) {
      if (!dbCache.services) dbCache.services = [];
      for (const ss of supaServices) {
        const sIdx = dbCache.services.findIndex((s) => s.id === ss.id || s.code.toUpperCase() === ss.code.toUpperCase());
        if (sIdx !== -1) {
          const supaTime = new Date(ss.updatedAt || 0).getTime();
          const localTime = new Date(dbCache.services[sIdx].updatedAt || 0).getTime();
          if (supaTime > localTime) {
            dbCache.services[sIdx] = {
              ...dbCache.services[sIdx],
              ...ss
            };
          }
        } else {
          dbCache.services.push(ss);
        }
      }
    }
    if (!isSupabaseServiceRoleActive()) return;
    const supaUsers = await fetchSupabaseUsers();
    if (supaUsers && supaUsers.length > 0) {
      for (const su of supaUsers) {
        const idx = dbCache.users.findIndex((u) => u.id === su.id || u.email.toLowerCase() === su.email.toLowerCase());
        if (idx !== -1) {
          const supaTime = new Date(su.updatedAt || 0).getTime();
          const localTime = new Date(dbCache.users[idx].updatedAt || 0).getTime();
          if (supaTime > localTime) {
            dbCache.users[idx] = {
              ...dbCache.users[idx],
              role: su.role,
              status: su.status,
              avatarUrl: su.avatarUrl || dbCache.users[idx].avatarUrl,
              onboardingStatus: su.onboardingStatus,
              onboardingApprovedAt: su.onboardingApprovedAt,
              onboardingApprovedBy: su.onboardingApprovedBy,
              roleAtApproval: su.roleAtApproval,
              assignedServices: su.assignedServices && su.assignedServices.length > 0 ? su.assignedServices : dbCache.users[idx].assignedServices,
              updatedAt: su.updatedAt
            };
          }
        } else {
          dbCache.users.push(su);
        }
      }
    }
    if (migrateAll) {
      for (const u of dbCache.users) {
        const res = await saveUserToSupabase(u);
        if (!res.success) {
          console.error("[Supabase Migration Notice] Failed to save user:", u.email, res.error);
        }
      }
      for (const w of dbCache.wallets) {
        const res = await saveWalletToSupabase(w);
        if (!res.success) {
          console.error("[Supabase Migration Notice] Failed to save wallet for:", w.userId, res.error);
        }
      }
    }
    ensureOwnerExists(dbCache);
  } catch (err) {
    console.error("[Supabase Sync Error]:", err.message || err);
  }
}
function getDb() {
  if (!dbCache) {
    return initDb();
  }
  ensureOwnerExists(dbCache);
  if (!dbCache.serviceRequests) {
    dbCache.serviceRequests = [];
  }
  if (!dbCache.supportTickets) {
    dbCache.supportTickets = [];
  }
  if (!dbCache.onboardingRequests) {
    dbCache.onboardingRequests = [];
  }
  if (!dbCache.services || dbCache.services.length === 0) {
    ensureAllServices(dbCache);
    saveDb();
  }
  return dbCache;
}
function generateServiceTicketId() {
  const db = getDb();
  const now = /* @__PURE__ */ new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  const datePrefix = `UPV-${yyyy}${mm}${dd}-`;
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let randomPart = "";
  for (let i = 0; i < 6; i++) {
    randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  let ticketId = `${datePrefix}${randomPart}`;
  const exists = (db.serviceRequests || []).some((r) => r.ticketId === ticketId || r.trackingId === ticketId);
  if (exists) {
    let altPart = "";
    for (let i = 0; i < 6; i++) {
      altPart += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    ticketId = `${datePrefix}${altPart}`;
  }
  return ticketId;
}
async function performDiskSave() {
  if (!dbCache || isSaving) {
    if (dbCache) pendingSave = true;
    return;
  }
  isSaving = true;
  pendingSave = false;
  try {
    if (!import_fs.default.existsSync(DATA_DIR)) {
      await import_fs.default.promises.mkdir(DATA_DIR, { recursive: true });
    }
    const jsonStr = JSON.stringify(dbCache);
    const tmpFile = `${DB_FILE}.tmp.${Date.now()}.${Math.random().toString(36).substring(2, 7)}`;
    await import_fs.default.promises.writeFile(tmpFile, jsonStr, "utf-8");
    await import_fs.default.promises.rename(tmpFile, DB_FILE);
  } catch (err) {
    console.warn("[DB_SAVE_WARN] Async write error:", err);
  } finally {
    isSaving = false;
    if (pendingSave) {
      pendingSave = false;
      setImmediate(() => {
        performDiskSave().catch(() => {
        });
      });
    }
  }
}
function saveDb() {
  if (!dbCache) return;
  pendingSave = true;
  if (saveDebounceTimer) {
    clearTimeout(saveDebounceTimer);
  }
  saveDebounceTimer = setTimeout(() => {
    saveDebounceTimer = null;
    performDiskSave().catch(() => {
    });
  }, 100);
}
function saveDbSync() {
  if (!dbCache) return;
  try {
    if (!import_fs.default.existsSync(DATA_DIR)) {
      import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpFile = `${DB_FILE}.tmp.${Date.now()}.${Math.random().toString(36).substring(2, 7)}`;
    import_fs.default.writeFileSync(tmpFile, JSON.stringify(dbCache), "utf-8");
    import_fs.default.renameSync(tmpFile, DB_FILE);
  } catch (err) {
    console.warn("[DB_SAVE_SYNC_WARN]", err);
  }
}
function logAudit(actorName, actorRole, action, details, userId, reference, ipAddress) {
  const db = getDb();
  const entry = {
    id: `aud_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    userId,
    actorName,
    actorRole,
    action,
    details,
    reference,
    ipAddress,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.auditLogs.unshift(entry);
  if (db.auditLogs.length > 2e3) {
    db.auditLogs = db.auditLogs.slice(0, 2e3);
  }
  saveDb();
}
var import_fs, import_path, import_crypto, DATA_DIR, DB_FILE, dbCache, processingLocks, defaultCatalogueServices, defaultEnrollmentCenters, isSaving, pendingSave, saveDebounceTimer;
var init_db = __esm({
  "server/db.ts"() {
    import_fs = __toESM(require("fs"), 1);
    import_path = __toESM(require("path"), 1);
    import_crypto = __toESM(require("crypto"), 1);
    init_supabase();
    DATA_DIR = import_path.default.join(process.cwd(), "data");
    DB_FILE = import_path.default.join(DATA_DIR, "db.json");
    dbCache = null;
    processingLocks = /* @__PURE__ */ new Set();
    defaultCatalogueServices = [
      {
        id: "srv_nin_01",
        code: "NIN",
        name: "NIN Verification",
        description: "Verify National Identity Number directly via official biometric identity registry database.",
        price: 1e3,
        status: "ACTIVE",
        icon: "UserCheck",
        category: "Identity",
        serviceType: "verification",
        providerMapping: "nin_verify",
        defaultProvider: "ninja",
        displayOrder: 1,
        requiredFields: [
          {
            name: "nin",
            label: "National Identity Number (NIN)",
            type: "text",
            placeholder: "Enter 11-digit NIN",
            required: true,
            regex: "^\\d{11}$",
            helperText: "Must be exactly 11 numeric digits"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_bvn_02",
        code: "BVN",
        name: "BVN Verification",
        description: "Instant Bank Verification Number check and KYC identity validation.",
        price: 1200,
        status: "ACTIVE",
        icon: "CreditCard",
        category: "Banking",
        serviceType: "verification",
        providerMapping: "bvn_verify",
        defaultProvider: "ninja",
        displayOrder: 2,
        requiredFields: [
          {
            name: "bvn",
            label: "Bank Verification Number (BVN)",
            type: "text",
            placeholder: "Enter 11-digit BVN",
            required: true,
            regex: "^\\d{11}$",
            helperText: "Must be exactly 11 numeric digits"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_phone_03",
        code: "PHONE",
        name: "Phone Number Verification",
        description: "Validate registered subscriber information, SIM binding and carrier status.",
        price: 500,
        status: "ACTIVE",
        icon: "PhoneCall",
        category: "Telecom",
        serviceType: "verification",
        providerMapping: "phone_verify",
        displayOrder: 3,
        requiredFields: [
          {
            name: "phone",
            label: "Phone Number",
            type: "text",
            placeholder: "e.g. 08012345678 or 2348012345678",
            required: true,
            regex: "^(0|234)[789][01]\\d{8}$",
            helperText: "Nigerian mobile telephone number"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_nin_phone_search_28",
        code: "NIN_PHONE",
        name: "NIN Phone Search",
        description: "Search and retrieve National Identity Number (NIN) record using registered mobile phone number.",
        price: 1200,
        status: "ACTIVE",
        icon: "Smartphone",
        category: "Identity",
        serviceType: "verification",
        providerMapping: "nin_phone_search",
        displayOrder: 4,
        requiredFields: [
          {
            name: "phone",
            label: "Registered Mobile Phone Number",
            type: "text",
            placeholder: "e.g. 08012345678 or 2348012345678",
            required: true,
            regex: "^(0|234)[789][01]\\d{8}$",
            helperText: "Enter registered mobile phone number linked to NIN"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_nin_val_04",
        code: "NIN_VALIDATION",
        name: "NIN Validation & Status Lookup",
        description: "Comprehensive National Identity register check with full slip verification breakdown.",
        price: 1500,
        status: "ACTIVE",
        icon: "ShieldCheck",
        category: "Identity",
        serviceType: "verification",
        providerMapping: "nin_validation",
        displayOrder: 4,
        requiredFields: [
          {
            name: "nin",
            label: "National Identity Number (NIN)",
            type: "text",
            placeholder: "Enter 11-digit NIN",
            required: true,
            regex: "^\\d{11}$"
          },
          {
            name: "trackingId",
            label: "Tracking ID / Slip No. (Optional)",
            type: "text",
            placeholder: "Enter tracking reference if available",
            required: false
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_id_lookup_05",
        code: "IDENTITY_LOOKUP",
        name: "Identity Cross Lookup",
        description: "Unified demographic search against certified governmental registry nodes.",
        price: 800,
        status: "ACTIVE",
        icon: "Search",
        category: "Cross-Match",
        serviceType: "verification",
        providerMapping: "identity_lookup",
        displayOrder: 5,
        defaultProvider: "veripine",
        requiredFields: [
          {
            name: "searchQuery",
            label: "Search Query (NIN, Phone or Document ID)",
            type: "text",
            placeholder: "Enter identifier",
            required: true
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_drivers_06",
        code: "DRIVERS_LICENSE",
        name: "Drivers License Verification",
        description: "FRSC Drivers License authenticity check and driver particulars match.",
        price: 1800,
        status: "ACTIVE",
        icon: "FileBadge",
        category: "Licensing",
        serviceType: "verification",
        providerMapping: "frsc_license",
        displayOrder: 6,
        requiredFields: [
          {
            name: "licenseNumber",
            label: "License Number",
            type: "text",
            placeholder: "e.g. ABC12345AA",
            required: true
          },
          {
            name: "dob",
            label: "Date of Birth (YYYY-MM-DD)",
            type: "text",
            placeholder: "1990-05-15",
            required: true
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      // --- INDIVIDUAL MODIFICATION SERVICES (EACH MANAGED INDIVIDUALLY) ---
      {
        id: "srv_nin_name_mod",
        code: "NIN_NAME_MOD",
        name: "Name Modification",
        description: "Change or correct registered names, fix spelling errors, or update surname due to marriage.",
        price: 4500,
        status: "ACTIVE",
        icon: "UserCheck",
        category: "Modification Services",
        serviceType: "non_verification",
        providerMapping: "modification_name",
        displayOrder: 7,
        requiredFields: [
          { name: "nin", label: "National Identity Number (NIN)", type: "text", placeholder: "Enter 11-digit NIN", required: true, regex: "^\\d{11}$" },
          { name: "surname", label: "New Surname", type: "text", placeholder: "Enter new surname", required: true },
          { name: "firstName", label: "New First Name", type: "text", placeholder: "Enter new first name", required: true },
          { name: "middleName", label: "New Middle Name", type: "text", placeholder: "Enter middle name if any", required: false }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_nin_dob_mod",
        code: "NIN_DOB_MOD",
        name: "Date of Birth Modification",
        description: "Official NIMC date of birth correction and registry update.",
        price: 5e4,
        status: "ACTIVE",
        icon: "Calendar",
        category: "Modification Services",
        serviceType: "non_verification",
        providerMapping: "modification_dob",
        displayOrder: 8,
        requiredFields: [
          { name: "nin", label: "National Identity Number (NIN)", type: "text", placeholder: "Enter 11-digit NIN", required: true, regex: "^\\d{11}$" },
          { name: "newDob", label: "Correct Date of Birth", type: "date", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_nin_phone_mod",
        code: "NIN_PHONE_MOD",
        name: "Phone Number Modification",
        description: "Update the primary mobile telephone number linked to your National Identity Number.",
        price: 4500,
        status: "ACTIVE",
        icon: "PhoneCall",
        category: "Modification Services",
        serviceType: "non_verification",
        providerMapping: "modification_phone",
        displayOrder: 9,
        requiredFields: [
          { name: "nin", label: "National Identity Number (NIN)", type: "text", placeholder: "Enter 11-digit NIN", required: true, regex: "^\\d{11}$" },
          { name: "oldPhone", label: "Old Phone Number", type: "text", placeholder: "Previous phone number", required: true },
          { name: "newPhone", label: "New Phone Number", type: "text", placeholder: "New phone number to link", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_nin_address_mod",
        code: "NIN_ADDRESS_MOD",
        name: "Address Modification",
        description: "Update residential address, state, and local government area on your national identity record.",
        price: 4500,
        status: "ACTIVE",
        icon: "Home",
        category: "Modification Services",
        serviceType: "non_verification",
        providerMapping: "modification_address",
        displayOrder: 10,
        requiredFields: [
          { name: "nin", label: "National Identity Number (NIN)", type: "text", placeholder: "Enter 11-digit NIN", required: true, regex: "^\\d{11}$" },
          { name: "address", label: "New Street Address", type: "text", placeholder: "Enter new residential address", required: true },
          { name: "state", label: "State", type: "text", placeholder: "State of residence", required: true },
          { name: "lga", label: "LGA", type: "text", placeholder: "Local Government Area", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_bvn_mod_center",
        code: "BVN_MODIFICATION",
        name: "BVN Modification",
        description: "Update name, date of birth, or phone number on bank verification record via certified center.",
        price: 3500,
        status: "ACTIVE",
        icon: "CreditCard",
        category: "Modification Services",
        serviceType: "non_verification",
        providerMapping: "bvn_modification",
        displayOrder: 11,
        requiredFields: [
          { name: "bvn", label: "Bank Verification Number (BVN)", type: "text", placeholder: "Enter 11-digit BVN", required: true, regex: "^\\d{11}$" },
          { name: "dob", label: "Date of Birth (YYYY-MM-DD)", type: "text", placeholder: "YYYY-MM-DD", required: true },
          { name: "newPhone", label: "New Phone Number", type: "text", placeholder: "Enter new phone number", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_online_nin_reg",
        code: "ONLINE_NIN_REGISTRATION",
        name: "Online NIN Registration",
        description: "Authorized operator enrollment service for registering citizen National Identity Numbers.",
        price: 5e3,
        status: "ACTIVE",
        icon: "Fingerprint",
        category: "Operator Services",
        serviceType: "non_verification",
        providerMapping: "online_nin_registration",
        displayOrder: 12,
        managedBy: "MEGA_ADMIN",
        allowedRoles: ["MEGA_ADMIN", "SUPER_ADMIN", "ADMIN", "AGENT"],
        requiredFields: [
          { name: "firstName", label: "First Name", type: "text", required: true },
          { name: "lastName", label: "Last Name", type: "text", required: true },
          { name: "dob", label: "Date of Birth", type: "date", required: true },
          { name: "nationality", label: "Nationality", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_cac_reg_01",
        code: "CAC_REGISTRATION",
        name: "CAC Business Registration",
        description: "Full business name, enterprise, or company incorporation registration with CAC.",
        price: 25e3,
        agentPrice: 2e4,
        status: "ACTIVE",
        icon: "Building2",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "cac_registration",
        displayOrder: 13,
        requiredFields: [
          { name: "proposedName1", label: "Proposed Name Option 1", type: "text", required: true },
          { name: "proposedName2", label: "Proposed Name Option 2", type: "text", required: true },
          { name: "businessNature", label: "Nature of Business", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_business_cac",
        code: "BUSINESS_CAC",
        name: "Business CAC",
        description: "Register Sole Proprietorship / Enterprise with the Corporate Affairs Commission.",
        price: 22e3,
        agentPrice: 18e3,
        status: "ACTIVE",
        icon: "Building",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "cac_registration",
        displayOrder: 14,
        requiredFields: [
          { name: "proposedName1", label: "Proposed Business Name 1", type: "text", required: true },
          { name: "proposedName2", label: "Proposed Business Name 2", type: "text", required: true },
          { name: "businessNature", label: "Nature of Business", type: "text", required: true },
          { name: "officeAddress", label: "Office Address", type: "text", required: true },
          { name: "proprietorName", label: "Proprietor Legal Name", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_company_cac",
        code: "COMPANY_CAC",
        name: "Company CAC",
        description: "Incorporate Private Limited Liability Company (LTD) with official CAC status.",
        price: 3e4,
        agentPrice: 25e3,
        status: "ACTIVE",
        icon: "Building2",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "cac_registration",
        displayOrder: 15,
        requiredFields: [
          { name: "proposedName1", label: "Proposed Company Name 1", type: "text", required: true },
          { name: "proposedName2", label: "Proposed Company Name 2", type: "text", required: true },
          { name: "businessNature", label: "Object / Nature of Business", type: "text", required: true },
          { name: "shareCapital", label: "Share Capital", type: "text", required: true },
          { name: "officeAddress", label: "Registered Address", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_tin_reg_01",
        code: "TIN_REGISTRATION",
        name: "TIN Registration",
        description: "Joint Tax Board (JTB) / FIRS Tax Identification Number registration and generation.",
        price: 8e3,
        agentPrice: 6e3,
        status: "ACTIVE",
        icon: "FileText",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "tin_registration",
        displayOrder: 16,
        requiredFields: [
          { name: "identifier", label: "NIN or BVN", type: "text", required: true },
          { name: "businessName", label: "Registered Business or Personal Name", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_tin_individual",
        code: "TIN_INDIVIDUAL",
        name: "Individual TIN Registration",
        description: "Register Personal / Sole Trader Tax Identification Number with Joint Tax Board.",
        price: 1e3,
        agentPrice: 750,
        status: "ACTIVE",
        icon: "Receipt",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "tin_registration",
        displayOrder: 17,
        requiredFields: [
          { name: "taxpayerName", label: "Taxpayer Full Name", type: "text", required: true },
          { name: "individualIdNumber", label: "NIN or BVN", type: "text", required: true },
          { name: "tinPhone", label: "Phone Number", type: "text", required: true },
          { name: "taxState", label: "State of Tax Residence", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_tin_company",
        code: "TIN_COMPANY",
        name: "Company TIN Registration",
        description: "Register Corporate entity Tax Identification Number for registered businesses and LLCs.",
        price: 2500,
        agentPrice: 2e3,
        status: "ACTIVE",
        icon: "FileBadge",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "tin_registration",
        displayOrder: 18,
        requiredFields: [
          { name: "taxpayerName", label: "Company / Business Registered Name", type: "text", required: true },
          { name: "rcOrBnNumber", label: "RC Number / BN Number", type: "text", required: true },
          { name: "tinPhone", label: "Official Phone Number", type: "text", required: true },
          { name: "taxState", label: "State of Operation", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_ipe_mod",
        code: "IPE_MODIFICATION",
        name: "IPE Modification",
        description: "Identity Protection Eligibility update and NIMC tracking clearance modification.",
        price: 4500,
        agentPrice: 3500,
        status: "ACTIVE",
        icon: "ShieldAlert",
        category: "Modification Services",
        serviceType: "non_verification",
        providerMapping: "ipe_clearance",
        displayOrder: 19,
        requiredFields: [
          { name: "nin", label: "National Identity Number (NIN)", type: "text", required: true, regex: "^\\d{11}$" },
          { name: "ipeTrackingId", label: "Tracking ID", type: "text", required: true },
          { name: "ipePhone", label: "Phone Number", type: "text", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_birth_att_09",
        code: "BIRTH_ATTESTATION",
        name: "Birth Attestation",
        description: "Official birth attestation processing (Takes 3-4 days)",
        price: 15e3,
        status: "ACTIVE",
        icon: "Baby",
        category: "Civil Registry",
        serviceType: "non_verification",
        providerMapping: "birth_attestation",
        displayOrder: 12,
        requiredFields: [
          {
            name: "fullName",
            label: "Applicant Legal Full Name",
            type: "text",
            placeholder: "Full Name as on records",
            required: true
          },
          {
            name: "dob",
            label: "Attested Date of Birth",
            type: "date",
            placeholder: "YYYY-MM-DD",
            required: true
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_pers_08",
        code: "PERSONALIZATION",
        name: "Personalization",
        description: "Get/retrieve NIN slip using a valid tracking ID.",
        price: 2e3,
        status: "ACTIVE",
        icon: "IdCard",
        category: "NIN Services",
        serviceType: "non_verification",
        providerMapping: "nin_personalization",
        displayOrder: 13,
        requiredFields: [
          {
            name: "trackingId",
            label: "NIMC Tracking ID",
            type: "text",
            placeholder: "Enter valid NIMC enrollment tracking ID",
            required: true,
            helperText: "Enter your valid NIMC enrollment tracking ID to retrieve slip"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_bvn_crm_10",
        code: "BVN_CRM",
        name: "BVN By CRM",
        description: "Verify Bank Verification Number through the supported CRM verification service.",
        price: 1500,
        status: "ACTIVE",
        icon: "Database",
        category: "Banking",
        serviceType: "verification",
        providerMapping: "bvn_crm",
        displayOrder: 10,
        requiredFields: [
          {
            name: "bvn",
            label: "Bank Verification Number (BVN)",
            type: "text",
            placeholder: "Enter 11-digit BVN",
            required: true,
            regex: "^\\d{11}$",
            helperText: "Must be 11 numeric digits"
          },
          {
            name: "crmRef",
            label: "CRM Reference / Account Number",
            type: "text",
            placeholder: "Enter CRM tracking ID or linked 10-digit NUBAN",
            required: true,
            helperText: "Any additional information required by the actual API"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_ipe_clr_12",
        code: "IPE_CLEARANCE",
        name: "IPE Clearance",
        description: "Identity Protection Eligibility clearance service.",
        price: 5e3,
        status: "ACTIVE",
        icon: "ShieldAlert",
        category: "Identity",
        serviceType: "non_verification",
        providerMapping: "ipe_clearance",
        displayOrder: 12,
        requiredFields: [
          {
            name: "nin",
            label: "National Identity Number (NIN)",
            type: "text",
            placeholder: "Enter 11-digit NIN",
            required: true,
            regex: "^\\d{11}$",
            helperText: "11-digit applicant NIN"
          },
          {
            name: "applicantDetails",
            label: "Applicant Legal Name & NIMC Center",
            type: "text",
            placeholder: "Full legal name and NIMC registration center details",
            required: true,
            helperText: "Other information required by the actual verification provider"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_nin_delink_14",
        code: "NIN_DELINKING",
        name: "NIN Delinking",
        description: "NIN delinking/self-service delinking and email retrieval where supported.",
        price: 2500,
        status: "ACTIVE",
        icon: "Unlink",
        category: "NIN Services",
        serviceType: "non_verification",
        providerMapping: "nin_delinking",
        displayOrder: 14,
        requiredFields: [
          {
            name: "nin",
            label: "National Identity Number (NIN)",
            type: "text",
            placeholder: "Enter 11-digit NIN",
            required: true,
            regex: "^\\d{11}$",
            helperText: "11-digit applicant NIN"
          },
          {
            name: "contactInfo",
            label: "Phone Number or Email to Delink / Retrieve",
            type: "text",
            placeholder: "e.g. 08012345678 or user@example.com",
            required: true,
            helperText: "Phone/email or other information required by the actual provider"
          },
          {
            name: "delinkAction",
            label: "Delinking Action Type",
            type: "select",
            placeholder: "Select action",
            required: true,
            options: [
              "Self-Service Phone Delinking",
              "Self-Service Email Delinking",
              "Email Retrieval & Status Verification"
            ]
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_bvn_and_15",
        code: "BVN_ANDROID_USER",
        name: "BVN Android User",
        description: "Allow users/agents to submit their details to become an approved BVN service agent where this service is actually supported.",
        price: 5e3,
        status: "ACTIVE",
        icon: "Smartphone",
        category: "Agent Services",
        serviceType: "non_verification",
        providerMapping: "bvn_android_user",
        displayOrder: 15,
        requiredFields: [
          {
            name: "fullName",
            label: "Agent Legal Full Name",
            type: "text",
            placeholder: "Enter official full legal name",
            required: true
          },
          {
            name: "phone",
            label: "Mobile Phone Number",
            type: "text",
            placeholder: "e.g. 08012345678",
            required: true,
            regex: "^(0|234)[789][01]\\d{8}$"
          },
          {
            name: "bvn",
            label: "BVN",
            type: "text",
            placeholder: "Enter 11-digit BVN",
            required: true,
            regex: "^\\d{11}$",
            helperText: "Must be 11 numeric digits"
          },
          {
            name: "email",
            label: "Agent Email Address",
            type: "text",
            placeholder: "agent@example.com",
            required: true
          },
          {
            name: "deviceDetails",
            label: "Android Device Particulars",
            type: "text",
            placeholder: "Device model and hardware identification",
            required: true,
            helperText: "Other provider-required information"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_bvn_ret_16",
        code: "BVN_RETRIEVAL",
        name: "BVN Retrieval",
        description: "Retrieve BVN details. This service costs \u20A6550.00.",
        price: 550,
        status: "ACTIVE",
        icon: "KeyRound",
        category: "Banking",
        serviceType: "non_verification",
        providerMapping: "bvn_retrieval",
        displayOrder: 16,
        requiredFields: [
          {
            name: "phone",
            label: "Phone Number",
            type: "text",
            placeholder: "e.g. 08012345678 or 2348012345678",
            required: true,
            regex: "^(0|234)[789][01]\\d{8}$",
            helperText: "Enter registered mobile phone number linked to BVN"
          },
          {
            name: "firstName",
            label: "First Name (Optional)",
            type: "text",
            placeholder: "Enter first name if known",
            required: false
          },
          {
            name: "lastName",
            label: "Last Name / Surname (Optional)",
            type: "text",
            placeholder: "Enter surname if known",
            required: false
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_cac_tin_17",
        code: "CAC_TIN",
        name: "CAC & TIN",
        description: "Corporate Affairs Commission filings & Joint Tax Board registrations (Business CAC, Company CAC, Individual TIN Registration, Company TIN Registration).",
        price: 1e3,
        status: "ACTIVE",
        icon: "Building2",
        category: "Corporate",
        serviceType: "non_verification",
        providerMapping: "cac_tin_service",
        displayOrder: 17,
        requiredFields: [
          {
            name: "cacTinType",
            label: "Sub-Service",
            type: "select",
            options: [
              "Business CAC",
              "Company CAC",
              "Individual TIN Registration",
              "Company TIN Registration"
            ],
            required: true
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_self_email_20",
        code: "SELF_SERVICE_EMAIL",
        name: "Self service Email Retrieval",
        description: "Retrieve email address linked to your NIN identity record.",
        price: 1500,
        status: "ACTIVE",
        icon: "Mail",
        category: "NIN Services",
        serviceType: "non_verification",
        providerMapping: "self_service_email",
        displayOrder: 20,
        requiredFields: [
          { name: "nin", label: "National Identity Number (NIN)", type: "text", required: true },
          { name: "email", label: "Email", type: "email", placeholder: "Enter email address", required: true }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "srv_demographic_ver_21",
        code: "DEMOGRAPHIC_VERIFICATION",
        name: "Demographic Verification",
        description: "Verify identity records by matching demographic criteria: First Name, Last Name, Gender, and Date of Birth.",
        price: 1200,
        status: "ACTIVE",
        icon: "UserCheck",
        category: "Identity Verification",
        serviceType: "verification",
        providerMapping: "demographic_verification",
        displayOrder: 21,
        requiredFields: [
          {
            name: "firstName",
            label: "First Name",
            type: "text",
            placeholder: "Enter first name",
            required: true,
            helperText: "Applicant legal first name"
          },
          {
            name: "lastName",
            label: "Last Name",
            type: "text",
            placeholder: "Enter last name (surname)",
            required: true,
            helperText: "Applicant legal last name / surname"
          },
          {
            name: "gender",
            label: "Gender",
            type: "select",
            placeholder: "Select gender",
            required: true,
            options: ["Male", "Female"],
            helperText: "Applicant gender"
          },
          {
            name: "dob",
            label: "Date of Birth",
            type: "date",
            placeholder: "YYYY-MM-DD",
            required: true,
            helperText: "Applicant registered date of birth"
          }
        ],
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    ];
    defaultEnrollmentCenters = [
      {
        id: "bvn_ec_agency",
        name: "AGENCY",
        code: "AGENCY",
        price: 3500,
        status: "ACTIVE",
        description: "Agency Banking Enrollment Center Network",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "bvn_ec_cafe",
        name: "CAFE BVN",
        code: "CAFE_BVN",
        price: 3500,
        status: "ACTIVE",
        description: "Cyber Caf\xE9 Certified Service Point",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "bvn_ec_gtb",
        name: "GT BANK",
        code: "GT_BANK",
        price: 7e3,
        status: "ACTIVE",
        description: "Guaranty Trust Bank Official KYC Center",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    ];
    isSaving = false;
    pendingSave = false;
    saveDebounceTimer = null;
  }
});

// server.ts
var import_config2 = require("dotenv/config");
var import_express2 = __toESM(require("express"), 1);
var import_path3 = __toESM(require("path"), 1);
var import_fs3 = __toESM(require("fs"), 1);
var import_vite = require("vite");

// server/api.ts
var import_express = __toESM(require("express"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_crypto4 = __toESM(require("crypto"), 1);
init_db();
init_supabase();

// server/paystack.ts
var import_crypto2 = __toESM(require("crypto"), 1);
init_db();
var PAYSTACK_BASE_URL = "https://api.paystack.co";
function getSecretKey() {
  let key = (process.env.PAYSTACK_SECRET_KEY || process.env.PAYSTACK_LIVE_SECRET_KEY || process.env.PAYSTACK_SECRET || process.env.PAYSTACK_KEY || process.env.LIVE_PAYSTACK_SECRET_KEY || process.env.PAYSTACK_LIVE_KEY || "").trim();
  if (!key) {
    try {
      const db = getDb();
      const p = db.providers?.find((prov) => prov.slug === "paystack");
      if (p?.secretKey && typeof p.secretKey === "string" && p.secretKey.trim()) {
        key = p.secretKey.trim();
      }
    } catch {
    }
  }
  return key;
}
function getPublicKey() {
  let key = (process.env.VITE_PAYSTACK_PUBLIC_KEY || process.env.PAYSTACK_PUBLIC_KEY || process.env.VITE_PAYSTACK_LIVE_PUBLIC_KEY || process.env.PAYSTACK_LIVE_PUBLIC_KEY || process.env.VITE_PAYSTACK_KEY || "").trim();
  if (!key) {
    try {
      const db = getDb();
      const p = db.providers?.find((prov) => prov.slug === "paystack");
      if (p?.apiKey && typeof p.apiKey === "string" && p.apiKey.trim()) {
        key = p.apiKey.trim();
      }
    } catch {
    }
  }
  return key;
}
function getPaystackConfigStatus() {
  let secretKey = "";
  try {
    secretKey = getSecretKey();
  } catch {
    secretKey = "";
  }
  const pubKey = getPublicKey();
  const configured = Boolean(secretKey && secretKey.startsWith("sk_live_"));
  const mode = configured ? "live" : "not_configured";
  let safePublicKey = "";
  if (pubKey) {
    safePublicKey = pubKey.length > 16 ? `${pubKey.substring(0, 10)}...${pubKey.substring(pubKey.length - 4)}` : pubKey;
  }
  return {
    configured,
    mode,
    publicKey: safePublicKey,
    hasSecret: configured
  };
}
async function initializePaystackTransaction(params) {
  const secretKey = getSecretKey();
  const hasSecret = Boolean(secretKey && secretKey.startsWith("sk_live_"));
  const hasEmail = Boolean(params.email && params.email.includes("@"));
  if (!secretKey) {
    console.warn("[Paystack Safe Diagnostic]", {
      action: "INITIALIZE_TRANSACTION_FAILED_PRECHECK",
      error: "PAYSTACK_SECRET_KEY_NOT_CONFIGURED",
      hasSecretKey: false,
      hasCustomerEmail: hasEmail,
      amountNgn: params.amountNgn,
      currency: "NGN",
      reference: params.reference
    });
    throw new Error("Paystack Live Secret Key is not configured on the server. Please add PAYSTACK_SECRET_KEY (sk_live_*) in your AI Studio project Secrets.");
  }
  if (!params.email || !params.email.includes("@")) {
    throw new Error("Valid customer email is required for Paystack transaction.");
  }
  if (!params.amountNgn || params.amountNgn <= 0) {
    throw new Error("Valid positive amount in NGN is required.");
  }
  if (!params.reference) {
    throw new Error("Unique transaction reference is required.");
  }
  const amountInKobo = Math.round(params.amountNgn * 100);
  const payload = {
    email: params.email.trim(),
    amount: amountInKobo,
    reference: params.reference.trim(),
    metadata: {
      platform: "UGOPAWAVERIFY",
      amount_ngn: params.amountNgn,
      ...params.metadata || {}
    }
  };
  if (params.callbackUrl) {
    payload.callback_url = params.callbackUrl;
  }
  if (params.channels && params.channels.length > 0) {
    payload.channels = params.channels;
  }
  console.log("[Paystack Safe Diagnostic - Request]", {
    action: "INITIALIZE_TRANSACTION_SUBMIT",
    endpoint: `${PAYSTACK_BASE_URL}/transaction/initialize`,
    hasSecretKey: hasSecret,
    keyPrefix: secretKey ? `${secretKey.substring(0, 8)}...` : "NONE",
    hasCustomerEmail: hasEmail,
    amountNgn: params.amountNgn,
    amountInKobo,
    currency: "NGN",
    reference: params.reference,
    callbackConfigured: Boolean(params.callbackUrl)
  });
  const response = await fetch(`${PAYSTACK_BASE_URL}/transaction/initialize`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${secretKey}`,
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(3e4)
  });
  const data = await response.json().catch(() => ({ status: false, message: "Invalid JSON response from Paystack" }));
  console.log("[Paystack Safe Diagnostic - Response]", {
    action: "INITIALIZE_TRANSACTION_RESPONSE",
    httpStatus: response.status,
    paystackStatus: data?.status,
    paystackMessage: data?.message,
    paystackCode: data?.code,
    paystackType: data?.type,
    hasAuthorizationUrl: Boolean(data?.data?.authorization_url),
    reference: params.reference
  });
  if (!response.ok || !data.status) {
    const errorMsg = data?.message || `Paystack initialization failed with status ${response.status}`;
    throw new Error(errorMsg);
  }
  return data;
}
async function verifyPaystackTransaction(reference) {
  const secretKey = getSecretKey();
  if (!secretKey) {
    throw new Error("Paystack secret key is not configured on the server.");
  }
  const cleanRef = String(reference || "").trim();
  if (!cleanRef) {
    throw new Error("Transaction reference is required for verification.");
  }
  const response = await fetch(`${PAYSTACK_BASE_URL}/transaction/verify/${encodeURIComponent(cleanRef)}`, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${secretKey}`,
      "Accept": "application/json"
    }
  });
  const data = await response.json().catch(() => ({ status: false, message: "Invalid JSON response from Paystack" }));
  if (!response.ok || !data.status) {
    const errorMsg = data?.message || `Paystack transaction verification failed with status ${response.status}`;
    throw new Error(errorMsg);
  }
  return data;
}
function verifyWebhookSignature(signatureHeader, rawBody) {
  const secretKey = getSecretKey();
  if (!secretKey || !signatureHeader || !rawBody) {
    return false;
  }
  try {
    const hash = import_crypto2.default.createHmac("sha512", secretKey).update(rawBody).digest("hex");
    const expectedBuffer = Buffer.from(hash, "hex");
    const actualBuffer = Buffer.from(signatureHeader.trim(), "hex");
    if (expectedBuffer.length !== actualBuffer.length) {
      return false;
    }
    return import_crypto2.default.timingSafeEqual(expectedBuffer, actualBuffer);
  } catch (err) {
    return false;
  }
}

// server/sendchamp.ts
var import_config = require("dotenv/config");
var import_crypto3 = __toESM(require("crypto"), 1);
var import_https = __toESM(require("https"), 1);
async function sendchampRequest(endpoint, postData) {
  const baseUrl = getSendchampBaseUrl();
  const fullUrl = new URL(endpoint.startsWith("http") ? endpoint : `${baseUrl}${endpoint.startsWith("/") ? "" : "/"}${endpoint}`);
  const apiKey = getSendchampApiKey();
  const bodyString = postData ? JSON.stringify(postData) : null;
  return new Promise((resolve, reject) => {
    const options = {
      hostname: fullUrl.hostname,
      port: fullUrl.port || 443,
      path: `${fullUrl.pathname}${fullUrl.search}`,
      method: postData ? "POST" : "GET",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Accept": "application/json",
        ...bodyString ? {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(bodyString)
        } : {}
      },
      timeout: 15e3
    };
    const req = import_https.default.request(options, (res) => {
      let raw = "";
      res.on("data", (chunk) => {
        raw += chunk;
      });
      res.on("end", () => {
        let parsed = null;
        try {
          parsed = JSON.parse(raw);
        } catch {
          parsed = { rawResponse: raw };
        }
        resolve({ statusCode: res.statusCode || 500, data: parsed });
      });
    });
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Sendchamp request timed out after 15 seconds."));
    });
    req.on("error", (err) => {
      reject(err);
    });
    if (bodyString) {
      req.write(bodyString);
    }
    req.end();
  });
}
var onboardingOtpSessions = /* @__PURE__ */ new Map();
function getSendchampBaseUrl() {
  const envUrl = (process.env.SENDCHAMP_BASE_URL || "").trim().replace(/\/$/, "");
  return envUrl || "https://api.sendchamp.com/api/v1";
}
function getSendchampApiKey() {
  let key = (process.env.SENDCHAMP_API_KEY || "").trim();
  key = key.replace(/^["']|["']$/g, "");
  key = key.replace(/[.;,]+$/, "");
  return key.trim();
}
function normalizeNigerianPhone(phone) {
  if (!phone || typeof phone !== "string") {
    return { valid: false, normalized: "", displayFormatted: "", error: "Phone number is required." };
  }
  let clean = phone.trim().replace(/[^\d+]/g, "");
  if (clean.startsWith("+")) {
    clean = clean.substring(1);
  }
  if (clean.startsWith("0") && clean.length === 11) {
    clean = "234" + clean.substring(1);
  } else if (!clean.startsWith("234") && clean.length === 10) {
    clean = "234" + clean;
  }
  const isNigerian = /^234(7|8|9)\d{9}$/.test(clean);
  const isInternational = /^\d{11,15}$/.test(clean);
  if (!isNigerian && !isInternational) {
    return {
      valid: false,
      normalized: clean,
      displayFormatted: phone,
      error: "Please enter a valid Nigerian mobile phone number (e.g. 08012345678 or +2348012345678)."
    };
  }
  const masked = clean.length >= 8 ? `+${clean.slice(0, 3)} ${clean.slice(3, 6)}****${clean.slice(-3)}` : `+${clean}`;
  return {
    valid: true,
    normalized: clean,
    displayFormatted: masked
  };
}
function generateSecureOtp() {
  const buf = import_crypto3.default.randomBytes(4);
  const num = buf.readUInt32BE(0) % 1e6;
  return num.toString().padStart(6, "0");
}
async function sendSendchampOtp(userId, rawPhone) {
  const apiKey = getSendchampApiKey();
  if (!apiKey) {
    return {
      success: false,
      unconfigured: true,
      message: "Sendchamp SMS gateway is not configured on the server. Please set SENDCHAMP_API_KEY in the environment secrets."
    };
  }
  const phoneCheck = normalizeNigerianPhone(rawPhone);
  if (!phoneCheck.valid) {
    return {
      success: false,
      message: phoneCheck.error || "Invalid Nigerian phone number format."
    };
  }
  const normalizedPhone = phoneCheck.normalized;
  const existing = onboardingOtpSessions.get(userId);
  if (existing && existing.lastSentAt) {
    const elapsedSeconds = Math.floor((Date.now() - existing.lastSentAt) / 1e3);
    const cooldownPeriod = 60;
    if (elapsedSeconds < cooldownPeriod) {
      const remaining = cooldownPeriod - elapsedSeconds;
      return {
        success: false,
        cooldownSeconds: remaining,
        message: `Please wait ${remaining} seconds before requesting a new OTP.`
      };
    }
  }
  const baseUrl = getSendchampBaseUrl();
  try {
    const { statusCode, data: resData } = await sendchampRequest("/verification/create", {
      channel: "sms",
      sender_name: "Sendchamp",
      token_type: "numeric",
      token_length: 6,
      expiration_time: 10,
      // 10 minutes
      customer_mobile_number: normalizedPhone
    });
    const isSuccess = statusCode >= 200 && statusCode < 300 && (resData?.status === "success" || resData?.code === 200 || resData?.code === 201 || Boolean(resData?.data?.reference || resData?.data?.business_id));
    if (isSuccess) {
      const reference = resData?.data?.reference || resData?.data?.verification_reference || `sc_${Date.now()}`;
      onboardingOtpSessions.set(userId, {
        userId,
        phone: normalizedPhone,
        reference,
        mode: "sendchamp_api",
        expiresAt: Date.now() + 10 * 60 * 1e3,
        attempts: 0,
        verified: false,
        lastSentAt: Date.now()
      });
      return {
        success: true,
        message: "A 6-digit verification code has been sent via SMS to your phone number.",
        normalizedPhone,
        displayPhone: phoneCheck.displayFormatted,
        cooldownSeconds: 60
      };
    }
    const sendchampMsg = resData?.message || resData?.errors?.[0]?.message || "Sendchamp verification dispatch failed";
    console.warn("[Sendchamp OTP] Verification API response non-200:", statusCode, sendchampMsg);
    const fallbackOtp = generateSecureOtp();
    const salt = import_crypto3.default.randomBytes(16).toString("hex");
    const pinHash = import_crypto3.default.createHash("sha256").update(fallbackOtp + salt).digest("hex");
    const { statusCode: smsStatusCode, data: smsData } = await sendchampRequest("/sms/send", {
      to: [normalizedPhone],
      message: `Your UGOPAWAVERIFY onboarding verification code is ${fallbackOtp}. Valid for 10 minutes. Do not share.`,
      sender_name: "Sendchamp",
      route: "dnd"
    });
    if (smsStatusCode >= 200 && smsStatusCode < 300 && (smsData?.status === "success" || smsData?.code === 200)) {
      onboardingOtpSessions.set(userId, {
        userId,
        phone: normalizedPhone,
        pinHash,
        salt,
        mode: "crypto_secure",
        expiresAt: Date.now() + 10 * 60 * 1e3,
        attempts: 0,
        verified: false,
        lastSentAt: Date.now()
      });
      return {
        success: true,
        message: "A 6-digit verification code has been sent via SMS to your phone number.",
        normalizedPhone,
        displayPhone: phoneCheck.displayFormatted,
        cooldownSeconds: 60
      };
    }
    return {
      success: false,
      message: `Failed to deliver SMS OTP via Sendchamp: ${sendchampMsg}. Please verify your phone number or try again shortly.`
    };
  } catch (err) {
    console.error("[Sendchamp OTP] Request exception:", err.message || err);
    return {
      success: false,
      message: `SMS gateway error: ${err.message || "Unable to connect to Sendchamp service"}. Please try again.`
    };
  }
}
async function verifySendchampOtp(userId, rawPhone, otpCode) {
  const apiKey = getSendchampApiKey();
  if (!apiKey) {
    return {
      success: false,
      verified: false,
      message: "Sendchamp SMS gateway is not configured on the server."
    };
  }
  const phoneCheck = normalizeNigerianPhone(rawPhone);
  if (!phoneCheck.valid) {
    return {
      success: false,
      verified: false,
      message: "Invalid phone number format."
    };
  }
  const normalizedPhone = phoneCheck.normalized;
  const cleanOtp = String(otpCode || "").replace(/\D/g, "").trim();
  if (cleanOtp.length !== 6) {
    return {
      success: false,
      verified: false,
      message: "OTP must be an exact 6-digit numerical code."
    };
  }
  const session = onboardingOtpSessions.get(userId);
  if (!session) {
    return {
      success: false,
      verified: false,
      message: 'No active OTP verification session found. Please click "Send OTP" to receive a verification code.'
    };
  }
  if (session.phone !== normalizedPhone) {
    return {
      success: false,
      verified: false,
      message: "The submitted phone number does not match the number that requested the OTP code."
    };
  }
  if (Date.now() > session.expiresAt) {
    onboardingOtpSessions.delete(userId);
    return {
      success: false,
      verified: false,
      message: "The verification code has expired (10-minute limit). Please request a fresh OTP."
    };
  }
  session.attempts += 1;
  const baseUrl = getSendchampBaseUrl();
  if (session.mode === "sendchamp_api" && session.reference) {
    try {
      const { statusCode, data: verifyData } = await sendchampRequest("/verification/confirm", {
        verification_reference: session.reference,
        verification_code: cleanOtp
      });
      const isVerified = Boolean(
        statusCode >= 200 && statusCode < 300 && (verifyData?.status === "success" || verifyData?.code === 200) || verifyData?.data?.status === "verified"
      );
      if (isVerified) {
        session.verified = true;
        onboardingOtpSessions.set(userId, session);
        return {
          success: true,
          verified: true,
          normalizedPhone,
          message: "Phone number verified successfully via Sendchamp SMS OTP!"
        };
      }
      const failMsg = verifyData?.message || "Incorrect 6-digit OTP code.";
      return {
        success: false,
        verified: false,
        message: failMsg
      };
    } catch (err) {
      console.warn("[Sendchamp OTP] Verification confirm exception:", err.message || err);
    }
  }
  if (session.pinHash && session.salt) {
    const inputHash = import_crypto3.default.createHash("sha256").update(cleanOtp + session.salt).digest("hex");
    if (import_crypto3.default.timingSafeEqual(Buffer.from(inputHash), Buffer.from(session.pinHash))) {
      session.verified = true;
      onboardingOtpSessions.set(userId, session);
      return {
        success: true,
        verified: true,
        normalizedPhone,
        message: "Phone number verified successfully via Sendchamp SMS OTP!"
      };
    }
    return {
      success: false,
      verified: false,
      message: "Incorrect 6-digit OTP code."
    };
  }
  return {
    success: false,
    verified: false,
    message: "Verification failed. Please request a fresh OTP code."
  };
}
function isPhoneVerifiedForUser(userId, rawPhone) {
  const phoneCheck = normalizeNigerianPhone(rawPhone);
  if (!phoneCheck.valid) return false;
  const session = onboardingOtpSessions.get(userId);
  if (session && session.verified && session.phone === phoneCheck.normalized) {
    if (Date.now() - session.lastSentAt <= 24 * 60 * 60 * 1e3) {
      return true;
    }
  }
  try {
    const { getDb: getDb2 } = (init_db(), __toCommonJS(db_exports));
    const db = getDb2();
    const user = db.users?.find((u) => u.id === userId);
    if (user && user.phone1Verified && user.phone1VerifiedNumber) {
      const userPhoneCheck = normalizeNigerianPhone(user.phone1VerifiedNumber);
      if (userPhoneCheck.valid && userPhoneCheck.normalized === phoneCheck.normalized) {
        return true;
      }
    }
  } catch {
  }
  return false;
}

// server/providerAdapter.ts
init_db();
var DEFAULT_API_TIMEOUT_MS = Number(process.env.API_REQUEST_TIMEOUT_MS) || 12e4;
function getServiceTimeoutMs(serviceCode) {
  if (process.env.API_REQUEST_TIMEOUT_MS) {
    const envVal = Number(process.env.API_REQUEST_TIMEOUT_MS);
    if (!isNaN(envVal) && envVal > 0) return envVal;
  }
  try {
    const db = getDb();
    if (db.settings?.apiTimeoutMs && Number(db.settings.apiTimeoutMs) > 0) {
      return Number(db.settings.apiTimeoutMs);
    }
    if (serviceCode) {
      const srv = db.services?.find((s) => s.code.toUpperCase() === serviceCode.toUpperCase());
      if (srv?.timeoutMs && Number(srv.timeoutMs) > 0) {
        return Number(srv.timeoutMs);
      }
    }
  } catch {
  }
  return DEFAULT_API_TIMEOUT_MS;
}
function sanitizeProviderResponse(obj) {
  if (!obj || typeof obj !== "object") return obj;
  try {
    const cloned = JSON.parse(JSON.stringify(obj));
    const mask = (target) => {
      if (!target || typeof target !== "object") return;
      for (const k of Object.keys(target)) {
        if (/api_?key|secret|token|password|authorization|auth_header|bearer/i.test(k)) {
          target[k] = "[REDACTED]";
        } else if (typeof target[k] === "object") {
          mask(target[k]);
        }
      }
    };
    mask(cloned);
    return cloned;
  } catch {
    return null;
  }
}
function getVeripineBaseUrl(provider) {
  if (provider?.slug === "veripine" && provider?.baseUrl && typeof provider.baseUrl === "string" && provider.baseUrl.startsWith("http")) {
    return provider.baseUrl.replace(/\/$/, "");
  }
  try {
    const db = getDb();
    const vProv = db.providers.find((p) => p.slug === "veripine");
    if (vProv?.baseUrl && typeof vProv.baseUrl === "string" && vProv.baseUrl.startsWith("http")) {
      return vProv.baseUrl.replace(/\/$/, "");
    }
  } catch {
  }
  const envUrl = process.env.VERIPINE_BASE_URL;
  if (envUrl && typeof envUrl === "string" && envUrl.startsWith("http")) {
    return envUrl.replace(/\/$/, "");
  }
  return "https://veripine.com/api";
}
function getVeripineApiKey(provider) {
  if (provider?.slug === "veripine") {
    const key = provider.apiKey || provider.secretKey;
    if (key && typeof key === "string" && key.trim()) return key.trim();
  }
  try {
    const db = getDb();
    const vProv = db.providers.find((p) => p.slug === "veripine");
    const key = vProv?.apiKey || vProv?.secretKey;
    if (key && typeof key === "string" && key.trim()) return key.trim();
  } catch {
  }
  const envKey = process.env.VERIPINE_SECRET_KEY || process.env.VERIPINE_API_KEY || (process.env.VERIPINE_BASE_URL && !process.env.VERIPINE_BASE_URL.startsWith("http") ? process.env.VERIPINE_BASE_URL : "") || "";
  return typeof envKey === "string" ? envKey.trim() : "";
}
function getNinjaBaseUrl(provider) {
  const candidateUrls = [
    provider?.baseUrl,
    (() => {
      try {
        return getDb().providers.find((p) => p.slug === "ninja")?.baseUrl;
      } catch {
        return null;
      }
    })(),
    process.env.NINJA_BASE_URL
  ];
  for (const url of candidateUrls) {
    if (url && typeof url === "string" && url.startsWith("http")) {
      const clean = url.replace(/\/+$/, "").replace(/\/login\/?$/, "");
      if (clean && !clean.endsWith(".ng") && !clean.endsWith("/login")) {
        return clean;
      }
    }
  }
  return "https://api.ninja.boucloud.io";
}
function getNinjaApiKey(provider) {
  if (provider?.slug === "ninja") {
    const key2 = provider.secretKey || provider.apiKey;
    if (key2 && typeof key2 === "string" && key2.trim()) return key2.trim();
  }
  try {
    const db = getDb();
    const nProv = db.providers.find((p) => p.slug === "ninja");
    const key2 = nProv?.secretKey || nProv?.apiKey;
    if (key2 && typeof key2 === "string" && key2.trim()) return key2.trim();
  } catch {
  }
  const key = process.env.NINJA_SECRET_KEY || process.env.NINJA_PUBLIC_KEY || process.env.NINJA_API_KEY || "";
  return typeof key === "string" ? key.trim() : "";
}
function getNinjaSecretKey(provider) {
  if (provider?.slug === "ninja") {
    const key2 = provider.secretKey || provider.apiKey;
    if (key2 && typeof key2 === "string" && key2.trim()) return key2.trim();
  }
  try {
    const db = getDb();
    const nProv = db.providers.find((p) => p.slug === "ninja");
    const key2 = nProv?.secretKey || nProv?.apiKey;
    if (key2 && typeof key2 === "string" && key2.trim()) return key2.trim();
  } catch {
  }
  const key = process.env.NINJA_SECRET_KEY || process.env.NINJA_PUBLIC_KEY || "";
  return typeof key === "string" ? key.trim() : "";
}
var SERVICE_PROVIDER_MAP = {
  // Approved Ninja Services (Ninja ONLY):
  "NIN": "ninja",
  "NIN_VERIFICATION": "ninja",
  "NIN_LOOKUP": "ninja",
  "NIN_STATUS": "ninja",
  "NIN_STATUS_LOOKUP": "ninja",
  "NIN_VERIFICATION_STATUS_LOOKUP": "ninja",
  "BVN": "ninja",
  "BVN_VERIFICATION": "ninja",
  "DRIVERS_LICENSE": "ninja",
  "DRIVING_LICENCE": "ninja",
  "DRIVING_LICENCE_VERIFICATION": "ninja",
  "BVN_CRM": "ninja",
  "BVN_BY_CRM": "ninja",
  // Approved Veripine Services (Veripine ONLY):
  "PHONE": "veripine",
  "PHONE_NUMBER_VERIFICATION": "veripine",
  "PHONE_VERIFICATION": "veripine",
  "NIN_PHONE": "veripine",
  "NIN_PHONE_SEARCH": "veripine",
  "DEMOGRAPHIC_VERIFICATION": "veripine",
  "DEMOGRAPHIC": "veripine",
  "DEMOGRAPHIC_SEARCH": "veripine",
  "PERSONALIZATION": "veripine",
  "NIN_TRACKING": "veripine",
  "IDENTITY_LOOKUP": "veripine",
  "IDENTITY_CROSS_LOOKUP": "veripine",
  // Other Existing Platform Services (Veripine):
  "BVN_RETRIEVAL": "veripine",
  "BVN_PHONE": "veripine",
  "NIN_VALIDATION": "veripine",
  "NIN_NAME_MOD": "veripine",
  "NAME_MODIFICATION": "veripine",
  "NIN_PHONE_MOD": "veripine",
  "PHONE_NUMBER_MODIFICATION": "veripine",
  "NIN_ADDRESS_MOD": "veripine",
  "ADDRESS_MODIFICATION": "veripine",
  "NIN_DOB_MOD": "veripine",
  "NIN_MODIFICATION": "veripine",
  "BIRTH_ATTESTATION": "veripine",
  "IPE_CLEARANCE": "veripine",
  "IPE_MODIFICATION": "veripine",
  "NIN_DELINKING": "veripine",
  "BVN_ANDROID_USER": "veripine",
  "CAC_TIN": "veripine",
  "CAC_REGISTRATION": "veripine",
  "TIN": "veripine",
  "TIN_INDIVIDUAL": "veripine",
  "TIN_COMPANY": "veripine",
  "SELF_SERVICE_EMAIL": "veripine"
};
var EnterpriseProviderAdapter = class {
  getProviderForService(serviceCode) {
    const db = getDb();
    if (serviceCode) {
      const codeUpper = serviceCode.toUpperCase();
      const service = db.services.find((s) => s.code.toUpperCase() === codeUpper);
      if (service) {
        if (service.defaultProvider) {
          const target = String(service.defaultProvider).toLowerCase();
          const matched = db.providers.find((p) => (p.slug === target || p.id === target) && p.status === "CONNECTED");
          if (matched) return matched;
        }
        if (service.providerId) {
          const matched = db.providers.find((p) => p.id === service.providerId && p.status === "CONNECTED");
          if (matched) return matched;
        }
      }
      const targetSlug = SERVICE_PROVIDER_MAP[codeUpper];
      if (targetSlug) {
        const matched = db.providers.find((p) => p.slug === targetSlug && p.status === "CONNECTED");
        if (matched) return matched;
        const matchedAnyStatus = db.providers.find((p) => p.slug === targetSlug);
        if (matchedAnyStatus) return matchedAnyStatus;
      }
    }
    return db.providers.find((p) => p.slug === "ninja" && p.status === "CONNECTED") || db.providers.find((p) => p.status === "CONNECTED") || db.providers[0] || null;
  }
  getActiveProvider(serviceCode) {
    return this.getProviderForService(serviceCode);
  }
  async testConnection(targetProviderIdOrSlug) {
    const db = getDb();
    let provider = null;
    if (targetProviderIdOrSlug) {
      provider = db.providers.find((p) => p.id === targetProviderIdOrSlug || p.slug === targetProviderIdOrSlug) || null;
    }
    if (!provider) {
      provider = this.getActiveProvider();
    }
    if (!provider) {
      return { success: false, message: "No verification provider configured in the system." };
    }
    const start = Date.now();
    try {
      if (provider.slug === "veripine") {
        const apiKey = getVeripineApiKey(provider);
        if (!apiKey) {
          return { success: false, message: "Veripine API credentials (VERIPINE_API_KEY / VERIPINE_SECRET_KEY) are missing." };
        }
        const baseUrl2 = getVeripineBaseUrl(provider);
        const res2 = await fetch(`${baseUrl2}/balance`, {
          method: "GET",
          headers: {
            "x-api-key": apiKey,
            "Authorization": `Bearer ${apiKey}`,
            "Accept": "application/json"
          },
          signal: AbortSignal.timeout(1e4)
        });
        const latencyMs2 = Date.now() - start;
        if (res2.ok) {
          const json = await res2.json().catch(() => ({}));
          const balanceNum = Number(json?.data?.balance ?? 0);
          const balance = json?.data?.formatted_balance || (json?.data?.balance !== void 0 ? `\u20A6${balanceNum.toLocaleString()}` : "Connected");
          const username = json?.data?.username || "Authenticated User";
          provider.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
          provider.status = "CONNECTED";
          provider.balance = balanceNum;
          if (balanceNum < 70) {
            return {
              success: false,
              message: `Connected to Veripine live gateway (${username}), but wallet balance is critically low (${balance}). Provider requires wallet funding to perform verifications.`,
              latencyMs: latencyMs2
            };
          }
          return {
            success: true,
            message: `Connected to Veripine live gateway successfully. Gateway Balance: ${balance} (${username}).`,
            latencyMs: latencyMs2
          };
        } else {
          return {
            success: false,
            message: `Veripine API returned HTTP ${res2.status}: ${res2.statusText || "Authentication failed"}. Please check your VERIPINE_API_KEY.`,
            latencyMs: latencyMs2
          };
        }
      }
      if (provider.slug === "ninja") {
        const secretKey = getNinjaSecretKey(provider) || getNinjaApiKey(provider);
        if (!secretKey) {
          return { success: false, message: "Ninja API credentials (NINJA_SECRET_KEY / NINJA_PUBLIC_KEY) are missing." };
        }
        const baseUrl2 = getNinjaBaseUrl(provider);
        const res2 = await fetch(`${baseUrl2}/api/wallet`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${secretKey}`,
            "Content-Type": "application/json"
          },
          signal: AbortSignal.timeout(1e4)
        });
        const latencyMs2 = Date.now() - start;
        if (res2.ok) {
          const json = await res2.json().catch(() => ({}));
          const balance = Array.isArray(json) && json[0]?.balance !== void 0 ? Number(json[0].balance) : Number(json.balance ?? 0);
          provider.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
          provider.status = "CONNECTED";
          provider.balance = balance;
          if (balance <= 0) {
            return {
              success: false,
              message: `Connected to Ninja API live gateway, but the provider account wallet balance is \u20A60.00 NGN. If you funded Ninja, please confirm that your current API keys in Admin match the funded account/business.`,
              latencyMs: latencyMs2
            };
          }
          return {
            success: true,
            message: `Connected to Ninja API live gateway successfully. Live Balance: \u20A6${balance.toLocaleString()} NGN.`,
            latencyMs: latencyMs2
          };
        } else {
          return {
            success: false,
            message: `Ninja API returned HTTP ${res2.status}: ${res2.statusText || "Authentication failed"}. Please check your Ninja API keys.`,
            latencyMs: latencyMs2
          };
        }
      }
      if (provider.slug === "paystack") {
        const secretKey = provider.secretKey || (process.env.PAYSTACK_SECRET_KEY || "").trim();
        if (!secretKey) {
          return { success: false, message: "Paystack LIVE Secret Key (PAYSTACK_SECRET_KEY) is not configured." };
        }
        const res2 = await fetch("https://api.paystack.co/balance", {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${secretKey}`,
            "Accept": "application/json"
          },
          signal: AbortSignal.timeout(1e4)
        });
        const latencyMs2 = Date.now() - start;
        if (res2.ok) {
          const json = await res2.json().catch(() => ({}));
          const balance = Array.isArray(json?.data) && json.data[0]?.balance !== void 0 ? Number(json.data[0].balance) / 100 : 0;
          provider.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
          provider.status = "CONNECTED";
          provider.balance = balance;
          return {
            success: true,
            message: `Connected to Paystack LIVE successfully. Live Balance: \u20A6${balance.toLocaleString()} NGN.`,
            latencyMs: latencyMs2
          };
        } else {
          return {
            success: false,
            message: `Paystack returned HTTP ${res2.status}: ${res2.statusText || "Authentication failed"}. Please check your Paystack Live Secret Key.`,
            latencyMs: latencyMs2
          };
        }
      }
      const baseUrl = (provider.baseUrl || "").replace(/\/$/, "");
      if (!baseUrl.startsWith("http")) {
        return { success: false, message: `${provider.name} baseUrl is invalid.` };
      }
      const res = await fetch(`${baseUrl}/ping`, {
        method: "GET",
        headers: {
          "x-api-key": provider.apiKey || "",
          "Authorization": `Bearer ${provider.secretKey || provider.apiKey || ""}`,
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(1e4)
      });
      const latencyMs = Date.now() - start;
      if (res.ok) {
        provider.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
        provider.status = "CONNECTED";
        return { success: true, message: `Connected to ${provider.name} successfully.`, latencyMs };
      } else {
        return {
          success: false,
          message: `${provider.name} returned HTTP ${res.status}: ${res.statusText}`,
          latencyMs
        };
      }
    } catch (err) {
      const isTimeout = err?.name === "TimeoutError" || err?.name === "AbortError";
      return {
        success: false,
        message: `${provider.name} connection test failed: ${isTimeout ? "Provider connection timed out." : err.message || "Network unreachable"}`
      };
    }
  }
  /**
   * Safe server-side diagnostic logging (NEVER logs API keys, secret credentials, or auth headers).
   */
  logDiagnostic(info) {
    if (info.isBalanceError || info.httpStatus && info.httpStatus >= 400) {
      console.warn(
        `[Verification Gateway Alert] Provider: ${info.provider} | Service: ${info.service} | Endpoint: ${info.endpoint} | HTTP: ${info.httpStatus ?? "N/A"} | Status: ${info.errorCode ?? info.rawType ?? "N/A"} | Msg: "${info.errorMessage ?? "N/A"}"`
      );
    }
  }
  /**
   * Helper to detect if an external upstream API error is caused by the gateway provider's own balance exhaustion.
   * Only classifies as insufficient balance when explicitly stated by provider or HTTP 402 Payment Required.
   * Never misclassifies 400, 401, 403, 404, 500, 503, invalid data, or generic messages as balance errors.
   */
  isUpstreamBalanceError(msg, status) {
    if (status === 402) return true;
    if (!msg || typeof msg !== "string") return false;
    const lower = msg.toLowerCase().trim();
    if (!lower) return false;
    return lower.includes("insufficient wallet balance") || lower.includes("insufficient balance") || lower.includes("insufficient wallet") || lower.includes("insufficient funds") || lower.includes("insufficient fund") || lower.includes("wallet balance is insufficient") || lower.includes("provider wallet balance") || lower.includes("credit exhausted") || lower.includes("credits exhausted") || lower.includes("low wallet balance") || lower.includes("balance depleted") || lower.includes("please fund your wallet") || lower.includes("fund your wallet to continue");
  }
  /**
   * Universal External API Caller with strictly enforced 2-minute timeout & structured response states:
   * A. SUCCESS (actual result returned)
   * B. API ERROR / PROVIDER ERROR (with preserved sanitized feedback)
   * C. TIMEOUT (2 minutes elapsed without response)
   * D. NETWORK / CONNECTION ERROR (DNS, connection, SSL, socket drop)
   * E. UNEXPECTED SYSTEM ERROR (runtime processing error)
   *
   * Automatically clears timeout countdown immediately if response arrives early.
   * Redacts sensitive API keys and authorization tokens.
   */
  async callApi(options) {
    const startTime = Date.now();
    const timeoutMs = options.customTimeoutMs || getServiceTimeoutMs(options.serviceCode);
    console.log(
      `[API_REQUEST_STARTED] Service: ${options.serviceCode} | Provider: ${options.providerName} | URL: ${options.url} | MaxTimeout: ${timeoutMs}ms | Timestamp: ${(/* @__PURE__ */ new Date()).toISOString()}`
    );
    const controller = new AbortController();
    let isTimedOut = false;
    let isSettled = false;
    const timer = setTimeout(() => {
      if (!isSettled) {
        isTimedOut = true;
        controller.abort();
      }
    }, timeoutMs);
    console.log(
      `[API_PROVIDER_CALLED] Service: ${options.serviceCode} | Provider: ${options.providerName} | Calling upstream provider API...`
    );
    try {
      const response = await fetch(options.url, {
        method: options.method || "GET",
        headers: options.headers,
        body: options.body ? typeof options.body === "string" ? options.body : JSON.stringify(options.body) : void 0,
        signal: controller.signal,
        keepalive: true
      });
      clearTimeout(timer);
      isSettled = true;
      const durationMs = Date.now() - startTime;
      console.log(
        `[API_RESPONSE_RECEIVED] Service: ${options.serviceCode} | Provider: ${options.providerName} | HTTP: ${response.status} | Duration: ${durationMs}ms`
      );
      const rawJson = await response.json().catch(() => null);
      const sanitized = sanitizeProviderResponse(rawJson);
      const isBalErr = this.isUpstreamBalanceError(rawJson?.message, response.status);
      if (isBalErr || response.status === 402) {
        console.warn(
          `[API_PROVIDER_ERROR] Service: ${options.serviceCode} | Provider: ${options.providerName} | Balance Insufficient | HTTP: ${response.status} | Duration: ${durationMs}ms`
        );
        return {
          success: false,
          status: "api_error",
          httpStatus: response.status,
          json: rawJson,
          message: "Verification gateway provider wallet balance is insufficient. Please contact system administrator to fund the verification gateway.",
          providerResponse: sanitized,
          durationMs
        };
      }
      if (!response.ok) {
        const rawErrMsg = rawJson?.message || rawJson?.error || rawJson?.notice?.message || `Request failed with HTTP status ${response.status}`;
        console.warn(
          `[API_PROVIDER_ERROR] Service: ${options.serviceCode} | Provider: ${options.providerName} | HTTP: ${response.status} | Error: ${rawErrMsg} | Duration: ${durationMs}ms`
        );
        let userMsg = rawErrMsg;
        if (response.status === 401 || response.status === 403) {
          userMsg = "Verification gateway authorization error. Please check provider credentials.";
        } else if (response.status === 404) {
          userMsg = rawJson?.message || "No matching identity record found in the national registry database.";
        } else if (response.status === 409) {
          userMsg = rawJson?.message || "Conflicting or duplicate request on registry gateway.";
        } else if (response.status === 422 || response.status === 400) {
          userMsg = rawJson?.message || rawJson?.error || `Invalid verification details submitted (HTTP ${response.status}).`;
        } else if (response.status === 429) {
          userMsg = "National registry query rate limit reached. Please wait a moment and try again.";
        } else if (response.status === 502 || response.status === 503 || response.status === 504) {
          userMsg = "National identity registry is temporarily unavailable. Please try again shortly.";
        } else if (response.status >= 500) {
          userMsg = rawJson?.message || `Registry gateway server error (HTTP ${response.status}).`;
        }
        console.log(`[API_REQUEST_COMPLETED] Service: ${options.serviceCode} | Status: api_error | Duration: ${durationMs}ms`);
        return {
          success: false,
          status: "api_error",
          httpStatus: response.status,
          json: rawJson,
          message: userMsg,
          providerResponse: sanitized,
          durationMs
        };
      }
      if (rawJson && (rawJson.status === "not_found" || rawJson.found === false || rawJson.status === false)) {
        const notFoundMsg = rawJson.message || rawJson.error || "No matching identity record found in the national registry.";
        console.log(`[API_REQUEST_COMPLETED] Service: ${options.serviceCode} | Status: api_error (Not Found) | Duration: ${durationMs}ms`);
        return {
          success: false,
          status: "api_error",
          httpStatus: response.status,
          json: rawJson,
          message: notFoundMsg,
          providerResponse: sanitized,
          durationMs
        };
      }
      console.log(`[API_REQUEST_COMPLETED] Service: ${options.serviceCode} | Status: success | Duration: ${durationMs}ms`);
      return {
        success: true,
        status: "success",
        httpStatus: response.status,
        json: rawJson,
        message: "Verification completed successfully.",
        providerResponse: sanitized,
        durationMs
      };
    } catch (err) {
      clearTimeout(timer);
      isSettled = true;
      const durationMs = Date.now() - startTime;
      if (isTimedOut || err?.name === "TimeoutError" || err?.name === "AbortError" || err?.message?.toLowerCase().includes("timed out")) {
        console.error(
          `[API_TIMEOUT] Service: ${options.serviceCode} | Provider: ${options.providerName} | Request timed out after ${durationMs}ms (Limit: ${timeoutMs}ms)`
        );
        console.log(`[API_REQUEST_COMPLETED] Service: ${options.serviceCode} | Status: timeout | Duration: ${durationMs}ms`);
        return {
          success: false,
          status: "timeout",
          json: null,
          message: "API request timed out. The national registry gateway did not respond within the 2-minute waiting window.",
          providerResponse: null,
          durationMs
        };
      }
      const isNetwork = err?.name === "TypeError" || err?.code === "ECONNREFUSED" || err?.code === "ENOTFOUND" || err?.code === "ECONNRESET" || err?.code === "ETIMEDOUT" || err?.code === "EHOSTUNREACH" || err?.message?.includes("fetch failed") || err?.message?.includes("network") || err?.message?.includes("socket") || err?.message?.includes("getaddrinfo");
      if (isNetwork) {
        console.error(
          `[API_NETWORK_ERROR] Service: ${options.serviceCode} | Provider: ${options.providerName} | Error: ${err?.message || "Network unreachable"} | Duration: ${durationMs}ms`
        );
        console.log(`[API_REQUEST_COMPLETED] Service: ${options.serviceCode} | Status: network_error | Duration: ${durationMs}ms`);
        return {
          success: false,
          status: "network_error",
          json: null,
          message: `Network connection error: Unable to reach verification gateway (${err?.message || "connectivity failed"}).`,
          providerResponse: null,
          durationMs
        };
      }
      console.error(
        `[API_UNEXPECTED_ERROR] Service: ${options.serviceCode} | Provider: ${options.providerName} | Error: ${err?.message || "Unknown error"} | Duration: ${durationMs}ms`
      );
      console.log(`[API_REQUEST_COMPLETED] Service: ${options.serviceCode} | Status: system_error | Duration: ${durationMs}ms`);
      return {
        success: false,
        status: "system_error",
        json: null,
        message: `An unexpected system error occurred while processing the verification request: ${err?.message || "Unknown error"}.`,
        providerResponse: null,
        durationMs
      };
    }
  }
  // =========================================================================
  // 1. NIN VERIFICATION (NINJA ONLY)
  // =========================================================================
  async verifyNIN(nin, extras) {
    const designatedProvider = this.getActiveProvider("NIN");
    const cleanNin = (nin || "").toString().replace(/\D/g, "").trim();
    if (!cleanNin || cleanNin.length !== 11) {
      return {
        success: false,
        status: "api_error",
        message: "A valid 11-digit National Identity Number (NIN) is required.",
        providerName: designatedProvider?.name || "Ninja Identity Gateway"
      };
    }
    const ninjaProv = this.getProviderForService("NIN") || designatedProvider;
    const ninjaKey = getNinjaSecretKey(ninjaProv) || getNinjaApiKey(ninjaProv);
    if (!ninjaKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Ninja API gateway credentials are not configured on the server. Please configure NINJA_SECRET_KEY or NINJA_PUBLIC_KEY.",
        providerName: ninjaProv?.name || "Ninja Identity Gateway"
      };
    }
    const baseUrl = getNinjaBaseUrl(ninjaProv);
    const endpoint = "/api/identity/identify";
    const ref = `nin_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const apiRes = await this.callApi({
      serviceCode: "NIN",
      providerName: ninjaProv?.name || "Ninja Identity Gateway",
      url: `${baseUrl}${endpoint}`,
      method: "POST",
      headers: {
        "Authorization": `Bearer ${ninjaKey}`,
        "Content-Type": "application/json"
      },
      body: {
        idType: "nin",
        mode: "lookup",
        idNumber: cleanNin,
        reference: ref
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: ninjaProv?.name || "Ninja Identity Gateway"
      };
    }
    const json = apiRes.json;
    const d = json.data || json;
    const returnedNin = String(d?.id_number || d?.nin || cleanNin).trim();
    const firstName = String(d?.first_name || d?.firstname || d?.firstName || d?.["first-name"] || "").trim();
    const middleName = String(d?.middle_name || d?.middlename || d?.middleName || d?.["middle-name"] || "").trim();
    const surname = String(d?.last_name || d?.surname || d?.lastname || d?.lastName || d?.["last-name"] || "").trim();
    const fullName = firstName || surname ? [d?.title, firstName, middleName, surname].filter(Boolean).join(" ") : String(d?.fullname || d?.full_name || d?.fullName || d?.name || "").trim();
    const dateOfBirth = String(d?.date_of_birth || d?.dob || d?.dateOfBirth || d?.birthdate || d?.birth_date || "").trim();
    if (!returnedNin && !fullName && !firstName && !surname && !dateOfBirth && !d?.mobile && !d?.phone) {
      return {
        success: false,
        status: "api_error",
        message: "National identity registry returned an incomplete or unverified record.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: ninjaProv?.name || "Ninja Identity Gateway"
      };
    }
    let photoUrl = null;
    const rawImg = d?.photoUrl || d?.photo_url || d?.image || d?.photo;
    if (rawImg && typeof rawImg === "string" && rawImg.trim()) {
      const trimmed = rawImg.trim();
      photoUrl = trimmed.startsWith("data:") || trimmed.startsWith("http") ? trimmed : `data:image/jpeg;base64,${trimmed}`;
    }
    const fullAddress = [d.address_line, d.address_town, d.address_lga, d.address_state].filter(Boolean).join(", ") || d.address || d.residence_address || "";
    const canonicalData = {
      verified: true,
      firstName,
      middleName,
      surname,
      fullName,
      dateOfBirth,
      photoUrl,
      nin: returnedNin,
      phone: d.mobile || d.phone || d.telephoneno || d.telecomNumber || null,
      address: fullAddress || null,
      gender: d.gender ? String(d.gender).toUpperCase() : null,
      trackingId: d.id || d.trackingId || d.tracking_id || null,
      stateOfOrigin: d.address_state || d.state_of_origin || d.state || null,
      lgaOfOrigin: d.address_lga || d.lga_of_origin || d.lga || null,
      telecomNumber: d.mobile || d.phone || d.telephoneno || d.telecomNumber || null,
      residenceAddress: fullAddress || null,
      status: "VERIFIED",
      rawResponse: json
    };
    return {
      success: true,
      status: "success",
      data: canonicalData,
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: ninjaProv?.name || "Ninja Identity Gateway"
    };
  }
  // =========================================================================
  // 2. BVN VERIFICATION (NINJA ONLY)
  // =========================================================================
  async verifyBVN(bvn, extras) {
    const designatedProvider = this.getActiveProvider("BVN");
    const cleanBvn = (bvn || "").toString().replace(/\D/g, "").trim();
    if (!cleanBvn || cleanBvn.length !== 11) {
      return {
        success: false,
        status: "api_error",
        message: "A valid 11-digit Bank Verification Number (BVN) is required.",
        providerName: designatedProvider?.name || "Ninja Identity Gateway"
      };
    }
    const ninjaProv = this.getProviderForService("BVN") || designatedProvider;
    const ninjaKey = getNinjaSecretKey(ninjaProv) || getNinjaApiKey(ninjaProv);
    if (!ninjaKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Ninja API gateway credentials are not configured on the server. Please configure NINJA_SECRET_KEY or NINJA_PUBLIC_KEY.",
        providerName: ninjaProv?.name || "Ninja Identity Gateway"
      };
    }
    const baseUrl = getNinjaBaseUrl(ninjaProv);
    const endpoint = "/api/identity/identify";
    const ref = `bvn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const apiRes = await this.callApi({
      serviceCode: "BVN",
      providerName: ninjaProv?.name || "Ninja Identity Gateway",
      url: `${baseUrl}${endpoint}`,
      method: "POST",
      headers: {
        "Authorization": `Bearer ${ninjaKey}`,
        "Content-Type": "application/json"
      },
      body: {
        idType: "bvn",
        mode: "lookup",
        idNumber: cleanBvn,
        reference: ref
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: ninjaProv?.name || "Ninja Identity Gateway"
      };
    }
    const json = apiRes.json;
    const d = json.data || json;
    const returnedBvn = String(d?.id_number || d?.bvn || cleanBvn).trim();
    const pFirstName = (d?.first_name || d?.firstname || "").toString().trim();
    const pMiddleName = (d?.middle_name || d?.middlename || "").toString().trim();
    const pSurname = (d?.last_name || d?.surname || "").toString().trim();
    const fullName = pFirstName || pSurname ? [d?.title, pFirstName, pMiddleName, pSurname].filter(Boolean).join(" ") : d?.fullname || d?.full_name || d?.name || "";
    if (!returnedBvn && !fullName && !pFirstName && !pSurname && !d?.date_of_birth && !d?.dob) {
      return {
        success: false,
        status: "api_error",
        message: "Banking directory returned an incomplete or unverified record.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: ninjaProv?.name || "Ninja Identity Gateway"
      };
    }
    let photoUrl = void 0;
    const rawImg = d.image || d.photo;
    if (rawImg) {
      photoUrl = rawImg.startsWith("data:") || rawImg.startsWith("http") ? rawImg : `data:image/jpeg;base64,${rawImg}`;
    }
    const fullAddress = [d.address_line, d.address_town, d.address_lga, d.address_state].filter(Boolean).join(", ") || d.address || d.residence_address || "";
    return {
      success: true,
      status: "success",
      data: {
        bvn: returnedBvn || void 0,
        fullName,
        firstName: pFirstName,
        middleName: pMiddleName,
        surname: pSurname,
        dateOfBirth: d.date_of_birth || d.dob || "",
        gender: d.gender ? String(d.gender).toUpperCase() : "",
        phoneNumber: d.mobile || d.phone || d.telephoneno || "",
        email: d.email || "",
        residenceAddress: fullAddress,
        stateOfOrigin: d.address_state || d.state_of_origin || d.state || "",
        lgaOfOrigin: d.address_lga || d.lga_of_origin || d.lga || "",
        photoUrl,
        trackingId: d.id || d.trackingId || d.tracking_id || "",
        status: "VERIFIED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: ninjaProv?.name || "Ninja Identity Gateway"
    };
  }
  // =========================================================================
  // 3. PHONE NUMBER VERIFICATION
  // =========================================================================
  async verifyPhone(phone, extras) {
    const provider = this.getActiveProvider("PHONE") || this.getActiveProvider("NIN_PHONE");
    let rawPhone = (phone || (extras?.phoneNumber || extras?.number || "")).toString().trim();
    let cleanPhone = rawPhone.replace(/\D/g, "");
    if (cleanPhone.startsWith("234") && cleanPhone.length === 13) {
      cleanPhone = "0" + cleanPhone.slice(3);
    } else if (cleanPhone.length === 10 && !cleanPhone.startsWith("0")) {
      cleanPhone = "0" + cleanPhone;
    }
    if (cleanPhone.length !== 11) {
      return {
        success: false,
        status: "api_error",
        message: "Invalid phone format. Phone number must be exactly 11 digits (e.g. 08012345678).",
        providerName: provider?.name || "Telecom Verification Gateway"
      };
    }
    const apiKey = getVeripineApiKey(provider);
    if (!apiKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Phone verification provider credentials are not configured (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "PHONE",
      providerName: provider?.name || "Veripine API Gateway",
      url: `${baseUrl}/nin-phone`,
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: {
        phone: cleanPhone,
        consent: true
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const json = apiRes.json;
    let d = json.data || json;
    if (d && typeof d === "object" && d.data && typeof d.data === "object") {
      d = d.data;
    }
    if (!d || typeof d === "object" && Object.keys(d).length === 0) {
      return {
        success: false,
        status: "api_error",
        message: json.message || "No linked identity record found for this phone number.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const rawPhoto = d.photo || d.photoUrl || d.image;
    const photoUrl = rawPhoto ? rawPhoto.startsWith("http") || rawPhoto.startsWith("data:") ? rawPhoto : `data:image/jpeg;base64,${rawPhoto}` : void 0;
    const firstName = (d.firstname || d.firstName || d.first_name || "").toString().trim();
    const middleName = (d.middlename || d.middleName || d.middle_name || "").toString().trim();
    const surname = (d.surname || d.lastName || d.lastname || d.last_name || "").toString().trim();
    const fullName = [firstName, middleName, surname].filter(Boolean).join(" ") || (d.fullName || d.name || "").toString().trim();
    const returnedNin = String(d.nin || d.id_number || "").trim();
    const returnedPhone = String(d.phone || d.telephoneno || d.mobile || "").trim();
    if (!returnedNin && !fullName && !firstName && !surname) {
      return {
        success: false,
        status: "api_error",
        message: "National identity registry returned an incomplete record with no verified name or NIN.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const fullAddress = [d.residence_address || d.address, d.residence_town || d.town, d.residence_lga || d.birthlga || d.lga, d.residence_state || d.birthstate || d.state].filter(Boolean).join(", ") || d.residence_address || d.address || "";
    return {
      success: true,
      status: "success",
      data: {
        phoneNumber: returnedPhone || void 0,
        nin: returnedNin || void 0,
        fullName,
        firstName,
        surname,
        middleName,
        gender: (d.gender || "").toUpperCase(),
        dateOfBirth: d.birthdate || d.dob || d.date_of_birth || "",
        trackingId: d.trackingId || d.tracking_id || "",
        residenceAddress: fullAddress,
        stateOfOrigin: d.birthstate || d.state_of_origin || d.state || "",
        lgaOfOrigin: d.birthlga || d.lga_of_origin || d.lga || "",
        photoUrl,
        status: "VERIFIED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Veripine API Gateway"
    };
  }
  // =========================================================================
  // 4. NIN PHONE SEARCH
  // =========================================================================
  async verifyNinPhoneSearch(searchData) {
    const provider = this.getActiveProvider("NIN_PHONE");
    const rawPhone = (searchData.phone || searchData.phoneNumber || searchData.number || "").toString().trim();
    let cleanPhone = rawPhone.replace(/\D/g, "");
    if (cleanPhone.startsWith("234") && cleanPhone.length === 13) {
      cleanPhone = "0" + cleanPhone.slice(3);
    } else if (cleanPhone.length === 10 && !cleanPhone.startsWith("0")) {
      cleanPhone = "0" + cleanPhone;
    }
    if (cleanPhone.length !== 11) {
      return {
        success: false,
        status: "api_error",
        message: "A valid 11-digit registered mobile phone number is required (e.g. 08012345678).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const apiKey = getVeripineApiKey(provider);
    if (!apiKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "NIN Phone Search provider credentials are not configured (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "NIN_PHONE",
      providerName: provider?.name || "Veripine API Gateway",
      url: `${baseUrl}/nin-phone`,
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: {
        phone: cleanPhone,
        consent: true
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const json = apiRes.json;
    let d = json.data || json;
    if (d && typeof d === "object" && d.data && typeof d.data === "object") {
      d = d.data;
    }
    if (!d || typeof d === "object" && Object.keys(d).length === 0) {
      return {
        success: false,
        status: "api_error",
        message: json.message || "No linked NIN record found for this phone number.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const rawPhoto = d.photo || d.photoUrl || d.image;
    const photoUrl = rawPhoto ? rawPhoto.startsWith("http") || rawPhoto.startsWith("data:") ? rawPhoto : `data:image/jpeg;base64,${rawPhoto}` : void 0;
    const firstName = (d.firstname || d.firstName || d.first_name || "").toString().trim();
    const middleName = (d.middlename || d.middleName || d.middle_name || "").toString().trim();
    const surname = (d.surname || d.lastName || d.lastname || d.last_name || "").toString().trim();
    const fullName = [firstName, middleName, surname].filter(Boolean).join(" ") || (d.fullName || d.name || "").toString().trim();
    const returnedNin = String(d.nin || d.id_number || "").trim();
    const returnedPhone = String(d.phone || d.telephoneno || d.mobile || "").trim();
    if (!returnedNin && !fullName && !firstName && !surname) {
      return {
        success: false,
        status: "api_error",
        message: "National identity registry returned an incomplete record with no verified name or NIN.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const fullAddress = [d.residence_address || d.address, d.residence_town || d.town, d.residence_lga || d.birthlga || d.lga, d.residence_state || d.birthstate || d.state].filter(Boolean).join(", ") || d.residence_address || d.address || "";
    return {
      success: true,
      status: "success",
      data: {
        nin: returnedNin || void 0,
        fullName,
        firstName,
        surname,
        middleName,
        phoneNumber: returnedPhone || void 0,
        gender: (d.gender || "").toUpperCase(),
        dateOfBirth: d.birthdate || d.dob || d.date_of_birth || "",
        trackingId: d.trackingId || d.tracking_id || "",
        residenceAddress: fullAddress,
        stateOfOrigin: d.birthstate || d.state_of_origin || d.state || "",
        lgaOfOrigin: d.birthlga || d.lga_of_origin || d.lga || "",
        photoUrl,
        status: "VERIFIED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Veripine API Gateway"
    };
  }
  // =========================================================================
  // 5. BVN RETRIEVAL BY PHONE
  // =========================================================================
  async verifyBvnRetrieval(searchData) {
    const provider = this.getActiveProvider("BVN_RETRIEVAL");
    const rawPhone = (searchData.phone || searchData.phoneNumber || searchData.number || "").toString().trim();
    let cleanPhone = rawPhone.replace(/\D/g, "");
    if (cleanPhone.startsWith("234") && cleanPhone.length === 13) {
      cleanPhone = "0" + cleanPhone.slice(3);
    } else if (cleanPhone.length === 10 && !cleanPhone.startsWith("0")) {
      cleanPhone = "0" + cleanPhone;
    }
    if (cleanPhone.length !== 11) {
      return {
        success: false,
        status: "api_error",
        message: "A valid 11-digit registered mobile phone number is required for BVN Retrieval (e.g. 08012345678).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const apiKey = getVeripineApiKey(provider);
    if (!apiKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "BVN Retrieval provider credentials are not configured (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "BVN_RETRIEVAL",
      providerName: provider?.name || "Veripine API Gateway",
      url: `${baseUrl}/bvn-phone`,
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: {
        phone: cleanPhone,
        consent: true
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const json = apiRes.json;
    let d = json.data || json;
    if (d && typeof d === "object" && d.data && typeof d.data === "object") {
      d = d.data;
    }
    if (!d || typeof d === "object" && Object.keys(d).length === 0) {
      return {
        success: false,
        status: "api_error",
        message: json.message || "No matching BVN record found for this phone number.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const firstName = (d.firstname || d.firstName || d.first_name || "").toString().trim();
    const middleName = (d.middlename || d.middleName || d.middle_name || "").toString().trim();
    const surname = (d.surname || d.lastName || d.lastname || d.last_name || "").toString().trim();
    const fullName = [firstName, middleName, surname].filter(Boolean).join(" ") || (d.fullName || d.name || "").toString().trim();
    const returnedBvn = String(d.bvn || d.id_number || "").trim();
    const returnedPhone = String(d.phone || d.phoneNumber || d.telephoneno || d.mobile || "").trim();
    if (!returnedBvn && !fullName && !firstName && !surname) {
      return {
        success: false,
        status: "api_error",
        message: "Banking directory returned an incomplete record with no verified name or BVN.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const rawPhoto = d.photo || d.photoUrl || d.image;
    const photoUrl = rawPhoto ? rawPhoto.startsWith("http") || rawPhoto.startsWith("data:") ? rawPhoto : `data:image/jpeg;base64,${rawPhoto}` : void 0;
    const fullAddress = [d.residence_address || d.address || d.residentialAddress, d.residence_town || d.town, d.residence_lga || d.lga, d.residence_state || d.state].filter(Boolean).join(", ") || d.residence_address || d.address || d.residentialAddress || "";
    return {
      success: true,
      status: "success",
      data: {
        bvn: returnedBvn || void 0,
        fullName,
        firstName,
        surname,
        middleName,
        phoneNumber: returnedPhone || void 0,
        dateOfBirth: d.birthdate || d.dob || d.dateOfBirth || "",
        gender: (d.gender || "").toUpperCase(),
        residenceAddress: fullAddress,
        photoUrl,
        retrievalReference: (d.retrievalReference || d.reference || "").toString().trim() || void 0,
        status: "VERIFIED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Veripine API Gateway"
    };
  }
  // =========================================================================
  // 6. DEMOGRAPHIC VERIFICATION
  // =========================================================================
  async verifyDemographicVerification(searchData) {
    const provider = this.getActiveProvider("DEMOGRAPHIC_VERIFICATION") || this.getActiveProvider("NIN_PHONE");
    const firstName = (searchData.firstName || searchData.firstname || "").toString().trim();
    const lastName = (searchData.lastName || searchData.lastname || searchData.surname || "").toString().trim();
    const rawGender = (searchData.gender || "").toString().trim().toLowerCase();
    const gender = rawGender === "female" || rawGender === "f" ? "female" : "male";
    let dob = (searchData.dob || searchData.dateOfBirth || "").toString().trim();
    if (!firstName || !lastName || !dob) {
      return {
        success: false,
        status: "api_error",
        message: "First name, last name, and date of birth are all required for demographic verification.",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    if (dob.includes("/") || dob.includes("-")) {
      const parts = dob.split(/[\/\-]/);
      if (parts[0].length === 2 && parts[2]?.length === 4) {
        dob = `${parts[2]}-${parts[1].padStart(2, "0")}-${parts[0].padStart(2, "0")}`;
      }
    }
    const apiKey = getVeripineApiKey(provider);
    if (!apiKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Demographic verification provider credentials are not configured (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "DEMOGRAPHIC_VERIFICATION",
      providerName: provider?.name || "Veripine API Gateway",
      url: `${baseUrl}/nin-demography`,
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: {
        firstname: firstName,
        lastname: lastName,
        gender,
        dob,
        consent: true
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const json = apiRes.json;
    let d = json.data || json;
    if (d && typeof d === "object" && d.data && typeof d.data === "object") {
      d = d.data;
    }
    if (!d || typeof d === "object" && Object.keys(d).length === 0) {
      return {
        success: false,
        status: "api_error",
        message: json.message || "No matching demographic record found in national registry.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const rawPhoto = d.photo || d.photoUrl || d.image;
    const photoUrl = rawPhoto ? rawPhoto.startsWith("http") || rawPhoto.startsWith("data:") ? rawPhoto : `data:image/jpeg;base64,${rawPhoto}` : void 0;
    const rawSig = d.signature;
    const signature = rawSig ? rawSig.startsWith("data:") || rawSig.startsWith("http") ? rawSig : `data:image/png;base64,${rawSig}` : void 0;
    const verifiedFirstName = (d.firstname || d.firstName || d.first_name || "").toString().trim();
    const verifiedMiddleName = (d.middlename || d.middleName || d.middle_name || "").toString().trim();
    const verifiedSurname = (d.surname || d.lastName || d.lastname || d.last_name || "").toString().trim();
    const verifiedFullName = (verifiedFirstName || verifiedSurname ? [verifiedFirstName, verifiedMiddleName, verifiedSurname].filter(Boolean).join(" ") : d.fullName || d.fullname || d.name || "").toString().trim();
    const verifiedNin = (d.nin || d.id_number || "").toString().trim();
    const verifiedDob = (d.birthdate || d.dob || d.date_of_birth || d.dateOfBirth || "").toString().trim();
    const verifiedGender = (d.gender ? String(d.gender).toUpperCase() : "").trim();
    if (!verifiedNin && !verifiedFullName && !d.photo && !d.image) {
      return {
        success: false,
        status: "api_error",
        message: "National identity registry returned insufficient or empty demographic match data.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const fullAddress = [d.residence_address || d.address, d.residence_town || d.town, d.residence_lga || d.birthlga || d.lga, d.residence_state || d.birthstate || d.state].filter(Boolean).join(", ") || d.residence_address || d.address || "";
    return {
      success: true,
      status: "success",
      data: {
        nin: verifiedNin || void 0,
        fullName: verifiedFullName,
        firstName: verifiedFirstName,
        surname: verifiedSurname,
        middleName: verifiedMiddleName,
        gender: verifiedGender,
        dateOfBirth: verifiedDob,
        phoneNumber: (d.phone || d.telephoneno || d.mobile || "").toString().trim(),
        trackingId: (d.trackingId || d.tracking_id || "").toString().trim(),
        residenceAddress: fullAddress,
        stateOfOrigin: (d.birthstate || d.state_of_origin || d.state || "").toString().trim(),
        lgaOfOrigin: (d.birthlga || d.lga_of_origin || d.lga || "").toString().trim(),
        photoUrl,
        signature,
        status: "VERIFIED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Veripine API Gateway"
    };
  }
  // =========================================================================
  // 7. PERSONALIZATION (NIN TRACKING ID)
  // =========================================================================
  async verifyPersonalization(searchData) {
    const provider = this.getActiveProvider("PERSONALIZATION");
    const apiKey = getVeripineApiKey(provider);
    const trackingId = (searchData.trackingId || searchData.tracking_id || searchData.trackingNo || searchData.searchQuery || "").toString().trim();
    if (!trackingId) {
      return {
        success: false,
        status: "api_error",
        message: "NIMC tracking ID is required for personalization slip retrieval.",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    if (!apiKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Personalization slip provider credentials are not configured (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "PERSONALIZATION",
      providerName: provider?.name || "Veripine API Gateway",
      url: `${baseUrl}/nin-tracking`,
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: {
        tracking_id: trackingId,
        consent: true
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const json = apiRes.json;
    let d = json.data || json;
    if (d && typeof d === "object" && d.data && typeof d.data === "object") {
      d = d.data;
    }
    if (!d || typeof d === "object" && Object.keys(d).length === 0) {
      return {
        success: false,
        status: "api_error",
        message: json.message || "No tracking record found for this tracking ID.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const rawPhoto = d.photo || d.photoUrl || d.image;
    const photoUrl = rawPhoto ? rawPhoto.startsWith("http") || rawPhoto.startsWith("data:") ? rawPhoto : `data:image/jpeg;base64,${rawPhoto}` : void 0;
    const firstName = (d.firstname || d.firstName || d.first_name || "").toString().trim();
    const middleName = (d.middlename || d.middleName || d.middle_name || "").toString().trim();
    const surname = (d.surname || d.lastName || d.lastname || d.last_name || "").toString().trim();
    const fullName = [firstName, middleName, surname].filter(Boolean).join(" ") || (d.fullName || d.name || "").toString().trim();
    const returnedNin = String(d.nin || d.id_number || "").trim();
    const returnedTracking = String(d.trackingId || d.tracking_id || "").trim();
    if (!returnedNin && !fullName && !returnedTracking) {
      return {
        success: false,
        status: "api_error",
        message: "Tracking record returned incomplete or unverified data from registry.",
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    return {
      success: true,
      status: "success",
      data: {
        nin: returnedNin || void 0,
        fullName,
        firstName,
        surname,
        middleName,
        trackingId: returnedTracking || void 0,
        dateOfBirth: (d.dob || d.birthdate || "").toString().trim(),
        gender: (d.gender || "").toString().toUpperCase(),
        phoneNumber: (d.phone || d.telephoneno || "").toString().trim(),
        residenceAddress: (d.residence_address || d.address || "").toString().trim(),
        photoUrl,
        status: "RETRIEVED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Veripine API Gateway"
    };
  }
  // =========================================================================
  // 8. NIN VALIDATION
  // =========================================================================
  async verifyNinValidation(nin, trackingId, extras) {
    const provider = this.getActiveProvider("NIN_VALIDATION");
    const veripineKey = getVeripineApiKey(provider);
    if (!veripineKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Veripine verification gateway is not configured with an API key (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "NIN_VALIDATION",
      providerName: provider?.name || "Veripine API Gateway",
      url: `${baseUrl}/nin-modification`,
      method: "POST",
      headers: {
        "x-api-key": veripineKey,
        "Authorization": `Bearer ${veripineKey}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: {
        service_type: "nin_validation",
        nin,
        dob: extras?.dob || trackingId,
        consent: true
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        data: null,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        rawHttpStatus: apiRes.httpStatus,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const json = apiRes.json;
    let d = json.data || json;
    if (d && typeof d === "object" && d.data && typeof d.data === "object") {
      d = d.data;
    }
    return {
      success: true,
      status: "success",
      data: {
        nin: String(d.nin || d.id_number || "").trim(),
        validationStatus: "VALID_AND_ACTIVE",
        referenceId: json.reference_id || d.reference_id,
        details: d,
        status: "VERIFIED"
      },
      message: "Verification completed successfully.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      rawHttpStatus: apiRes.httpStatus,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Veripine API Gateway"
    };
  }
  // =========================================================================
  // 9. IDENTITY CROSS LOOKUP (Veripine ONLY - No fallback)
  // =========================================================================
  async lookupIdentity(query, extras) {
    const provider = this.getActiveProvider("IDENTITY_CROSS_LOOKUP") || this.getActiveProvider("IDENTITY_LOOKUP");
    const apiKey = getVeripineApiKey(provider);
    if (!apiKey) {
      return {
        success: false,
        unconfigured: true,
        message: "Veripine verification gateway is not configured with an API key (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const cleaned = (query || extras?.searchQuery || extras?.phone || extras?.trackingId || extras?.nin || "").toString().trim();
    if (!cleaned && (!extras || Object.keys(extras).length === 0)) {
      return {
        success: false,
        message: "Search identifier (NIN, Phone Number, or Tracking ID) is required for Identity Cross Lookup.",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    const baseUrl = getVeripineBaseUrl(provider);
    try {
      const cleanDigits = cleaned.replace(/\D/g, "");
      const isTrackingId = /^[A-Za-z0-9]{12,24}$/i.test(cleaned) && !/^\d+$/.test(cleaned) || !!extras?.tracking_id || !!extras?.trackingId;
      const isPhone = cleanDigits.length === 11 && cleanDigits.startsWith("0") || !!extras?.phone;
      if (isTrackingId || extras?.tracking_id || extras?.trackingId) {
        const trackingId = (extras?.tracking_id || extras?.trackingId || cleaned).toString().trim();
        const apiRes2 = await this.callApi({
          serviceCode: "IDENTITY_CROSS_LOOKUP",
          providerName: provider?.name || "Veripine API Gateway",
          url: `${baseUrl}/nin-tracking`,
          method: "POST",
          headers: {
            "x-api-key": apiKey,
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: {
            tracking_id: trackingId,
            consent: true
          }
        });
        if (!apiRes2.success || !apiRes2.json) {
          return {
            success: false,
            status: apiRes2.status,
            message: apiRes2.message,
            providerResponse: apiRes2.providerResponse,
            rawResponse: apiRes2.json,
            durationMs: apiRes2.durationMs,
            providerName: provider?.name || "Veripine API Gateway"
          };
        }
        const json = apiRes2.json;
        let d2 = json.data || json;
        if (d2 && typeof d2 === "object" && d2.data && typeof d2.data === "object") d2 = d2.data;
        if (d2 && (d2.nin || d2.firstname || d2.fullName || d2.surname || d2.tracking_id || d2.trackingId)) {
          const res = this.formatVeripineCrossResult(d2, json, provider?.name || "Veripine API Gateway");
          res.status = "success";
          res.providerResponse = apiRes2.providerResponse;
          res.durationMs = apiRes2.durationMs;
          return res;
        }
      }
      if (isPhone || cleanDigits.length === 11) {
        const phoneToQuery = extras?.phone ? String(extras.phone).replace(/\D/g, "") : cleanDigits;
        const apiRes2 = await this.callApi({
          serviceCode: "IDENTITY_CROSS_LOOKUP",
          providerName: provider?.name || "Veripine API Gateway",
          url: `${baseUrl}/nin-phone`,
          method: "POST",
          headers: {
            "x-api-key": apiKey,
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: {
            phone: phoneToQuery,
            consent: true
          }
        });
        if (!apiRes2.success || !apiRes2.json) {
          return {
            success: false,
            status: apiRes2.status,
            message: apiRes2.message,
            providerResponse: apiRes2.providerResponse,
            rawResponse: apiRes2.json,
            durationMs: apiRes2.durationMs,
            providerName: provider?.name || "Veripine API Gateway"
          };
        }
        const json = apiRes2.json;
        let d2 = json.data || json;
        if (d2 && typeof d2 === "object" && d2.data && typeof d2.data === "object") d2 = d2.data;
        if (d2 && (d2.nin || d2.firstname || d2.fullName || d2.surname || d2.phone)) {
          const res = this.formatVeripineCrossResult(d2, json, provider?.name || "Veripine API Gateway");
          res.status = "success";
          res.providerResponse = apiRes2.providerResponse;
          res.durationMs = apiRes2.durationMs;
          return res;
        }
        return {
          success: false,
          status: "api_error",
          message: json?.message || `No linked identity record found for phone/NIN (${phoneToQuery}) on Veripine gateway.`,
          providerName: provider?.name || "Veripine API Gateway",
          providerResponse: apiRes2.providerResponse,
          rawResponse: json,
          durationMs: apiRes2.durationMs
        };
      }
      if (extras?.firstname && extras?.surname) {
        const apiRes2 = await this.callApi({
          serviceCode: "IDENTITY_CROSS_LOOKUP",
          providerName: provider?.name || "Veripine API Gateway",
          url: `${baseUrl}/nin-demography`,
          method: "POST",
          headers: {
            "x-api-key": apiKey,
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: {
            firstname: extras.firstname,
            surname: extras.surname,
            dob: extras.dob || extras.dateOfBirth,
            gender: extras.gender,
            state: extras.state,
            lga: extras.lga,
            consent: true
          }
        });
        if (!apiRes2.success || !apiRes2.json) {
          return {
            success: false,
            status: apiRes2.status,
            message: apiRes2.message,
            providerResponse: apiRes2.providerResponse,
            rawResponse: apiRes2.json,
            durationMs: apiRes2.durationMs,
            providerName: provider?.name || "Veripine API Gateway"
          };
        }
        const json = apiRes2.json;
        let d2 = json.data || json;
        if (d2 && typeof d2 === "object" && d2.data && typeof d2.data === "object") d2 = d2.data;
        if (d2 && (d2.nin || d2.firstname || d2.fullName || d2.surname)) {
          const res = this.formatVeripineCrossResult(d2, json, provider?.name || "Veripine API Gateway");
          res.status = "success";
          res.providerResponse = apiRes2.providerResponse;
          res.durationMs = apiRes2.durationMs;
          return res;
        }
      }
      const apiRes = await this.callApi({
        serviceCode: "IDENTITY_CROSS_LOOKUP",
        providerName: provider?.name || "Veripine API Gateway",
        url: `${baseUrl}/nin-tracking`,
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: {
          tracking_id: cleaned,
          consent: true
        }
      });
      if (!apiRes.success || !apiRes.json) {
        return {
          success: false,
          status: apiRes.status,
          message: apiRes.message,
          providerResponse: apiRes.providerResponse,
          rawResponse: apiRes.json,
          durationMs: apiRes.durationMs,
          providerName: provider?.name || "Veripine API Gateway"
        };
      }
      const trackingJson = apiRes.json;
      let d = trackingJson.data || trackingJson;
      if (d && typeof d === "object" && d.data && typeof d.data === "object") d = d.data;
      if (d && (d.nin || d.firstname || d.fullName || d.surname || d.tracking_id || d.trackingId)) {
        const res = this.formatVeripineCrossResult(d, trackingJson, provider?.name || "Veripine API Gateway");
        res.status = "success";
        res.providerResponse = apiRes.providerResponse;
        res.durationMs = apiRes.durationMs;
        return res;
      }
      return {
        success: false,
        status: "api_error",
        message: trackingJson?.message || `No matching identity record found for query (${cleaned}) on Veripine gateway. Please verify your input.`,
        providerName: provider?.name || "Veripine API Gateway",
        providerResponse: apiRes.providerResponse,
        rawResponse: trackingJson,
        durationMs: apiRes.durationMs
      };
    } catch (err) {
      return {
        success: false,
        status: "system_error",
        message: "Veripine Identity Cross Lookup service encountered an unexpected error. Please try again.",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
  }
  formatVeripineCrossResult(d, rawJson, providerName) {
    const rawPhoto = d.photo || d.photoUrl || d.image;
    const photoUrl = rawPhoto ? rawPhoto.startsWith("http") || rawPhoto.startsWith("data:") ? rawPhoto : `data:image/jpeg;base64,${rawPhoto}` : void 0;
    const firstName = (d.firstname || d.firstName || d.first_name || "").toString().trim();
    const middleName = (d.middlename || d.middleName || d.middle_name || "").toString().trim();
    const surname = (d.surname || d.lastName || d.lastname || d.last_name || "").toString().trim();
    const fullName = [firstName, middleName, surname].filter(Boolean).join(" ") || (d.fullName || d.name || "").toString().trim();
    const returnedNin = String(d.nin || d.id_number || d.vnin || "").trim();
    const returnedPhone = String(d.phone || d.telephoneno || d.mobile || "").trim();
    const returnedTracking = String(d.trackingId || d.tracking_id || "").trim();
    const fullAddress = [
      d.residence_address || d.address,
      d.residence_town || d.town,
      d.residence_lga || d.birthlga || d.lga,
      d.residence_state || d.birthstate || d.state
    ].filter(Boolean).join(", ") || d.residence_address || d.address || "";
    return {
      success: true,
      providerName,
      rawResponse: rawJson,
      data: {
        nin: returnedNin || void 0,
        phoneNumber: returnedPhone || void 0,
        fullName,
        firstName,
        surname,
        middleName,
        gender: (d.gender || "").toUpperCase(),
        dateOfBirth: (d.birthdate || d.dob || d.date_of_birth || "").toString().trim(),
        trackingId: returnedTracking || void 0,
        residenceAddress: fullAddress,
        stateOfOrigin: (d.birthstate || d.state_of_origin || d.self_origin_state || d.state || "").toString().trim(),
        lgaOfOrigin: (d.birthlga || d.lga_of_origin || d.self_origin_lga || d.lga || "").toString().trim(),
        religion: (d.religion || "").toString().trim(),
        maritalStatus: (d.maritalstatus || "").toString().trim(),
        employmentStatus: (d.employmentstatus || "").toString().trim(),
        photoUrl,
        status: "VERIFIED"
      }
    };
  }
  // =========================================================================
  // 10. DRIVERS LICENSE
  // =========================================================================
  async verifyDriversLicense(licenseNumber, dob) {
    const provider = this.getActiveProvider("DRIVERS_LICENSE");
    const secretKey = getNinjaSecretKey(provider) || getNinjaApiKey(provider);
    if (!secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "FRSC driver license gateway credentials are not configured.",
        providerName: provider?.name || "Ninja API"
      };
    }
    const baseUrl = getNinjaBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "DRIVERS_LICENSE",
      providerName: provider?.name || "Ninja API",
      url: `${baseUrl}/api/identity/identify`,
      method: "POST",
      headers: {
        "Authorization": `Bearer ${secretKey}`,
        "Content-Type": "application/json"
      },
      body: {
        idType: "drivers_license",
        mode: "lookup",
        idNumber: licenseNumber,
        dob,
        reference: `frsc_${Date.now()}`
      }
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Ninja API"
      };
    }
    const json = apiRes.json;
    if (json && json.data) {
      return {
        success: true,
        status: "success",
        providerName: provider?.name || "Ninja API",
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        data: json.data
      };
    }
    return {
      success: false,
      status: "api_error",
      message: json?.message || "Driver license could not be verified with FRSC.",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      providerName: provider?.name || "Ninja API"
    };
  }
  // =========================================================================
  // 11. NIN MODIFICATION
  // =========================================================================
  async verifyNinModification(searchData) {
    const provider = this.getActiveProvider("NIN_MODIFICATION");
    const apiKey = getVeripineApiKey(provider);
    if (!apiKey) {
      return {
        success: false,
        unconfigured: true,
        message: "Veripine API verification gateway is not configured with an API key (VERIPINE_API_KEY).",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
    let serviceType = "nin_name_modification";
    const modType = (searchData.modificationType || searchData.serviceType || searchData.service_type || "").toLowerCase();
    if (modType.includes("phone")) {
      serviceType = "nin_phone_modification";
    } else if (modType.includes("address")) {
      serviceType = "nin_address_modification";
    } else if (modType.includes("validation")) {
      serviceType = "nin_validation";
    }
    try {
      const baseUrl = getVeripineBaseUrl(provider);
      const payload = {
        service_type: serviceType,
        nin: searchData.nin,
        consent: true
      };
      if (serviceType === "nin_name_modification") {
        payload.surname = searchData.currentSurname || searchData.surname;
        payload.firstname = searchData.currentFirstName || searchData.firstName;
        payload.new_surname = searchData.newSurname || searchData.new_surname || searchData.surname;
        payload.new_firstname = searchData.newFirstName || searchData.new_firstname || searchData.firstName;
        if (searchData.phone) payload.phone = searchData.phone;
      } else if (serviceType === "nin_phone_modification") {
        payload.phone = searchData.currentPhone || searchData.phone;
        payload.new_phone = searchData.newPhone || searchData.new_phone;
      } else if (serviceType === "nin_address_modification") {
        payload.address = searchData.currentAddress || searchData.address;
        payload.new_address = searchData.newAddress || searchData.new_address;
      } else if (serviceType === "nin_validation") {
        if (searchData.dob) payload.dob = searchData.dob;
      }
      const apiRes = await this.callApi({
        serviceCode: "NIN_MODIFICATION",
        providerName: provider?.name || "Veripine API Gateway",
        url: `${baseUrl}/nin-modification`,
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: payload
      });
      if (!apiRes.success || !apiRes.json) {
        return {
          success: false,
          status: apiRes.status,
          message: apiRes.message,
          providerResponse: apiRes.providerResponse,
          rawResponse: apiRes.json,
          durationMs: apiRes.durationMs,
          providerName: provider?.name || "Veripine API Gateway"
        };
      }
      const json = apiRes.json;
      if (json.status !== "success") {
        return {
          success: false,
          status: "api_error",
          message: json?.message || "NIN Modification submission was rejected by the registry.",
          providerResponse: apiRes.providerResponse,
          rawResponse: json,
          durationMs: apiRes.durationMs,
          providerName: provider?.name || "Veripine API Gateway"
        };
      }
      const d = json.data || json;
      return {
        success: true,
        status: "success",
        providerName: provider?.name || "Veripine API Gateway",
        providerResponse: apiRes.providerResponse,
        rawResponse: json,
        durationMs: apiRes.durationMs,
        data: {
          status: "SUBMITTED",
          serviceType,
          orderId: d.order_id || json.order_id,
          referenceId: d.reference_id || json.reference_id,
          message: json.message || "NIN modification order placed successfully.",
          details: d
        }
      };
    } catch {
      return {
        success: false,
        status: "system_error",
        message: "NIN Modification service encountered an unexpected error.",
        providerName: provider?.name || "Veripine API Gateway"
      };
    }
  }
  // =========================================================================
  // 12. BIRTH ATTESTATION
  // =========================================================================
  async verifyBirthAttestation(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Birth Attestation API provider is not yet configured.",
        providerName: provider?.name || "NPC Provider"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "BIRTH_ATTESTATION",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/npc/birth-attestation/process`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  // =========================================================================
  // 13. BVN CRM
  // =========================================================================
  async verifyBvnCrm(searchData) {
    const provider = this.getActiveProvider("BVN_CRM");
    const secretKey = getNinjaSecretKey(provider) || getNinjaApiKey(provider);
    if (!secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Ninja API (BVN by CRM) verification gateway is not configured.",
        providerName: provider?.name || "Ninja API"
      };
    }
    const baseUrl = getNinjaBaseUrl(provider);
    const apiRes = await this.callApi({
      serviceCode: "BVN_CRM",
      providerName: provider?.name || "Ninja API",
      url: `${baseUrl}/api/v1/banking/bvn/crm-lookup`,
      method: "POST",
      headers: {
        "Authorization": `Bearer ${secretKey}`,
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider?.name || "Ninja API"
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider?.name || "Ninja API",
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  // =========================================================================
  // 14. BVN MODIFICATION
  // =========================================================================
  async verifyBvnModification(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "BVN Modification API provider is not yet configured.",
        providerName: provider?.name || "NIBSS Clearing House"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "BVN_MODIFICATION",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/banking/bvn/modification/submit`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  // =========================================================================
  // 15. IPE CLEARANCE & MODIFICATION
  // =========================================================================
  async verifyIpeClearance(searchData) {
    const provider = this.getActiveProvider("IPE_CLEARANCE");
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "Identity Clearance verification gateway is not configured.",
        providerName: provider?.name || "Identity Clearance Gateway"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "IPE_CLEARANCE",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/identity/ipe/clearance`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  async verifyIpeModification(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "IPE Modification API provider is not yet configured.",
        providerName: provider?.name || "Unconfigured Provider"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "IPE_MODIFICATION",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/identity/ipe/modification`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  // =========================================================================
  // 16. NIN DELINKING & BVN ANDROID USER
  // =========================================================================
  async verifyNinDelinking(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "NIN Delinking API provider is not yet configured.",
        providerName: provider?.name || "NCC/NIMC Gateway"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "NIN_DELINKING",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/nimc/delinking/execute`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  async verifyBvnAndroidUser(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "BVN Android User agent approval API is not yet configured.",
        providerName: provider?.name || "NIBSS Agent Gateway"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "BVN_ANDROID_USER",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/banking/bvn/android-agent/register`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  // =========================================================================
  // 17. CAC & TIN VERIFICATION
  // =========================================================================
  async verifyCacTin(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "CAC & TIN integration provider is not yet configured.",
        providerName: provider?.name || "CAC Gateway"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "CAC_TIN",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/corporate/cac-tin/process`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  async verifyTin(searchData) {
    const provider = this.getActiveProvider();
    if (!provider || !provider.apiKey && !provider.secretKey) {
      return {
        success: false,
        status: "api_error",
        unconfigured: true,
        message: "TIN verification and issuance API is not yet configured.",
        providerName: provider?.name || "FIRS / JTB Gateway"
      };
    }
    const apiRes = await this.callApi({
      serviceCode: "TIN",
      providerName: provider.name,
      url: `${provider.baseUrl}/api/v1/tax/tin/lookup`,
      method: "POST",
      headers: {
        "x-api-key": provider.apiKey || "",
        "app-id": provider.secretKey || "",
        "Content-Type": "application/json"
      },
      body: searchData
    });
    if (!apiRes.success || !apiRes.json) {
      return {
        success: false,
        status: apiRes.status,
        message: apiRes.message,
        providerResponse: apiRes.providerResponse,
        rawResponse: apiRes.json,
        durationMs: apiRes.durationMs,
        providerName: provider.name
      };
    }
    const json = apiRes.json;
    return {
      success: true,
      status: "success",
      providerName: provider.name,
      providerResponse: apiRes.providerResponse,
      rawResponse: json,
      durationMs: apiRes.durationMs,
      data: json.data || json
    };
  }
  // =========================================================================
  // DISPATCHER: Enforce Strict Routing Policies
  // - default: Multi-gateway auto routing (can use any gateway)
  // - ninja: Strict Ninja Identity Gateway ONLY (no other gateway)
  // - veripine: Strict Veripine Gateway ONLY (no other gateway)
  // - admin: Strict Admin Gateway (routed for manual administrator processing)
  // =========================================================================
  async executeService(serviceCode, searchData) {
    const code = (serviceCode || "").toUpperCase();
    const db = getDb();
    const serviceRecord = db.services?.find((s) => s.code.toUpperCase() === code || s.id === serviceCode);
    const configuredProvider = (serviceRecord?.defaultProvider || "default").toLowerCase().trim();
    if (configuredProvider === "admin" || configuredProvider === "admin_gateway" || configuredProvider === "manual") {
      return {
        success: false,
        unconfigured: false,
        apiCallState: "api_not_called",
        apiCalled: false,
        apiResponseReceived: false,
        message: "This service is configured on Admin Gateway and will be processed manually by Administrators.",
        providerName: "Admin Gateway"
      };
    }
    if (configuredProvider === "ninja") {
      const ninjaProv = this.getProviderForService(code) || db.providers.find((p) => p.slug === "ninja");
      const ninjaKey = getNinjaSecretKey(ninjaProv) || getNinjaApiKey(ninjaProv);
      if (!ninjaKey) {
        return {
          success: false,
          unconfigured: true,
          apiCallState: "api_not_called",
          apiCalled: false,
          apiResponseReceived: false,
          message: "Ninja API gateway credentials are not configured on the server.",
          providerName: "Ninja Identity Gateway"
        };
      }
      let res2;
      if (code === "NIN" || code.startsWith("NIN_") || code === "NIN_VERIFICATION" || code === "NIN_LOOKUP") {
        res2 = await this.verifyNIN(searchData.nin || Object.values(searchData)[0], searchData);
      } else if (code === "BVN" || code.startsWith("BVN_") || code === "BVN_VERIFICATION") {
        if (code === "BVN_CRM" || code === "BVN_BY_CRM") {
          res2 = await this.verifyBvnCrm(searchData);
        } else {
          res2 = await this.verifyBVN(searchData.bvn || Object.values(searchData)[0], searchData);
        }
      } else if (code === "DRIVERS_LICENSE" || code === "DRIVING_LICENCE" || code === "DRIVING_LICENCE_VERIFICATION") {
        res2 = await this.verifyDriversLicense(searchData.licenseNumber || searchData.license_number, searchData.dob || searchData.dateOfBirth);
      } else {
        const queryVal = searchData.nin || searchData.bvn || searchData.searchQuery || searchData.phone || Object.values(searchData)[0];
        res2 = await this.verifyNIN(queryVal, searchData);
      }
      if (!res2.apiCallState) {
        res2.apiCallState = res2.unconfigured ? "api_not_called" : "api_called_response_received";
        res2.apiCalled = !res2.unconfigured;
        res2.apiResponseReceived = !res2.unconfigured;
      }
      return res2;
    }
    if (configuredProvider === "veripine") {
      const veripineProv = this.getProviderForService(code) || db.providers.find((p) => p.slug === "veripine");
      const veripineKey = getVeripineApiKey(veripineProv);
      if (!veripineKey) {
        return {
          success: false,
          unconfigured: true,
          apiCallState: "api_not_called",
          apiCalled: false,
          apiResponseReceived: false,
          message: "Veripine API gateway credentials are not configured (VERIPINE_API_KEY).",
          providerName: "Veripine API Gateway"
        };
      }
      let res2;
      if (code === "PHONE" || code === "PHONE_NUMBER_VERIFICATION" || code === "PHONE_VERIFICATION") {
        res2 = await this.verifyPhone(searchData.phone || searchData.phoneNumber || searchData.number, searchData);
      } else if (code === "NIN_PHONE" || code === "NIN_PHONE_SEARCH") {
        res2 = await this.verifyNinPhoneSearch(searchData);
      } else if (code === "BVN_RETRIEVAL" || code === "BVN_PHONE") {
        res2 = await this.verifyBvnRetrieval(searchData);
      } else if (code === "PERSONALIZATION" || code === "NIN_TRACKING") {
        res2 = await this.verifyPersonalization(searchData);
      } else if (code === "NIN_VALIDATION") {
        res2 = await this.verifyNinValidation(searchData.nin, searchData.trackingId || searchData.dob, searchData);
      } else if (code === "DEMOGRAPHIC_VERIFICATION" || code === "DEMOGRAPHIC" || code === "DEMOGRAPHIC_SEARCH") {
        res2 = await this.verifyDemographicVerification(searchData);
      } else if (code.includes("MODIFICATION")) {
        res2 = await this.verifyNinModification(searchData);
      } else {
        res2 = await this.lookupIdentity(searchData.searchQuery || searchData.phone || searchData.nin || Object.values(searchData)[0] || "", searchData);
      }
      if (!res2.apiCallState) {
        res2.apiCallState = res2.unconfigured ? "api_not_called" : "api_called_response_received";
        res2.apiCalled = !res2.unconfigured;
        res2.apiResponseReceived = !res2.unconfigured;
      }
      return res2;
    }
    const targetProvider = SERVICE_PROVIDER_MAP[code] || "ninja";
    if (targetProvider === "ninja") {
      const ninjaProv = this.getProviderForService(code) || db.providers.find((p) => p.slug === "ninja");
      const ninjaKey = getNinjaSecretKey(ninjaProv) || getNinjaApiKey(ninjaProv);
      if (!ninjaKey) {
        return {
          success: false,
          unconfigured: true,
          apiCallState: "api_not_called",
          apiCalled: false,
          apiResponseReceived: false,
          message: "Ninja API gateway credentials are not configured on the server.",
          providerName: "Ninja Identity Gateway"
        };
      }
    } else if (targetProvider === "veripine") {
      const veripineProv = this.getProviderForService(code) || db.providers.find((p) => p.slug === "veripine");
      const veripineKey = getVeripineApiKey(veripineProv);
      if (!veripineKey) {
        return {
          success: false,
          unconfigured: true,
          apiCallState: "api_not_called",
          apiCalled: false,
          apiResponseReceived: false,
          message: "Veripine API gateway credentials are not configured (VERIPINE_API_KEY).",
          providerName: "Veripine API Gateway"
        };
      }
    }
    let res;
    switch (code) {
      // Ninja Handled Services
      case "NIN":
      case "NIN_VERIFICATION":
      case "NIN_LOOKUP":
      case "NIN_STATUS":
      case "NIN_STATUS_LOOKUP":
      case "NIN_VERIFICATION_STATUS_LOOKUP":
        res = await this.verifyNIN(searchData.nin, searchData);
        break;
      case "BVN":
      case "BVN_VERIFICATION":
        res = await this.verifyBVN(searchData.bvn, searchData);
        break;
      case "IDENTITY_LOOKUP":
      case "IDENTITY_CROSS_LOOKUP":
        res = await this.lookupIdentity(searchData.searchQuery || searchData.phone || searchData.nin || searchData.trackingId || searchData.tracking_id || Object.values(searchData)[0], searchData);
        break;
      case "DRIVERS_LICENSE":
      case "DRIVING_LICENCE":
      case "DRIVING_LICENCE_VERIFICATION":
        res = await this.verifyDriversLicense(searchData.licenseNumber || searchData.license_number, searchData.dob || searchData.dateOfBirth);
        break;
      case "BVN_CRM":
      case "BVN_BY_CRM":
        res = await this.verifyBvnCrm(searchData);
        break;
      // Veripine Handled Services
      case "NIN_PHONE":
      case "NIN_PHONE_SEARCH":
        res = await this.verifyNinPhoneSearch(searchData);
        break;
      case "BVN_RETRIEVAL":
      case "BVN_PHONE":
        res = await this.verifyBvnRetrieval(searchData);
        break;
      case "PERSONALIZATION":
      case "NIN_TRACKING":
        res = await this.verifyPersonalization(searchData);
        break;
      case "NIN_VALIDATION":
        res = await this.verifyNinValidation(searchData.nin, searchData.trackingId || searchData.dob, searchData);
        break;
      case "NIN_MODIFICATION":
      case "NIN_NAME_MOD":
      case "NAME_MODIFICATION":
      case "NIN_PHONE_MOD":
      case "PHONE_NUMBER_MODIFICATION":
      case "NIN_ADDRESS_MOD":
      case "ADDRESS_MODIFICATION":
        res = await this.verifyNinModification(searchData);
        break;
      // Telecom & Clearance Handled Services
      case "PHONE":
      case "PHONE_NUMBER_VERIFICATION":
      case "PHONE_VERIFICATION":
        res = await this.verifyPhone(searchData.phone || searchData.phoneNumber || searchData.number, searchData);
        break;
      case "IPE_CLEARANCE":
        res = await this.verifyIpeClearance(searchData);
        break;
      // Other platform services
      case "DEMOGRAPHIC_VERIFICATION":
      case "DEMOGRAPHIC":
      case "DEMOGRAPHIC_SEARCH":
        res = await this.verifyDemographicVerification(searchData);
        break;
      case "BIRTH_ATTESTATION":
        res = await this.verifyBirthAttestation(searchData);
        break;
      case "BVN_MODIFICATION":
        res = await this.verifyBvnModification(searchData);
        break;
      case "IPE_MODIFICATION":
        res = await this.verifyIpeModification(searchData);
        break;
      case "NIN_DELINKING":
        res = await this.verifyNinDelinking(searchData);
        break;
      case "BVN_ANDROID_USER":
        res = await this.verifyBvnAndroidUser(searchData);
        break;
      case "CAC_TIN":
        res = await this.verifyCacTin(searchData);
        break;
      case "TIN":
        res = await this.verifyTin(searchData);
        break;
      default:
        res = await this.lookupIdentity(Object.values(searchData)[0] || "", searchData);
        break;
    }
    if (!res.apiCallState) {
      if (res.unconfigured) {
        res.apiCallState = "api_not_called";
        res.apiCalled = false;
        res.apiResponseReceived = false;
      } else if (res.message && (res.message.toLowerCase().includes("timed out") || res.message.toLowerCase().includes("unreachable") || res.message.toLowerCase().includes("gateway is temporarily unavailable")) && !res.rawResponse) {
        res.apiCallState = "api_call_failed_before_response";
        res.apiCalled = true;
        res.apiResponseReceived = false;
      } else {
        res.apiCallState = "api_called_response_received";
        res.apiCalled = true;
        res.apiResponseReceived = true;
      }
    }
    return res;
  }
};
var providerAdapter = new EnterpriseProviderAdapter();

// server/api.ts
var apiRouter = import_express.default.Router();
apiRouter.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }
  next();
});
apiRouter.use(import_express.default.json({
  limit: "100mb",
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
apiRouter.use(import_express.default.urlencoded({ limit: "100mb", extended: true }));
function generateToken(userId) {
  const payload = { userId, exp: Date.now() + 7 * 24 * 60 * 60 * 1e3 };
  const str = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const secret = process.env.JWT_SECRET || "ugopawa_secure_identity_key_2026";
  const sig = import_crypto4.default.createHmac("sha256", secret).update(str).digest("base64url");
  return `${str}.${sig}`;
}
function verifyToken(tokenString) {
  try {
    const parts = tokenString.split(".");
    if (parts.length !== 2) return null;
    const [str, sig] = parts;
    const secret = process.env.JWT_SECRET || "ugopawa_secure_identity_key_2026";
    const expectedSig = import_crypto4.default.createHmac("sha256", secret).update(str).digest("base64url");
    if (sig !== expectedSig) return null;
    const payload = JSON.parse(Buffer.from(str, "base64url").toString("utf-8"));
    if (payload.exp < Date.now()) return null;
    return payload.userId;
  } catch {
    return null;
  }
}
async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Authentication required. Please log in." });
  }
  const token = authHeader.split(" ")[1];
  const userId = verifyToken(token);
  if (!userId) {
    return res.status(401).json({ error: "Session expired or invalid. Please log in again." });
  }
  const db = getDb();
  let user = db.users.find((u) => u.id === userId);
  if (!user) {
    const supaUser = await fetchSupabaseUserById(userId);
    if (supaUser) {
      user = supaUser;
      db.users.push(user);
    }
  } else {
    const supaUser = await fetchSupabaseUserById(userId);
    if (supaUser) {
      user.status = supaUser.status;
      user.role = supaUser.role;
    }
  }
  if (!user) {
    return res.status(401).json({ error: "User account not found." });
  }
  if (user.status === "PAUSED") {
    return res.status(403).json({ error: "Your account has been paused by the administrator. Please contact support." });
  }
  if (user.status === "SUSPENDED") {
    return res.status(403).json({ error: "Your account has been suspended. Please contact an administrator." });
  }
  req.user = user;
  next();
}
function requireMegaAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (!req.user || req.user.role !== "MEGA_ADMIN") {
      return res.status(403).json({ error: "Unauthorized. Mega Administrator (Owner) privileges required." });
    }
    next();
  });
}
function requireSuperAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (!req.user || req.user.role !== "MEGA_ADMIN" && req.user.role !== "SUPER_ADMIN") {
      return res.status(403).json({ error: "Unauthorized. Super Administrator privileges required." });
    }
    next();
  });
}
function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (!req.user || req.user.role !== "MEGA_ADMIN" && req.user.role !== "SUPER_ADMIN" && req.user.role !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized. Administrative access required." });
    }
    if (req.user.role === "ADMIN" && req.user.onboardingStatus !== "approved") {
      return res.status(403).json({ error: "Administrative access suspended pending completion and approval of one-time identity onboarding." });
    }
    next();
  });
}
apiRouter.get("/health", (req, res) => {
  res.json({ status: "healthy", platform: "UGOPAWAVERIFY", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
});
apiRouter.get("/supabase/status", async (req, res) => {
  const result = await testSupabaseConnection();
  res.json(result);
});
apiRouter.get("/settings/public", (req, res) => {
  const db = getDb();
  const s = db.settings;
  res.json({
    platformName: s.platformName,
    logoText: s.logoText,
    tagline: s.tagline,
    supportWhatsapp: s.supportWhatsapp,
    supportEmail: s.supportEmail,
    whatsappNumber: s.whatsappNumber || s.supportWhatsapp || "07071944789",
    phoneNumber1: s.phoneNumber1 || "07071944789",
    phoneNumber2: s.phoneNumber2 || "07018486189",
    businessEmail: s.businessEmail || s.supportEmail || "contact@ugopawaverify.com.ng",
    unitValueNgn: s.unitValueNgn || 200,
    currency: s.currency === "UNITS" ? "Credits" : s.currency || "Credits",
    currencySymbol: s.currencySymbol === "UNITS" ? "Credits" : s.currencySymbol || "Credits",
    minWalletFunding: s.minWalletFunding,
    maxWalletFunding: s.maxWalletFunding,
    maintenanceMode: s.maintenanceMode,
    bankDetails: s.bankDetails
  });
});
apiRouter.get("/stats/public", (req, res) => {
  const db = getDb();
  const totalUsers = db.users.length;
  const totalVerifications = db.verificationRequests.length;
  const successfulVerifications = db.verificationRequests.filter((r) => r.status === "SUCCESS").length;
  const successRate = totalVerifications > 0 ? Math.round(successfulVerifications / totalVerifications * 100) : 99.4;
  const activeServices = db.services.filter((s) => s.status === "ACTIVE").length;
  res.json({
    totalUsers: totalUsers > 0 ? totalUsers : "--",
    verificationsCompleted: totalVerifications > 0 ? totalVerifications : "--",
    successRate: totalVerifications > 0 ? `${successRate}%` : "--",
    servicesAvailable: activeServices > 0 ? activeServices : "--"
  });
});
apiRouter.get("/announcements/active", (req, res) => {
  const db = getDb();
  const active = db.announcements.filter((a) => a.isActive);
  res.json(active);
});
apiRouter.post("/auth/register", async (req, res) => {
  const { fullName, phone, username, email, password, confirmPassword, agreeTerms } = req.body;
  if (!fullName || !phone || !username || !email || !password) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ error: "Passwords do not match." });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }
  if (!agreeTerms) {
    return res.status(400).json({ error: "You must agree to the Terms and Conditions to proceed." });
  }
  const cleanEmail = email.toLowerCase().trim();
  const cleanUsername = username.toLowerCase().trim();
  const db = getDb();
  if (db.users.some((u) => u.email === cleanEmail)) {
    return res.status(400).json({ error: "An account with this email address already exists." });
  }
  if (db.users.some((u) => u.username === cleanUsername)) {
    return res.status(400).json({ error: "This username is already taken. Please choose another." });
  }
  const { hash: passwordHash, salt } = hashPassword(password);
  const supaAuthId = await createSupabaseAuthUser({
    email: cleanEmail,
    password,
    fullName: fullName.trim(),
    phone: phone.trim()
  });
  const userId = supaAuthId || `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const newUser = {
    id: userId,
    email: cleanEmail,
    username: cleanUsername,
    fullName: fullName.trim(),
    phone: phone.trim(),
    passwordHash,
    salt,
    transactionPinHash: "",
    pinSalt: "",
    role: "USER",
    // Standard rule: Public registrations always receive default USER role
    status: "ACTIVE",
    onboardingStatus: "not_started",
    assignedServices: [],
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  const newWallet = {
    id: `wal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    availableBalance: 0,
    pendingBalance: 0,
    totalDeposited: 0,
    totalSpent: 0,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.users.push(newUser);
  db.wallets.push(newWallet);
  db.profiles.push({
    userId,
    address: "",
    lastLoginAt: (/* @__PURE__ */ new Date()).toISOString(),
    lastLoginIp: req.ip || "127.0.0.1"
  });
  db.notifications.push({
    id: `notif_${Date.now()}`,
    userId,
    title: "Welcome to UGOPAWAVERIFY",
    message: "Your identity portal has been set up successfully. Fund your wallet to begin authenticating records.",
    type: "SECURITY",
    isRead: false,
    link: "/wallet/fund",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(newUser.fullName, newUser.role, "USER_REGISTERED", `New account created: ${newUser.email}`, userId, void 0, req.ip);
  saveDb();
  await saveUserToSupabase(newUser);
  await saveWalletToSupabase(newWallet);
  const token = generateToken(userId);
  res.status(201).json({
    token,
    user: {
      id: newUser.id,
      email: newUser.email,
      username: newUser.username,
      fullName: newUser.fullName,
      phone: newUser.phone,
      role: newUser.role,
      status: newUser.status
    }
  });
});
apiRouter.post("/auth/login", async (req, res) => {
  const { identifier, password } = req.body;
  if (!identifier || !password) {
    return res.status(400).json({ error: "Email/username and password are required." });
  }
  const rawId = String(identifier).trim();
  const clean = rawId.toLowerCase();
  const db = getDb();
  const isMegaAdminIdentifier = clean === "/mega//admin/ugopawaverify" || clean === "/mega/admin/ugopawaverify" || clean === "mega/admin/ugopawaverify" || clean === "ugopawaverify" || clean === "ugochukwuoparaocha3@gmail.com" || rawId === "/Mega//admin/ugopawaverify";
  let user = db.users.find((u) => {
    if (isMegaAdminIdentifier && u.role === "MEGA_ADMIN") return true;
    return u.email && u.email.toLowerCase() === clean || u.username && u.username.toLowerCase() === clean || u.username && u.username === rawId;
  });
  if (!user) {
    const supaUser2 = await fetchSupabaseUserByIdentifier(clean);
    if (supaUser2) {
      user = supaUser2;
      db.users.push(user);
    }
  }
  if (!user) {
    return res.status(401).json({ error: "Invalid email/username or password." });
  }
  const supaUser = await fetchSupabaseUserById(user.id);
  if (supaUser) {
    user.status = supaUser.status;
    user.role = supaUser.role;
    const idx = db.users.findIndex((u) => u.id === user.id);
    if (idx !== -1) {
      db.users[idx].status = supaUser.status;
      db.users[idx].role = supaUser.role;
    }
  }
  if (user.status === "SUSPENDED") {
    return res.status(403).json({ error: "Your account has been suspended. Please contact an administrator." });
  }
  const isValid = verifyPassword(String(password).trim(), user.passwordHash, user.salt);
  if (!isValid) {
    return res.status(401).json({ error: "Invalid email/username or password." });
  }
  const profile = db.profiles.find((p) => p.userId === user.id);
  if (profile) {
    profile.lastLoginAt = (/* @__PURE__ */ new Date()).toISOString();
    profile.lastLoginIp = req.ip || "127.0.0.1";
  }
  const auditAction = user.role === "MEGA_ADMIN" ? "MEGA_ADMIN_LOGIN" : "USER_LOGIN";
  logAudit(user.fullName, user.role, auditAction, `Logged in via IP ${req.ip || "unknown"}`, user.id, void 0, req.ip);
  saveDb();
  const token = generateToken(user.id);
  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      fullName: user.fullName,
      phone: user.phone,
      phone2: user.phone2,
      role: user.role,
      status: user.status,
      onboardingStatus: user.onboardingStatus || (user.role === "MEGA_ADMIN" ? "approved" : "not_started"),
      onboardingApprovedAt: user.onboardingApprovedAt,
      onboardingApprovedBy: user.onboardingApprovedBy,
      roleAtApproval: user.roleAtApproval,
      assignedServices: user.assignedServices || [],
      satisfactionTitle: user.satisfactionTitle,
      dob: user.dob,
      nin: user.nin,
      avatarUrl: user.avatarUrl || profile?.avatarUrl || "",
      verificationPinMode: user.verificationPinMode || "NONE"
    }
  });
});
apiRouter.post("/auth/mega-admin-login", async (req, res) => {
  const { identifier = "/Mega//admin/ugopawaverify", password } = req.body;
  if (!password) {
    return res.status(400).json({ error: "Mega Administrator password is required." });
  }
  const clean = String(identifier).trim().toLowerCase();
  const db = getDb();
  const megaAdmin = db.users.find(
    (u) => u.role === "MEGA_ADMIN" || u.email.toLowerCase() === "ugochukwuoparaocha3@gmail.com" || u.username === "/Mega//admin/ugopawaverify"
  );
  if (!megaAdmin) {
    return res.status(500).json({ error: "System error: Mega Administrator record is uninitialized." });
  }
  const isValid = verifyPassword(String(password).trim(), megaAdmin.passwordHash, megaAdmin.salt);
  if (!isValid) {
    logAudit("SYSTEM", "SECURITY", "MEGA_ADMIN_AUTH_FAILED", `Failed Mega Admin login attempt from IP ${req.ip || "unknown"}`, megaAdmin.id, void 0, req.ip);
    return res.status(401).json({ error: "Invalid Mega Administrator credentials." });
  }
  logAudit(megaAdmin.fullName, "MEGA_ADMIN", "MEGA_ADMIN_LOGIN", `Mega Admin logged in securely via dedicated gateway from IP ${req.ip || "unknown"}`, megaAdmin.id, void 0, req.ip);
  saveDb();
  const token = generateToken(megaAdmin.id);
  res.json({
    token,
    user: {
      id: megaAdmin.id,
      email: megaAdmin.email,
      username: megaAdmin.username,
      fullName: megaAdmin.fullName,
      phone: megaAdmin.phone,
      role: "MEGA_ADMIN",
      status: "ACTIVE",
      onboardingStatus: "approved",
      onboardingApprovedAt: megaAdmin.onboardingApprovedAt,
      onboardingApprovedBy: megaAdmin.onboardingApprovedBy,
      roleAtApproval: "MEGA_ADMIN",
      assignedServices: megaAdmin.assignedServices || ["ONLINE_NIN_REGISTRATION"],
      avatarUrl: megaAdmin.avatarUrl,
      createdAt: megaAdmin.createdAt
    }
  });
});
apiRouter.get("/auth/me", requireAuth, async (req, res) => {
  let user = req.user;
  const supaUser = await fetchSupabaseUserById(user.id);
  if (supaUser) {
    user = { ...user, ...supaUser };
    req.user = user;
    const db2 = getDb();
    const idx = db2.users.findIndex((u) => u.id === user.id);
    if (idx !== -1) db2.users[idx] = user;
  }
  const db = getDb();
  let wallet = await fetchSupabaseWalletByUserId(user.id);
  if (!wallet) {
    wallet = db.wallets.find((w) => w.userId === user.id) || {
      id: "",
      userId: user.id,
      availableBalance: 0,
      pendingBalance: 0,
      totalDeposited: 0,
      totalSpent: 0,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  const profile = db.profiles.find((p) => p.userId === user.id);
  const unreadCount = db.notifications.filter((n) => n.userId === user.id && !n.isRead).length;
  res.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      fullName: user.fullName,
      phone: user.phone,
      phone2: user.phone2,
      role: user.role,
      status: user.status,
      createdAt: user.createdAt,
      address: profile?.address || "",
      avatarUrl: user.avatarUrl || profile?.avatarUrl || "",
      verificationPinMode: user.verificationPinMode || "NONE",
      onboardingStatus: user.onboardingStatus || (user.role === "MEGA_ADMIN" ? "approved" : "not_started"),
      onboardingApprovedAt: user.onboardingApprovedAt,
      onboardingApprovedBy: user.onboardingApprovedBy,
      roleAtApproval: user.roleAtApproval,
      assignedServices: user.assignedServices || [],
      satisfactionTitle: user.satisfactionTitle,
      dob: user.dob,
      nin: user.nin
    },
    wallet,
    unreadNotifications: unreadCount
  });
});
apiRouter.post("/auth/change-password", requireAuth, (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: "Current password and new password are required." });
  }
  if (newPassword !== confirmPassword) {
    return res.status(400).json({ error: "New passwords do not match." });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters long." });
  }
  const user = req.user;
  if (!verifyPassword(currentPassword, user.passwordHash, user.salt)) {
    return res.status(400).json({ error: "Current password is incorrect." });
  }
  const { hash, salt } = hashPassword(newPassword);
  user.passwordHash = hash;
  user.salt = salt;
  user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  logAudit(user.fullName, user.role, "PASSWORD_CHANGED", "User successfully changed password", user.id, void 0, req.ip);
  saveDb();
  res.json({ success: true, message: "Password updated successfully." });
});
apiRouter.post("/auth/forgot-password", (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email address is required." });
  }
  res.json({
    success: true,
    message: "If an account exists with this email address, a password reset link has been dispatched."
  });
});
apiRouter.all(["/profile", "/auth/profile"], requireAuth, async (req, res) => {
  if (req.method !== "PUT" && req.method !== "PATCH" && req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { fullName, phone, address, avatarUrl, profilePictureUrl, verificationPinMode } = req.body;
  const user = req.user;
  const db = getDb();
  if (fullName !== void 0) user.fullName = String(fullName).trim();
  if (phone !== void 0) user.phone = String(phone).trim();
  const targetAvatar = avatarUrl !== void 0 ? avatarUrl : profilePictureUrl;
  if (targetAvatar !== void 0) {
    user.avatarUrl = String(targetAvatar).trim();
  }
  if (verificationPinMode !== void 0) {
    const cleanMode = String(verificationPinMode).trim().toUpperCase();
    if (cleanMode === "NONE" || cleanMode === "USE_PIN") {
      user.verificationPinMode = cleanMode;
    }
  }
  user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  let profile = db.profiles.find((p) => p.userId === user.id);
  if (!profile) {
    profile = { userId: user.id };
    db.profiles.push(profile);
  }
  if (address !== void 0) profile.address = String(address).trim();
  if (targetAvatar !== void 0) profile.avatarUrl = user.avatarUrl;
  logAudit(user.fullName, user.role, "PROFILE_UPDATED", "User updated account profile details", user.id, void 0, req.ip);
  saveDb();
  const saveRes = await saveUserToSupabase(user);
  if (!saveRes.success && isSupabaseServiceRoleActive()) {
    console.error(`[PROFILE_UPDATE_ERROR] Supabase update failed for ${user.email}:`, saveRes.error);
    return res.status(500).json({
      error: `Failed to update profile in authoritative Supabase database: ${saveRes.error || "Unknown error"}.`
    });
  }
  const supaUser = await fetchSupabaseUserById(user.id);
  const confirmedUser = supaUser || user;
  res.json({
    success: true,
    message: "Profile updated successfully.",
    user: {
      id: confirmedUser.id,
      email: confirmedUser.email,
      username: confirmedUser.username,
      fullName: confirmedUser.fullName,
      phone: confirmedUser.phone,
      address: profile.address || "",
      avatarUrl: confirmedUser.avatarUrl || "",
      verificationPinMode: user.verificationPinMode || "NONE",
      role: confirmedUser.role,
      status: confirmedUser.status
    }
  });
});
apiRouter.post(["/auth/profile-picture", "/user/profile-picture"], requireAuth, async (req, res) => {
  const { pictureData, avatarUrl } = req.body;
  const user = req.user;
  const db = getDb();
  const photoString = String(pictureData || avatarUrl || "").trim();
  if (!photoString) {
    return res.status(400).json({ error: "No image data provided. Please select a valid JPG or PNG image." });
  }
  if (!photoString.startsWith("data:image/") && !photoString.startsWith("http://") && !photoString.startsWith("https://") && !photoString.startsWith("/uploads/")) {
    return res.status(400).json({ error: "Invalid image format. Allowed formats: JPG, JPEG, PNG." });
  }
  let authoritativeUrl = photoString;
  if (photoString.startsWith("data:image/")) {
    try {
      const mimeMatch = photoString.match(/^data:image\/([a-zA-Z0-9+]+);base64,/);
      const rawExt = mimeMatch ? mimeMatch[1].toLowerCase() : "jpg";
      const ext = rawExt === "jpeg" ? "jpg" : rawExt;
      const base64Data = photoString.replace(/^data:image\/[a-zA-Z0-9+]+;base64,/, "");
      const buffer = Buffer.from(base64Data, "base64");
      const fileName = `avatar_${user.id}_${Date.now()}.${ext}`;
      const avatarsDir = import_path2.default.join(process.cwd(), "data", "uploads", "avatars");
      if (!import_fs2.default.existsSync(avatarsDir)) {
        import_fs2.default.mkdirSync(avatarsDir, { recursive: true });
      }
      const filePath = import_path2.default.join(avatarsDir, fileName);
      import_fs2.default.writeFileSync(filePath, buffer);
      authoritativeUrl = `/uploads/avatars/${fileName}`;
      if (isSupabaseServiceRoleActive()) {
        const storageRes = await uploadAvatarToSupabaseStorage(user.id, fileName, buffer, `image/${ext}`);
        if (!storageRes.success) {
          console.error("[PROFILE_PHOTO_ERROR] Supabase storage upload failed:", storageRes.error);
          return res.status(500).json({
            error: `Failed to upload profile picture to Supabase storage: ${storageRes.error}`
          });
        }
        if (storageRes.url) {
          authoritativeUrl = storageRes.url;
        }
      }
    } catch (e) {
      console.error("[PROFILE_PHOTO_ERROR] Failed to process avatar image:", e.message || e);
      return res.status(500).json({ error: `Image processing error: ${e.message || String(e)}` });
    }
  }
  user.avatarUrl = authoritativeUrl;
  user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  let profile = db.profiles.find((p) => p.userId === user.id);
  if (!profile) {
    profile = { userId: user.id };
    db.profiles.push(profile);
  }
  profile.avatarUrl = authoritativeUrl;
  logAudit(user.fullName, user.role, "PROFILE_PICTURE_UPDATED", "User updated profile avatar photo", user.id, void 0, req.ip);
  saveDb();
  const avatarRes = await updateUserAvatarInSupabase(user.id, user.avatarUrl);
  if (!avatarRes.success && isSupabaseServiceRoleActive()) {
    console.error("[PROFILE_PHOTO_ERROR] Supabase avatar update failed:", avatarRes.error);
    return res.status(500).json({ error: `Failed to persist avatar in Supabase database: ${avatarRes.error}` });
  }
  const saveRes = await saveUserToSupabase(user);
  if (!saveRes.success && isSupabaseServiceRoleActive()) {
    console.error("[PROFILE_PHOTO_ERROR] Supabase saveUser failed:", saveRes.error);
    return res.status(500).json({ error: `Failed to persist user profile in Supabase database: ${saveRes.error}` });
  }
  const reloaded = await fetchSupabaseUserById(user.id);
  const finalAvatar = reloaded?.avatarUrl || user.avatarUrl;
  res.json({
    success: true,
    message: "Profile picture saved successfully.",
    avatarUrl: finalAvatar
  });
});
apiRouter.delete(["/auth/profile-picture", "/user/profile-picture"], requireAuth, async (req, res) => {
  const user = req.user;
  const db = getDb();
  user.avatarUrl = "";
  user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  let profile = db.profiles.find((p) => p.userId === user.id);
  if (profile) {
    profile.avatarUrl = "";
  }
  logAudit(user.fullName, user.role, "PROFILE_PICTURE_REMOVED", "User removed profile avatar photo", user.id, void 0, req.ip);
  saveDb();
  const avatarRes = await updateUserAvatarInSupabase(user.id, "");
  if (!avatarRes.success && isSupabaseServiceRoleActive()) {
    return res.status(500).json({ error: `Failed to remove profile picture in database: ${avatarRes.error}` });
  }
  await saveUserToSupabase(user);
  res.json({
    success: true,
    message: "Profile picture removed.",
    avatarUrl: ""
  });
});
apiRouter.get("/services", async (req, res) => {
  const db = getDb();
  const getServiceOrder = (s) => {
    const code = s.code.toUpperCase();
    if (code === "NIN") return 1;
    if (code === "BVN") return 2;
    if (code === "PHONE") return 3;
    if (code === "NIN_PHONE") return 4;
    if (code === "NIN_VALIDATION") return 5;
    if (s.displayOrder && s.displayOrder > 0) return s.displayOrder;
    const def = defaultCatalogueServices.find((d) => d.code.toUpperCase() === code || d.id === s.id);
    return def?.displayOrder ?? 50;
  };
  const sorted = [...db.services || []].sort((a, b) => getServiceOrder(a) - getServiceOrder(b));
  res.json(sorted);
});
apiRouter.get("/services/:id", async (req, res) => {
  const term = req.params.id.trim();
  const db = getDb();
  let localService = db.services.find((s) => s.id === term || s.code.toUpperCase() === term.toUpperCase());
  const supaService = await fetchSupabaseServiceByCodeOrId(term);
  let service = localService;
  if (supaService) {
    if (localService) {
      const supaTime = new Date(supaService.updatedAt || 0).getTime();
      const localTime = new Date(localService.updatedAt || 0).getTime();
      if (supaTime > localTime) {
        service = { ...localService, ...supaService };
        const idx = db.services.findIndex((s) => s.id === localService.id);
        if (idx !== -1) db.services[idx] = service;
      }
    } else {
      service = supaService;
      if (!db.services) db.services = [];
      db.services.push(supaService);
    }
  }
  if (!service) {
    return res.status(404).json({ error: "Service not found." });
  }
  if (!service.requiredFields || service.requiredFields.length === 0) {
    const def = defaultCatalogueServices.find((d) => d.code.toUpperCase() === service.code.toUpperCase() || d.id === service.id);
    if (def?.requiredFields) service.requiredFields = def.requiredFields;
  }
  res.json(service);
});
apiRouter.get("/wallet/summary", requireAuth, async (req, res) => {
  const user = req.user;
  const db = getDb();
  const supaWallet = await fetchSupabaseWalletByUserId(user.id);
  if (supaWallet) {
    const idx = db.wallets.findIndex((w) => w.userId === user.id);
    if (idx !== -1) {
      db.wallets[idx] = supaWallet;
    } else {
      db.wallets.push(supaWallet);
    }
  }
  const wallet = db.wallets.find((w) => w.userId === user.id);
  if (!wallet) {
    return res.status(404).json({ error: "Wallet not found." });
  }
  res.json(wallet);
});
apiRouter.post("/wallet/fund/card", requireAuth, async (req, res) => {
  return res.status(400).json({
    error: "Direct card simulation is deprecated. All card payments must be initialized via POST /api/paystack/initialize and verified with Paystack Live API."
  });
});
apiRouter.post("/wallet/fund/bank-transfer", requireAuth, async (req, res) => {
  const { amount, reference, receiptData, receiptName, method } = req.body;
  const user = req.user;
  const db = getDb();
  const numAmount = Number(amount);
  if (!numAmount || numAmount < db.settings.minWalletFunding) {
    return res.status(400).json({
      error: `Minimum wallet funding amount is \u20A6${db.settings.minWalletFunding.toLocaleString()}.`
    });
  }
  const payRef = (reference || `TRF-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`).trim();
  if (db.fundingRequests.some((r) => r.reference === payRef)) {
    return res.status(400).json({ error: "A funding request with this payment reference already exists." });
  }
  const newRequest = {
    id: `fnd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId: user.id,
    userName: user.fullName,
    userEmail: user.email,
    reference: payRef,
    amount: numAmount,
    method: method || "BANK_TRANSFER",
    receiptUrl: receiptData || void 0,
    receiptName: receiptName || "transfer_receipt.png",
    status: "PENDING",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.fundingRequests.unshift(newRequest);
  const wallet = db.wallets.find((w) => w.userId === user.id);
  if (wallet) {
    wallet.pendingBalance += numAmount;
    wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  }
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: user.id,
    title: "Transfer Receipt Submitted",
    message: `Your deposit request of \u20A6${numAmount.toLocaleString()} has been received and is pending admin verification.`,
    type: "WALLET",
    isRead: false,
    link: "/wallet",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(user.fullName, user.role, "FUNDING_REQUEST_CREATED", `Deposit receipt of \u20A6${numAmount} ref: ${payRef}`, user.id, payRef, req.ip);
  saveDb();
  await insertFundingRequestToSupabase(newRequest);
  res.status(201).json({
    success: true,
    message: "Deposit request submitted successfully. It will be credited once confirmed by our finance desk.",
    request: newRequest
  });
});
apiRouter.get("/wallet/funding-requests", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const list = db.fundingRequests.filter((f) => f.userId === user.id);
  res.json(list);
});
apiRouter.get(["/transactions", "/wallet/transactions"], requireAuth, async (req, res) => {
  try {
    const user = req.user;
    const db = getDb();
    let txns = (db.transactions || []).filter((t) => t.userId === user.id);
    if (supabaseServer) {
      try {
        const { data: supaTxns } = await supabaseServer.from("transactions").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
        if (supaTxns && Array.isArray(supaTxns)) {
          const existingIds = new Set(txns.map((t) => t.id));
          const existingRefs = new Set(txns.map((t) => t.reference));
          for (const st of supaTxns) {
            if (!existingIds.has(st.id) && !existingRefs.has(st.reference)) {
              txns.push({
                id: st.id,
                walletId: st.wallet_id,
                userId: st.user_id,
                reference: st.reference,
                type: st.type,
                amount: Number(st.amount),
                fee: Number(st.fee || 0),
                balanceBefore: Number(st.balance_before),
                balanceAfter: Number(st.balance_after),
                status: st.status,
                description: st.description,
                metadata: st.metadata || {},
                createdAt: st.created_at
              });
              existingIds.add(st.id);
            }
          }
        }
      } catch (err) {
      }
    }
    txns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const limitStr = req.query.limit;
    if (limitStr) {
      const limit = parseInt(limitStr, 10);
      if (!isNaN(limit) && limit > 0) {
        txns = txns.slice(0, limit);
      }
    }
    res.json(txns);
  } catch (err) {
    console.error("Error fetching transactions:", err);
    res.json([]);
  }
});
async function fulfillPaystackPayment({
  reference,
  verifiedData,
  source,
  expectedUserId,
  ipAddress
}) {
  const cleanRef = String(reference || "").trim();
  if (!cleanRef) {
    return {
      success: false,
      alreadyProcessed: false,
      message: "Transaction reference is missing."
    };
  }
  const lockKey = `LOCK_PAYSTACK_${cleanRef}`;
  if (!acquireLock(lockKey)) {
    await new Promise((r) => setTimeout(r, 500));
    const db = getDb();
    const existingTx = db.transactions.find((t) => t.reference === cleanRef && t.status === "SUCCESS");
    if (existingTx) {
      if (expectedUserId && existingTx.userId !== expectedUserId) {
        return {
          success: false,
          alreadyProcessed: false,
          message: "This payment transaction belongs to another account."
        };
      }
      const wallet = db.wallets.find((w) => w.id === existingTx.walletId);
      return {
        success: true,
        alreadyProcessed: true,
        message: "Transaction has already been successfully processed and credited.",
        wallet,
        transaction: existingTx
      };
    }
    return {
      success: false,
      alreadyProcessed: false,
      message: "Payment fulfillment is currently in progress. Please check balance momentarily."
    };
  }
  try {
    const db = getDb();
    const existingTxn = db.transactions.find((t) => t.reference === cleanRef && t.status === "SUCCESS");
    if (existingTxn) {
      releaseLock(lockKey);
      if (expectedUserId && existingTxn.userId !== expectedUserId) {
        return {
          success: false,
          alreadyProcessed: false,
          message: "This payment transaction belongs to another account."
        };
      }
      const wallet2 = db.wallets.find((w) => w.id === existingTxn.walletId);
      return {
        success: true,
        alreadyProcessed: true,
        message: "Transaction has already been successfully processed and credited.",
        wallet: wallet2,
        transaction: existingTxn
      };
    }
    if (supabaseServer) {
      try {
        const { data: supaTx } = await supabaseServer.from("transactions").select("*").eq("reference", cleanRef).eq("status", "SUCCESS").limit(1);
        if (supaTx && supaTx.length > 0) {
          releaseLock(lockKey);
          if (expectedUserId && supaTx[0].user_id !== expectedUserId) {
            return {
              success: false,
              alreadyProcessed: false,
              message: "This payment transaction belongs to another account."
            };
          }
          const wallet2 = db.wallets.find((w) => w.id === supaTx[0].wallet_id);
          return {
            success: true,
            alreadyProcessed: true,
            message: "Transaction was already processed in database.",
            wallet: wallet2,
            transaction: supaTx[0]
          };
        }
      } catch (err) {
      }
    }
    let fundingReq = db.fundingRequests.find((r) => r.reference === cleanRef);
    if (!fundingReq && supabaseServer) {
      try {
        const { data: supaReq } = await supabaseServer.from("funding_requests").select("*").eq("reference", cleanRef).limit(1);
        if (supaReq && supaReq.length > 0) {
          fundingReq = {
            id: supaReq[0].id,
            userId: supaReq[0].user_id,
            userName: supaReq[0].user_name,
            userEmail: supaReq[0].user_email,
            reference: supaReq[0].reference,
            amount: Number(supaReq[0].amount),
            method: supaReq[0].method,
            status: supaReq[0].status,
            createdAt: supaReq[0].created_at
          };
          db.fundingRequests.unshift(fundingReq);
        }
      } catch (err) {
      }
    }
    if (!fundingReq) {
      releaseLock(lockKey);
      return {
        success: false,
        alreadyProcessed: false,
        message: `No UGOPAWAVERIFY funding request found for reference '${cleanRef}'.`
      };
    }
    if (expectedUserId && fundingReq.userId !== expectedUserId) {
      releaseLock(lockKey);
      return {
        success: false,
        alreadyProcessed: false,
        message: "This payment transaction belongs to another account."
      };
    }
    if (fundingReq.status === "APPROVED") {
      releaseLock(lockKey);
      const wallet2 = db.wallets.find((w) => w.userId === fundingReq.userId);
      const existingTx = db.transactions.find((t) => t.reference === cleanRef);
      return {
        success: true,
        alreadyProcessed: true,
        message: "Funding request has already been approved and credited.",
        wallet: wallet2,
        transaction: existingTx
      };
    }
    if (verifiedData.status !== "success") {
      releaseLock(lockKey);
      fundingReq.status = "REJECTED";
      fundingReq.adminNote = `Paystack payment status was '${verifiedData.status}' (${verifiedData.gateway_response || "Unsuccessful"})`;
      saveDb();
      updateFundingRequestStatusInSupabase(cleanRef, "REJECTED", "PAYSTACK", fundingReq.adminNote);
      return {
        success: false,
        alreadyProcessed: false,
        message: `Paystack reported payment was not successful (Status: ${verifiedData.status}). Wallet was not credited.`
      };
    }
    if (verifiedData.currency && verifiedData.currency.toUpperCase() !== "NGN") {
      releaseLock(lockKey);
      fundingReq.status = "REJECTED";
      fundingReq.adminNote = `Currency mismatch: expected NGN, received ${verifiedData.currency}`;
      saveDb();
      updateFundingRequestStatusInSupabase(cleanRef, "REJECTED", "SECURITY_CHECK", fundingReq.adminNote);
      return {
        success: false,
        alreadyProcessed: false,
        message: `Currency mismatch: Expected NGN, but Paystack processed ${verifiedData.currency}. Wallet was not credited.`
      };
    }
    const paystackAmountNgn = verifiedData.amount / 100;
    if (Math.abs(paystackAmountNgn - fundingReq.amount) > 0.01) {
      releaseLock(lockKey);
      fundingReq.status = "REJECTED";
      fundingReq.adminNote = `Payment amount mismatch: expected \u20A6${fundingReq.amount}, received \u20A6${paystackAmountNgn}`;
      saveDb();
      updateFundingRequestStatusInSupabase(cleanRef, "REJECTED", "SECURITY_CHECK", fundingReq.adminNote);
      logAudit(
        "SECURITY",
        "SYSTEM",
        "PAYMENT_AMOUNT_MISMATCH",
        fundingReq.adminNote,
        fundingReq.userId,
        cleanRef,
        ipAddress
      );
      return {
        success: false,
        alreadyProcessed: false,
        message: `Payment amount mismatch: Expected \u20A6${fundingReq.amount}, but Paystack processed \u20A6${paystackAmountNgn}. Wallet was not credited.`
      };
    }
    const wallet = db.wallets.find((w) => w.userId === fundingReq.userId);
    if (!wallet) {
      releaseLock(lockKey);
      return {
        success: false,
        alreadyProcessed: false,
        message: "Customer wallet not found."
      };
    }
    const unitRate = db.settings?.unitValueNgn || 200;
    const creditsCredited = Number((fundingReq.amount / unitRate).toFixed(2));
    const before = wallet.availableBalance;
    wallet.availableBalance += fundingReq.amount;
    wallet.totalDeposited += fundingReq.amount;
    wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const feeNgn = verifiedData.fees ? verifiedData.fees / 100 : 0;
    const newTxn = {
      id: `txn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      walletId: wallet.id,
      userId: fundingReq.userId,
      reference: cleanRef,
      type: "FUNDING",
      amount: fundingReq.amount,
      fee: feeNgn,
      balanceBefore: before,
      balanceAfter: wallet.availableBalance,
      status: "SUCCESS",
      description: `Wallet funded with ${creditsCredited} Credits (\u20A6${fundingReq.amount.toLocaleString()}) via Paystack (${cleanRef})`,
      metadata: {
        gateway: "PAYSTACK",
        paystack_id: verifiedData.id,
        channel: verifiedData.channel,
        card_type: verifiedData.authorization?.card_type,
        last4: verifiedData.authorization?.last4,
        bank: verifiedData.authorization?.bank,
        customer_email: verifiedData.customer?.email,
        paid_at: verifiedData.paid_at,
        gateway_response: verifiedData.gateway_response,
        credits_credited: creditsCredited,
        unit_rate: unitRate,
        source
      },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.transactions.unshift(newTxn);
    fundingReq.status = "APPROVED";
    fundingReq.reviewedBy = `PAYSTACK_${source}`;
    fundingReq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
    fundingReq.adminNote = `Settled successfully via Paystack (${verifiedData.channel || "Card"}) on ${verifiedData.paid_at || (/* @__PURE__ */ new Date()).toISOString()}`;
    db.notifications.unshift({
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: fundingReq.userId,
      title: "Wallet Funded Successfully",
      message: `Your wallet was credited with ${creditsCredited} Credits (\u20A6${fundingReq.amount.toLocaleString()}) via Paystack.`,
      type: "WALLET",
      isRead: false,
      link: "/wallet",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    logAudit(
      fundingReq.userName,
      "USER",
      "WALLET_FUNDED_PAYSTACK",
      `Credited \u20A6${fundingReq.amount.toLocaleString()} (${creditsCredited} Credits) ref: ${cleanRef} (${source})`,
      fundingReq.userId,
      cleanRef,
      ipAddress
    );
    saveDb();
    const userObj = db.users.find((u) => u.id === fundingReq.userId);
    if (userObj) {
      await ensureUserInSupabase(userObj);
    }
    await syncWalletToSupabase(wallet);
    await insertTransactionToSupabase(newTxn);
    await updateFundingRequestStatusInSupabase(cleanRef, "APPROVED", `PAYSTACK_${source}`, fundingReq.adminNote);
    await insertAuditLogToSupabase({
      id: `aud_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: fundingReq.userId,
      actorName: fundingReq.userName,
      actorRole: "USER",
      action: "WALLET_FUNDED_PAYSTACK",
      details: `Credited \u20A6${fundingReq.amount.toLocaleString()} (${creditsCredited} Credits) ref: ${cleanRef} (${source})`,
      reference: cleanRef,
      ipAddress,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    releaseLock(lockKey);
    return {
      success: true,
      alreadyProcessed: false,
      message: `Successfully credited ${creditsCredited} Credits (\u20A6${fundingReq.amount.toLocaleString()}) to your wallet.`,
      wallet,
      transaction: newTxn,
      creditsCredited,
      amountNgn: fundingReq.amount
    };
  } catch (err) {
    releaseLock(lockKey);
    return {
      success: false,
      alreadyProcessed: false,
      message: `Error fulfilling payment: ${err.message || String(err)}`
    };
  }
}
apiRouter.get("/paystack/status", (req, res) => {
  const status = getPaystackConfigStatus();
  return res.json(status);
});
apiRouter.post("/paystack/initialize", requireAuth, async (req, res) => {
  const user = req.user;
  const db = getDb();
  const { amount, callbackUrl } = req.body;
  const numAmount = Number(amount);
  if (!numAmount || isNaN(numAmount) || numAmount <= 0) {
    return res.status(400).json({ error: "Please enter a valid funding amount in NGN." });
  }
  const minFunding = db.settings?.minWalletFunding || 1e3;
  const maxFunding = db.settings?.maxWalletFunding || 1e6;
  const unitRate = db.settings?.unitValueNgn || 200;
  if (numAmount < minFunding) {
    const minCredits = Number((minFunding / unitRate).toFixed(1));
    return res.status(400).json({
      error: `Minimum wallet funding is \u20A6${minFunding.toLocaleString()} (${minCredits} Credits).`
    });
  }
  if (numAmount > maxFunding) {
    return res.status(400).json({
      error: `Maximum wallet funding per transaction is \u20A6${maxFunding.toLocaleString()}.`
    });
  }
  const calculatedCredits = Number((numAmount / unitRate).toFixed(2));
  const reference = `PSTK-${Date.now()}-${import_crypto4.default.randomBytes(4).toString("hex").toUpperCase()}`;
  const newRequest = {
    id: `fnd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId: user.id,
    userName: user.fullName,
    userEmail: user.email,
    reference,
    amount: numAmount,
    method: "CARD",
    status: "PENDING",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.fundingRequests.unshift(newRequest);
  saveDb();
  await ensureUserInSupabase(user);
  await insertFundingRequestToSupabase(newRequest);
  try {
    const paystackRes = await initializePaystackTransaction({
      email: user.email,
      amountNgn: numAmount,
      reference,
      callbackUrl: callbackUrl || void 0,
      metadata: {
        userId: user.id,
        userEmail: user.email,
        userName: user.fullName,
        credits: calculatedCredits,
        unitRate
      }
    });
    logAudit(
      user.fullName,
      user.role,
      "PAYSTACK_INITIATED",
      `Initiated funding of \u20A6${numAmount.toLocaleString()} (${calculatedCredits} Credits) ref: ${reference}`,
      user.id,
      reference,
      req.ip
    );
    return res.json({
      success: true,
      reference,
      authorizationUrl: paystackRes.data?.authorization_url,
      accessCode: paystackRes.data?.access_code,
      amount: numAmount,
      credits: calculatedCredits,
      unitRate
    });
  } catch (err) {
    newRequest.status = "REJECTED";
    newRequest.adminNote = `Paystack initialization failed: ${err.message}`;
    saveDb();
    updateFundingRequestStatusInSupabase(reference, "REJECTED", "SYSTEM", newRequest.adminNote);
    return res.status(502).json({
      error: `Failed to initialize transaction with Paystack: ${err.message}`
    });
  }
});
apiRouter.get("/paystack/verify/:reference", requireAuth, async (req, res) => {
  const { reference } = req.params;
  const cleanRef = String(reference || "").trim();
  if (!cleanRef) {
    return res.status(400).json({ error: "Transaction reference is required." });
  }
  const db = getDb();
  const existingTx = db.transactions.find((t) => t.reference === cleanRef && t.status === "SUCCESS");
  if (existingTx) {
    if (req.user && !["ADMIN", "SUPER_ADMIN", "MEGA_ADMIN"].includes(req.user.role) && existingTx.userId !== req.user.id) {
      return res.status(403).json({ error: "This payment transaction belongs to another account." });
    }
    const wallet = db.wallets.find((w) => w.id === existingTx.walletId);
    return res.json({
      success: true,
      alreadyProcessed: true,
      message: "Transaction has already been verified and credited.",
      wallet,
      transaction: existingTx,
      amountNgn: existingTx.amount,
      creditsCredited: existingTx.metadata?.credits_credited || 0
    });
  }
  try {
    const paystackRes = await verifyPaystackTransaction(cleanRef);
    if (!paystackRes.status || !paystackRes.data) {
      return res.status(400).json({
        error: paystackRes.message || "Payment verification failed on Paystack."
      });
    }
    const result = await fulfillPaystackPayment({
      reference: cleanRef,
      verifiedData: paystackRes.data,
      source: "VERIFY_ENDPOINT",
      expectedUserId: req.user?.id,
      ipAddress: req.ip
    });
    if (!result.success) {
      return res.status(400).json({ error: result.message });
    }
    return res.json(result);
  } catch (err) {
    return res.status(502).json({
      error: `Paystack verification failed: ${err.message}`
    });
  }
});
apiRouter.post("/paystack/webhook", async (req, res) => {
  const signature = req.headers["x-paystack-signature"] || "";
  const rawBody = req.rawBody;
  if (!signature || !rawBody || !verifyWebhookSignature(signature, rawBody)) {
    console.warn("[Paystack Webhook] Signature verification failed from IP:", req.ip);
    return res.status(401).json({ error: "Invalid webhook signature." });
  }
  const event = req.body;
  if (!event || !event.event) {
    return res.status(400).json({ error: "Malformed webhook payload." });
  }
  if (event.event === "charge.success") {
    const data = event.data;
    const reference = data?.reference;
    if (reference) {
      try {
        await fulfillPaystackPayment({
          reference,
          verifiedData: data,
          source: "WEBHOOK",
          ipAddress: req.ip
        });
      } catch (err) {
        console.error("[Paystack Webhook] Error fulfilling charge.success:", err);
      }
    }
  }
  return res.status(200).json({ status: true, message: "Webhook event processed." });
});
function isVerificationService(serviceOrCode) {
  if (!serviceOrCode) return false;
  const db = getDb();
  let code = "";
  let name = "";
  let category = "";
  let routingProvider;
  if (typeof serviceOrCode === "string") {
    const raw = serviceOrCode.trim();
    const upper = raw.toUpperCase();
    const s = db.services?.find((x) => x.id === raw || x.code.toUpperCase() === upper) || defaultCatalogueServices.find((x) => x.id === raw || x.code.toUpperCase() === upper);
    if (s) {
      code = s.code.toUpperCase();
      name = (s.name || "").toUpperCase();
      category = (s.category || "").toUpperCase();
      routingProvider = s.defaultProvider ? String(s.defaultProvider).toLowerCase().trim() : void 0;
    } else {
      code = upper;
    }
  } else if (typeof serviceOrCode === "object") {
    code = (serviceOrCode.code || "").toUpperCase();
    name = (serviceOrCode.name || "").toUpperCase();
    category = (serviceOrCode.category || "").toUpperCase();
    routingProvider = serviceOrCode.defaultProvider ? String(serviceOrCode.defaultProvider).toLowerCase().trim() : void 0;
  }
  if (routingProvider === "admin" || routingProvider === "admin_gateway" || routingProvider === "manual") {
    return false;
  }
  if (routingProvider === "ninja" || routingProvider === "veripine") {
    return true;
  }
  const nonVerifKeywords = [
    "MOD",
    "REG",
    "ATTESTATION",
    "RETRIEVAL",
    "DELINK",
    "ONBOARDING",
    "PERSONAL",
    "SELF_SERVICE",
    "IPE",
    "CAC",
    "TIN",
    "TRACKING",
    "VALIDATION",
    "LOOKUP",
    "CRM",
    "DEMOGRAPHIC",
    "ONLINE_NIN"
  ];
  for (const kw of nonVerifKeywords) {
    if (code.includes(kw) || name.includes(kw) || category.includes(kw)) {
      return false;
    }
  }
  const exactVerificationCodes = [
    "NIN",
    "BVN",
    "PHONE",
    "VNIN",
    "DRIVERS_LICENSE"
  ];
  return exactVerificationCodes.includes(code);
}
async function handleNonVerificationServiceRequest(req, res, serviceIdentifier, searchData, idempotencyKey, customerFiles) {
  const user = req.user;
  const db = getDb();
  if (!db.serviceRequests) db.serviceRequests = [];
  if (!db.transactions) db.transactions = [];
  const rawIdent = String(serviceIdentifier || "").trim().toUpperCase();
  let resolvedCode = rawIdent;
  if (resolvedCode === "MODIFICATION" || resolvedCode === "NIN_MODIFICATION") {
    const modType = String(searchData?.modificationType || searchData?.type || searchData?.subType || "").toLowerCase();
    if (modType.includes("dob") || modType.includes("birth")) resolvedCode = "NIN_DOB_MOD";
    else if (modType.includes("phone")) resolvedCode = "NIN_PHONE_MOD";
    else if (modType.includes("address")) resolvedCode = "NIN_ADDRESS_MOD";
    else if (modType.includes("bvn")) resolvedCode = "BVN_MODIFICATION";
    else if (modType.includes("ipe")) resolvedCode = "IPE_MODIFICATION";
    else resolvedCode = "NIN_NAME_MOD";
  } else if (resolvedCode === "CAC_TIN" || resolvedCode === "CAC" || resolvedCode === "TIN") {
    const cacType = String(searchData?.cacTinType || searchData?.registrationType || searchData?.subServiceKey || "").toLowerCase();
    if (cacType.includes("company_cac") || cacType.includes("company cac") || cacType.includes("llc") || cacType.includes("limited")) {
      resolvedCode = "COMPANY_CAC";
    } else if (cacType.includes("business_cac") || cacType.includes("business cac") || cacType.includes("business name")) {
      resolvedCode = "BUSINESS_CAC";
    } else if (cacType.includes("company_tin") || cacType.includes("company tin") || cacType.includes("corporate tin")) {
      resolvedCode = "TIN_COMPANY";
    } else if (cacType.includes("individual_tin") || cacType.includes("individual tin")) {
      resolvedCode = "TIN_INDIVIDUAL";
    } else {
      resolvedCode = "CAC_REGISTRATION";
    }
  }
  let targetService = db.services?.find((s) => s.code.toUpperCase() === resolvedCode || s.id === serviceIdentifier);
  if (!targetService) {
    targetService = defaultCatalogueServices.find((s) => s.code.toUpperCase() === resolvedCode || s.id === serviceIdentifier);
  }
  if (resolvedCode === "ONLINE_NIN_REGISTRATION") {
    if (user.role === "USER") {
      return res.status(403).json({
        error: "Online NIN Registration is an operator enrollment service reserved for authorized Agents and Admins."
      });
    }
    if (user.role === "AGENT" && (!user.assignedServices || !user.assignedServices.includes("ONLINE_NIN_REGISTRATION"))) {
      return res.status(403).json({
        error: "Online NIN Registration service is not assigned to your Agent account. Please contact Mega Admin or Super Admin for service authorization."
      });
    }
  }
  const serviceName = targetService?.name || resolvedCode.replace(/_/g, " ") + " Service";
  const serviceCategory = targetService?.category || "Non-Verification Services";
  let applicablePrice = targetService && targetService.price !== void 0 && targetService.price > 0 ? targetService.price : 4500;
  if (!targetService?.price) {
    if (resolvedCode === "NIN_DOB_MOD") applicablePrice = 5e4;
    else if (resolvedCode === "COMPANY_CAC") applicablePrice = 3e4;
    else if (resolvedCode === "BUSINESS_CAC") applicablePrice = 22e3;
    else if (resolvedCode === "TIN_COMPANY") applicablePrice = 2500;
    else if (resolvedCode === "TIN_INDIVIDUAL") applicablePrice = 1e3;
  }
  if (resolvedCode === "BVN_MODIFICATION") {
    if (searchData?.enrollmentCenterPrice && Number(searchData.enrollmentCenterPrice) > 0) {
      applicablePrice = Number(searchData.enrollmentCenterPrice);
    } else if (searchData?.enrollmentCenterId) {
      const center = (db.bvnEnrollmentCenters || []).find((c) => c.id === searchData.enrollmentCenterId);
      if (center) applicablePrice = center.price;
    }
  }
  if (user.role === "AGENT") {
    if (targetService?.agentPrice !== void 0 && targetService.agentPrice > 0) {
      applicablePrice = targetService.agentPrice;
    } else {
      applicablePrice = Math.round(applicablePrice * 0.75 * 100) / 100;
    }
  }
  const cleanIdemKey = (idempotencyKey || req.body?.idempotencyKey || `idem_sr_${user.id}_${resolvedCode}_${Date.now()}`).trim();
  const existingReq = db.serviceRequests.find(
    (r) => r.idempotencyKey === cleanIdemKey || r.submittedData?.__idempotencyKey === cleanIdemKey
  );
  if (existingReq) {
    return res.json({
      success: true,
      cached: true,
      ticketId: existingReq.ticketId,
      trackingId: existingReq.ticketId,
      request: existingReq,
      verification: existingReq,
      message: "Service request submitted successfully."
    });
  }
  const lockKey = `LOCK_SR_${user.id}_${cleanIdemKey}`;
  if (!acquireLock(lockKey)) {
    return res.status(429).json({ error: "Service request processing in progress. Please do not duplicate." });
  }
  try {
    const wallet = db.wallets.find((w) => w.userId === user.id);
    if (!wallet) {
      releaseLock(lockKey);
      return res.status(400).json({ error: "User wallet account not initialized." });
    }
    const unitRate = db.settings?.unitValueNgn || 200;
    const requiredUnits = Number((applicablePrice / unitRate).toFixed(2));
    const currentUnits = Number((wallet.availableBalance / unitRate).toFixed(2));
    if (wallet.availableBalance < applicablePrice) {
      releaseLock(lockKey);
      return res.status(400).json({
        error: `Insufficient wallet balance. This service costs ${requiredUnits} Credits (\u20A6${applicablePrice.toLocaleString()}), but your balance is ${currentUnits} Credits (\u20A6${wallet.availableBalance.toLocaleString()}). Please fund your wallet.`
      });
    }
    const balanceBefore = wallet.availableBalance;
    wallet.availableBalance -= applicablePrice;
    wallet.totalSpent += applicablePrice;
    wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const trackingId = generateServiceTicketId();
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const debitTxn = {
      id: `txn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      walletId: wallet.id,
      userId: user.id,
      reference: trackingId,
      type: "SERVICE_REQUEST",
      amount: -applicablePrice,
      fee: 0,
      balanceBefore,
      balanceAfter: wallet.availableBalance,
      status: "SUCCESS",
      description: `Service Request Fee: ${serviceName} (${trackingId})`,
      metadata: {
        ticketId: trackingId,
        trackingId,
        serviceCode: resolvedCode,
        serviceName,
        serviceCategory,
        serviceType: "non_verification",
        unitCost: applicablePrice,
        originalUnitCost: applicablePrice,
        units: requiredUnits,
        originalPrice: applicablePrice,
        amountCharged: applicablePrice,
        creditsDeducted: applicablePrice,
        debitSummary: "Non-verification service request submitted \u2014 fee debited pending fulfillment"
      },
      createdAt: now
    };
    db.transactions.unshift(debitTxn);
    const timeline = [
      {
        id: `tml_${Date.now()}_1`,
        status: "PENDING",
        title: "Service Request Submitted",
        description: `Customer submitted request for ${serviceName}. Payment of \u20A6${applicablePrice.toLocaleString()} confirmed.`,
        actorName: user.fullName,
        actorRole: user.role === "AGENT" ? "AGENT" : "CUSTOMER",
        timestamp: now
      }
    ];
    const safeSubmittedData = {
      ...searchData || {},
      __idempotencyKey: cleanIdemKey,
      submittedAt: now
    };
    const newRequest = {
      id: `sr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      ticketId: trackingId,
      trackingId,
      userId: user.id,
      customerName: user.fullName,
      customerEmail: user.email,
      customerPhone: user.phone || "",
      serviceId: targetService?.id || `srv_${resolvedCode.toLowerCase()}`,
      serviceCode: resolvedCode,
      serviceName,
      serviceCategory,
      price: applicablePrice,
      amountCharged: applicablePrice,
      creditsDeducted: applicablePrice,
      submittedData: safeSubmittedData,
      customerFiles: Array.isArray(customerFiles) ? customerFiles : [],
      status: "PENDING",
      refundStatus: "NONE",
      timeline,
      createdAt: now,
      updatedAt: now
    };
    newRequest.idempotencyKey = cleanIdemKey;
    db.serviceRequests.unshift(newRequest);
    if (!db.verificationRequests) db.verificationRequests = [];
    const vReq = {
      id: `vreq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      idempotencyKey: cleanIdemKey,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.email,
      serviceId: targetService?.id || `srv_${resolvedCode.toLowerCase()}`,
      serviceCode: resolvedCode,
      serviceName,
      serviceCategory: "non_verification",
      serviceType: "non_verification",
      apiCallState: "completed",
      reference: trackingId,
      ticketId: trackingId,
      searchData: safeSubmittedData,
      status: "PENDING",
      amountCharged: applicablePrice,
      refundStatus: "NONE",
      createdAt: now,
      updatedAt: now
    };
    vReq.serviceRequestId = newRequest.id;
    vReq.trackingId = trackingId;
    db.verificationRequests.unshift(vReq);
    if (!db.notifications) db.notifications = [];
    db.notifications.unshift({
      id: `notif_${Date.now()}_c`,
      userId: user.id,
      title: "Service Request Submitted Successfully",
      message: `Your service request for "${serviceName}" was received. Tracking ID: ${trackingId}. Status: Pending.`,
      type: "SERVICE_REQUEST",
      isRead: false,
      link: "/my-service-requests",
      createdAt: now
    });
    const adminUsers = db.users.filter(
      (u) => u.role === "ADMIN" || u.role === "SUPER_ADMIN" || u.role === "MEGA_ADMIN"
    );
    for (const adm of adminUsers) {
      db.notifications.unshift({
        id: `notif_${Date.now()}_a_${adm.id}`,
        userId: adm.id,
        title: "\u{1F514} New Customer Service Request",
        message: `New service request received: ${serviceName}. Tracking ID: ${trackingId}. Customer: ${user.fullName}`,
        type: "ANNOUNCEMENT",
        isRead: false,
        link: "/admin/service-requests",
        createdAt: now
      });
    }
    logAudit(
      user.fullName,
      user.role,
      "SERVICE_REQUEST_SUBMITTED",
      `Submitted ${serviceName} (Tracking ID: ${trackingId}, Amount: \u20A6${applicablePrice})`,
      user.id,
      trackingId,
      req.ip
    );
    saveDb();
    await saveServiceRequestToSupabase(newRequest);
    await saveWalletToSupabase(wallet);
    releaseLock(lockKey);
    return res.status(201).json({
      success: true,
      trackingId,
      ticketId: trackingId,
      service: serviceName,
      serviceName,
      serviceCategory,
      amount: applicablePrice,
      amountCharged: applicablePrice,
      creditsDeducted: applicablePrice,
      status: "PENDING",
      request: newRequest,
      verification: vReq,
      message: "Service request submitted successfully."
    });
  } catch (err) {
    releaseLock(lockKey);
    console.error("[SERVICE_REQUEST_ERROR] Failed to submit non-verification request:", err);
    return res.status(500).json({ error: err.message || "Failed to submit service request." });
  }
}
apiRouter.post(["/verifications/initiate", "/verifications/execute"], requireAuth, async (req, res) => {
  const { serviceId, serviceCode, searchData, idempotencyKey, customerFiles } = req.body;
  const user = req.user;
  const db = getDb();
  const rawCode = String(serviceCode || "").trim();
  const rawId = String(serviceId || "").trim();
  const effectiveData = searchData || req.body.submittedData || {};
  const identifierToTest = rawCode || rawId;
  if (!identifierToTest) {
    return res.status(400).json({ error: "Service identifier is required." });
  }
  const isCodeNonVerif = rawCode && !isVerificationService(rawCode);
  const isIdNonVerif = rawId && !isVerificationService(rawId);
  const isIdentNonVerif = !isVerificationService(identifierToTest);
  if (isCodeNonVerif || isIdNonVerif || isIdentNonVerif) {
    const nonVerifIdentifier = isCodeNonVerif ? rawCode : isIdNonVerif ? rawId : identifierToTest;
    return handleNonVerificationServiceRequest(
      req,
      res,
      nonVerifIdentifier,
      effectiveData,
      idempotencyKey,
      customerFiles
    );
  }
  const lookupIdentifier = identifierToTest;
  if (!effectiveData || Object.keys(effectiveData).length === 0) {
    return res.status(400).json({ error: "Search parameters are required for live verification." });
  }
  const upperIdentifier = lookupIdentifier.toUpperCase();
  const localService = db.services.find((s) => s.id === lookupIdentifier || s.code.toUpperCase() === upperIdentifier);
  let service = localService;
  if (!service) {
    const supaService = await fetchSupabaseServiceByCodeOrId(lookupIdentifier);
    service = supaService || defaultCatalogueServices.find((s) => s.id === lookupIdentifier || s.code.toUpperCase() === upperIdentifier);
  }
  if (!service || service.status !== "ACTIVE") {
    return res.status(400).json({ error: "Selected verification service is currently unavailable or inactive." });
  }
  if (service.code.toUpperCase() === "ONLINE_NIN_REGISTRATION") {
    if (user.role === "USER") {
      return res.status(403).json({
        error: "Online NIN Registration is an operator enrollment service reserved for authorized Agents and Admins."
      });
    }
    if (user.role === "AGENT" && (!user.assignedServices || !user.assignedServices.includes("ONLINE_NIN_REGISTRATION"))) {
      return res.status(403).json({
        error: "Online NIN Registration service is not assigned to your Agent account. Please contact Mega Admin or Super Admin for service authorization."
      });
    }
  }
  for (const field of service.requiredFields) {
    if (field.required && !searchData[field.name]) {
      return res.status(400).json({ error: `Field '${field.label}' is required.` });
    }
  }
  const cleanIdempotencyKey = (idempotencyKey || `IDEM-${user.id}-${service.code}-${Date.now()}`).trim();
  const existingReq = db.verificationRequests.find((r) => r.idempotencyKey === cleanIdempotencyKey);
  if (existingReq && existingReq.status === "SUCCESS") {
    const existingResult = db.verificationResults.find((vr) => vr.requestId === existingReq.id);
    return res.json({
      success: true,
      cached: true,
      verification: existingReq,
      result: existingResult
    });
  }
  const lockKey = `LOCK_VERIFY_${user.id}_${service.id}_${cleanIdempotencyKey}`;
  if (!acquireLock(lockKey)) {
    return res.status(429).json({ error: "Verification in progress. Please do not duplicate your request." });
  }
  try {
    const wallet = db.wallets.find((w) => w.userId === user.id);
    if (!wallet) {
      releaseLock(lockKey);
      return res.status(400).json({ error: "Wallet not found." });
    }
    let applicablePrice = user.role === "AGENT" && service.agentPrice !== void 0 && service.agentPrice > 0 ? service.agentPrice : service.price;
    let serviceDescription = `${service.name} Fee`;
    const isBvnMod = service.code === "BVN_MODIFICATION" || service.code.startsWith("BVN_MOD_") || Boolean(searchData?.enrollmentCenter || req.body.enrollmentCenterId || req.body.enrollmentCenterCode);
    if (isBvnMod) {
      const centerQuery = String(
        req.body.enrollmentCenterId || req.body.enrollmentCenterCode || searchData?.enrollmentCenter || ""
      ).trim().toUpperCase();
      const centers = db.bvnEnrollmentCenters || [];
      const matchedCenter = centers.find(
        (c) => c.id.toUpperCase() === centerQuery || c.code.toUpperCase() === centerQuery || c.name.toUpperCase() === centerQuery
      );
      if (matchedCenter) {
        applicablePrice = matchedCenter.price;
        serviceDescription = `BVN Modification (${matchedCenter.name}) Fee`;
        searchData.enrollmentCenter = matchedCenter.name;
        searchData.enrollmentCenterPrice = matchedCenter.price;
      }
    }
    if (service.code === "NIN_DELINKING" || service.code === "SELF_SERVICE") {
      const chosen = String(searchData?.selectedService || searchData?.serviceType || "");
      if (chosen.toLowerCase().includes("email")) {
        const emailSrv = db.services.find((s) => s.code === "SELF_SERVICE_EMAIL");
        applicablePrice = emailSrv?.price ?? 1500;
        serviceDescription = "Self service Email Retrieval Fee";
      } else {
        const delinkSrv = db.services.find((s) => s.code === "NIN_DELINKING");
        applicablePrice = delinkSrv?.price ?? 2500;
        serviceDescription = "Self service NIN Delinking Fee";
      }
    }
    if (service.code === "MODIFICATION" || service.code === "NIN_MODIFICATION") {
      const chosenMod = String(searchData?.modificationType || searchData?.subServiceKey || searchData?.type || searchData?.selectedService || "").toLowerCase();
      if (chosenMod.includes("dob") || chosenMod.includes("birth")) {
        const srv = db.services.find((s) => s.code === "NIN_DOB_MOD");
        applicablePrice = srv?.price ?? 5e4;
        serviceDescription = "Date of Birth Modification Fee";
      } else if (chosenMod.includes("bvn")) {
        const srv = db.services.find((s) => s.code === "BVN_MODIFICATION");
        applicablePrice = srv?.price ?? 3e3;
        if (searchData.enrollmentCenterId || searchData.enrollmentCenter) {
          const matched = db.bvnEnrollmentCenters?.find((c) => c.id === searchData.enrollmentCenterId || c.name === searchData.enrollmentCenter);
          if (matched) applicablePrice = matched.price;
        }
        serviceDescription = "BVN Modification Fee";
      } else if (chosenMod.includes("ipe")) {
        const srv = db.services.find((s) => s.code === "IPE_MODIFICATION");
        applicablePrice = srv?.price ?? 4500;
        serviceDescription = "IPE Modification Fee";
      } else if (chosenMod.includes("phone")) {
        const srv = db.services.find((s) => s.code === "NIN_PHONE_MOD");
        applicablePrice = srv?.price ?? 4500;
        serviceDescription = "Phone Number Modification Fee";
      } else if (chosenMod.includes("address")) {
        const srv = db.services.find((s) => s.code === "NIN_ADDRESS_MOD");
        applicablePrice = srv?.price ?? 4500;
        serviceDescription = "Address Modification Fee";
      } else {
        const srv = db.services.find((s) => s.code === "NIN_NAME_MOD");
        applicablePrice = srv?.price ?? 4500;
        serviceDescription = "Name Modification Fee";
      }
    }
    if (service.code === "CAC_TIN") {
      const chosenCacTin = String(searchData?.cacTinType || searchData?.subServiceKey || searchData?.registrationType || "").toLowerCase();
      if (chosenCacTin.includes("company_cac") || chosenCacTin.includes("company cac") || chosenCacTin.includes("llc") || chosenCacTin.includes("limited")) {
        applicablePrice = 3e4;
        serviceDescription = "Company CAC Registration Fee";
      } else if (chosenCacTin.includes("business_cac") || chosenCacTin.includes("business cac") || chosenCacTin.includes("business name")) {
        applicablePrice = 22e3;
        serviceDescription = "Business CAC Registration Fee";
      } else if (chosenCacTin.includes("company_tin") || chosenCacTin.includes("company tin") || chosenCacTin.includes("corporate tin")) {
        const srv = db.services.find((s) => s.code === "TIN_COMPANY");
        applicablePrice = srv?.price ?? 2500;
        serviceDescription = "Company TIN Registration Fee";
      } else if (chosenCacTin.includes("individual_tin") || chosenCacTin.includes("individual tin")) {
        const srv = db.services.find((s) => s.code === "TIN_INDIVIDUAL");
        applicablePrice = srv?.price ?? 1e3;
        serviceDescription = "Individual TIN Registration Fee";
      }
    }
    if (user.role === "AGENT") {
      const matchedAgentPrice = service.agentPrice;
      if (matchedAgentPrice !== void 0 && matchedAgentPrice > 0) {
        applicablePrice = matchedAgentPrice;
      } else {
        applicablePrice = Math.round(applicablePrice * 0.75 * 100) / 100;
      }
      serviceDescription += " (Agent Rate)";
    }
    const unitRate = db.settings?.unitValueNgn || 200;
    const requiredUnits = Number((applicablePrice / unitRate).toFixed(2));
    const currentUnits = Number((wallet.availableBalance / unitRate).toFixed(2));
    if (wallet.availableBalance < applicablePrice) {
      releaseLock(lockKey);
      return res.status(400).json({
        error: `Insufficient wallet balance. This service costs ${requiredUnits} Credits (\u20A6${applicablePrice.toLocaleString()}), but your balance is ${currentUnits} Credits (\u20A6${wallet.availableBalance.toLocaleString()}). Please fund your wallet.`
      });
    }
    const verificationRef = `VRF-${service.code}-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const isInstantVerificationService = service.serviceType === "verification" || !service.serviceType && isVerificationService(service.code);
    const isNonVerificationAdminService = !isInstantVerificationService;
    if (isNonVerificationAdminService) {
      const balanceBefore2 = wallet.availableBalance;
      wallet.availableBalance -= applicablePrice;
      wallet.totalSpent += applicablePrice;
      wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (!db.serviceRequests) db.serviceRequests = [];
      const ticketId = generateServiceTicketId();
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const debitTxn2 = {
        id: `txn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        walletId: wallet.id,
        userId: user.id,
        reference: ticketId,
        type: "SERVICE_REQUEST",
        amount: -applicablePrice,
        fee: 0,
        balanceBefore: balanceBefore2,
        balanceAfter: wallet.availableBalance,
        status: "SUCCESS",
        description: `${serviceDescription} (${ticketId})`,
        metadata: {
          serviceCode: service.code,
          serviceName: service.name,
          serviceCategory: "non_verification",
          serviceType: "non_verification",
          ticketId,
          unitCost: applicablePrice,
          originalUnitCost: applicablePrice,
          units: requiredUnits,
          originalPrice: applicablePrice,
          debitSummary: "Admin processing request submitted \u2014 debit retained pending completion"
        },
        createdAt: now
      };
      db.transactions.unshift(debitTxn2);
      const verificationReq = {
        id: `vreq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        idempotencyKey: cleanIdempotencyKey,
        userId: user.id,
        userName: user.fullName,
        userEmail: user.email,
        serviceId: service.id,
        serviceCode: service.code,
        serviceName: service.name,
        serviceCategory: "non_verification",
        serviceType: "non_verification",
        apiCallState: "completed",
        reference: ticketId,
        ticketId,
        searchData,
        status: "PENDING",
        amountCharged: applicablePrice,
        refundStatus: "NONE",
        createdAt: now,
        updatedAt: now
      };
      const ninTrackingId = (searchData.trackingId || searchData.tracking_id || searchData.ninTrackingId || searchData.trackingNo || searchData.searchQuery || "").toString().trim();
      let userMessage = `${service.name} request submitted (Ticket: ${ticketId}). Request is under review and will be processed by Admin.`;
      if (service.code === "PERSONALIZATION" || service.code === "PERSONALISATION" || service.code === "NIN_TRACKING") {
        userMessage = `Personalisation request submitted successfully (Ticket: ${ticketId}). NIN Tracking ID: ${ninTrackingId || "Recorded"}. Status: PENDING. Admin will process and complete your request.`;
      } else if (service.code === "NIN_VALIDATION") {
        userMessage = `NIN Validation & Status request submitted (Ticket: ${ticketId}). Status: PENDING. Our operations desk is reviewing your national identity record.`;
      } else if (service.code === "BIRTH_ATTESTATION") {
        userMessage = `Birth Attestation request submitted (Ticket: ${ticketId}). NOTE: This Service Takes 3 to 4 days To Be Processed.`;
      } else if (service.code === "MODIFICATION" || service.code.startsWith("NIN_MOD")) {
        userMessage = `Modification request (${searchData.modificationType || service.name}) submitted (Ticket: ${ticketId}). Status: PENDING. Admin will process and update your records.`;
      } else if (service.code.startsWith("BVN_MOD")) {
        userMessage = `BVN Modification request submitted (Ticket: ${ticketId}). Processing at ${searchData.enrollmentCenter || "Center"}.`;
      } else if (service.code === "BVN_RETRIEVAL") {
        userMessage = `BVN Retrieval request submitted (Ticket: ${ticketId}). Status: PENDING. Banking directory lookup queued for processing.`;
      } else if (service.code === "BVN_ANDROID_USER" || service.code === "ANDROID_BVN_ONBOARDING") {
        userMessage = `Android BVN Onboarding agent license request submitted (Ticket: ${ticketId}).`;
      } else if (service.code === "NIN_DELINKING" || service.code === "SELF_SERVICE" || service.code === "SELF_SERVICE_EMAIL") {
        userMessage = `Self Service request submitted (Ticket: ${ticketId}). NOTE: This Service Takes 24-48hrs To Be Processed.`;
      } else if (service.code === "CAC_REGISTRATION" || service.code === "CAC_TIN") {
        userMessage = `CAC Registration submitted (Ticket: ${ticketId}). We will process and issue your certificate within 2 to 4 weeks.`;
      } else if (service.code.includes("TIN")) {
        userMessage = `${service.name} submitted (Ticket: ${ticketId}). Verification & JTB registration in progress.`;
      }
      const newServiceRequest = {
        id: `sr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        ticketId,
        userId: user.id,
        customerName: user.fullName,
        customerEmail: user.email,
        customerPhone: user.phone || "",
        serviceId: service.id,
        serviceCode: service.code,
        serviceName: service.name,
        serviceCategory: service.category || "Manual Service",
        price: applicablePrice,
        submittedData: {
          ...searchData,
          ...ninTrackingId ? { ninTrackingId, trackingId: ninTrackingId } : {}
        },
        customerFiles: req.body.customerFiles || [],
        status: "PENDING",
        refundStatus: "NONE",
        timeline: [
          {
            id: `tml_${Date.now()}_1`,
            status: "PENDING",
            title: "Service Request Submitted",
            description: `Customer submitted request for ${service.name}. Credits/Payment of \u20A6${applicablePrice.toLocaleString()} (${requiredUnits} Credits) deducted.`,
            actorName: user.fullName,
            actorRole: "CUSTOMER",
            timestamp: now
          }
        ],
        createdAt: now,
        updatedAt: now
      };
      db.serviceRequests.unshift(newServiceRequest);
      verificationReq.ticketId = ticketId;
      verificationReq.serviceRequestId = newServiceRequest.id;
      db.verificationRequests.unshift(verificationReq);
      db.notifications.unshift({
        id: `notif_${Date.now()}`,
        userId: user.id,
        title: `${service.name} Submitted (Pending)`,
        message: userMessage,
        type: "SERVICE_REQUEST",
        isRead: false,
        link: "/my-service-requests",
        createdAt: now
      });
      logAudit(
        user.fullName,
        user.role,
        "SERVICE_REQUEST_SUBMITTED",
        `Submitted ${service.name} (Ticket: ${ticketId}) - Charged: \u20A6${applicablePrice} (${requiredUnits} Credits) - Status: PENDING`,
        user.id,
        ticketId,
        req.ip
      );
      saveDb();
      releaseLock(lockKey);
      return res.status(200).json({
        success: true,
        pending: true,
        status: "PENDING",
        ticketId,
        message: userMessage,
        request: verificationReq,
        serviceRequest: newServiceRequest
      });
    }
    const balanceBefore = wallet.availableBalance;
    wallet.availableBalance -= applicablePrice;
    wallet.totalSpent += applicablePrice;
    wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const debitTxn = {
      id: `txn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      walletId: wallet.id,
      userId: user.id,
      reference: verificationRef,
      type: "VERIFICATION",
      amount: -applicablePrice,
      fee: 0,
      balanceBefore,
      balanceAfter: wallet.availableBalance,
      status: "SUCCESS",
      description: `${serviceDescription} (${verificationRef})`,
      metadata: {
        serviceCode: service.code,
        serviceName: service.name,
        serviceCategory: "verification",
        serviceType: "verification",
        originalUnitCost: applicablePrice,
        units: requiredUnits,
        apiCallState: "api_not_called",
        debitRetained: true,
        debitSummary: "Verification lookup initiated"
      },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.transactions.unshift(debitTxn);
    const providerRes = await providerAdapter.executeService(service.code, searchData);
    const apiWasCalledAndReturnedResponse = providerRes.apiCallState === "api_called_response_received" || providerRes.apiCalled === true && !providerRes.unconfigured && providerRes.apiCallState !== "api_not_called" && providerRes.apiCallState !== "api_call_failed_before_response";
    if (apiWasCalledAndReturnedResponse) {
      debitTxn.metadata = {
        ...debitTxn.metadata,
        apiCallState: "api_called_response_received",
        debitSummary: "API called and response received \u2014 debit retained",
        debitRetained: true,
        finalServiceStatus: providerRes.success ? "SUCCESSFUL" : "FAILED",
        providerName: providerRes.providerName,
        rawHttpStatus: providerRes.rawHttpStatus
      };
      const retData = providerRes.data;
      const hasVerifiedData = providerRes.success && retData && typeof retData === "object" && Object.keys(retData).length > 0 && Boolean(
        retData.nin || retData.bvn || retData.licenseNumber || retData.fullName || retData.firstName && retData.surname || retData.photoUrl || retData.trackingId || retData.status === "VERIFIED"
      );
      if (hasVerifiedData) {
        const verificationReq = {
          id: `vreq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          idempotencyKey: cleanIdempotencyKey,
          userId: user.id,
          userName: user.fullName,
          userEmail: user.email,
          serviceId: service.id,
          serviceCode: service.code,
          serviceName: service.name,
          serviceCategory: "verification",
          serviceType: "verification",
          apiCallState: "api_called_response_received",
          reference: verificationRef,
          searchData,
          status: "SUCCESS",
          amountCharged: applicablePrice,
          refundStatus: "NONE",
          resultData: providerRes.data,
          result: providerRes.data,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        db.verificationRequests.unshift(verificationReq);
        const verificationResult = {
          id: `vres_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          requestId: verificationReq.id,
          userId: user.id,
          serviceCode: service.code,
          serviceName: service.name,
          reference: verificationRef,
          returnedData: providerRes.data || {},
          photoUrl: providerRes.data?.photoUrl || void 0,
          providerName: providerRes.providerName,
          verifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
          verifiedBy: user.fullName
        };
        db.verificationResults.unshift(verificationResult);
        db.notifications.unshift({
          id: `notif_${Date.now()}`,
          userId: user.id,
          title: "Verification Completed",
          message: `${service.name} verified successfully. Reference: ${verificationRef}`,
          type: "VERIFICATION",
          isRead: false,
          link: "/verify/history",
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        logAudit(
          user.fullName,
          user.role,
          "VERIFICATION_SUCCESS",
          `Verified ${service.code} Ref: ${verificationRef}. API called + response received (debit retained: \u20A6${applicablePrice}).`,
          user.id,
          verificationRef,
          req.ip
        );
        saveDb();
        releaseLock(lockKey);
        return res.json({
          success: true,
          message: "Verification completed successfully.",
          verification: verificationReq,
          request: verificationReq,
          result: verificationResult
        });
      } else {
        const unverifiedReq = {
          id: `vreq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          idempotencyKey: cleanIdempotencyKey,
          userId: user.id,
          userName: user.fullName,
          userEmail: user.email,
          serviceId: service.id,
          serviceCode: service.code,
          serviceName: service.name,
          serviceCategory: "verification",
          serviceType: "verification",
          apiCallState: "api_called_response_received",
          reference: verificationRef,
          searchData,
          status: "FAILED",
          amountCharged: applicablePrice,
          // DEBIT KEPT!
          refundStatus: "NONE",
          // NO REFUND!
          errorMessage: providerRes.message || "No matching identity record found in the national registry database.",
          resultData: providerRes.data || null,
          result: providerRes.data || null,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        db.verificationRequests.unshift(unverifiedReq);
        db.notifications.unshift({
          id: `notif_${Date.now()}`,
          userId: user.id,
          title: "Verification Result: Record Not Found",
          message: `${service.name} lookup returned no record. The verification API was called and response received; debit of ${requiredUnits} Credits (\u20A6${applicablePrice.toLocaleString()}) was retained.`,
          type: "VERIFICATION",
          isRead: false,
          link: "/verify/history",
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        logAudit(
          user.fullName,
          user.role,
          "VERIFICATION_API_RESPONSE_RECORD_NOT_FOUND",
          `No matching record for ${service.code} Ref: ${verificationRef}. API called + response received. Debit retained: \u20A6${applicablePrice}.`,
          user.id,
          verificationRef,
          req.ip
        );
        saveDb();
        releaseLock(lockKey);
        return res.json({
          success: true,
          verified: false,
          error: unverifiedReq.errorMessage,
          message: unverifiedReq.errorMessage,
          verification: unverifiedReq,
          request: unverifiedReq,
          result: null
        });
      }
    } else {
      const apiState = providerRes.apiCallState || "api_not_called";
      wallet.availableBalance += applicablePrice;
      wallet.totalSpent = Math.max(0, wallet.totalSpent - applicablePrice);
      wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      const refundTxn = {
        id: `txn_${Date.now()}_ref_${Math.random().toString(36).substring(2, 6)}`,
        walletId: wallet.id,
        userId: user.id,
        reference: `REF-${verificationRef}`,
        type: "REFUND",
        amount: applicablePrice,
        fee: 0,
        balanceBefore: wallet.availableBalance - applicablePrice,
        balanceAfter: wallet.availableBalance,
        status: "SUCCESS",
        description: `Automatic Refund: ${service.name} API was not called (${verificationRef})`,
        metadata: {
          originalReference: verificationRef,
          serviceCode: service.code,
          serviceName: service.name,
          serviceCategory: "verification",
          serviceType: "verification",
          originalUnitCost: applicablePrice,
          units: requiredUnits,
          apiCallState: apiState,
          debitSummary: "API was not called \u2014 refund issued",
          refundAmount: applicablePrice,
          refundReason: providerRes.unconfigured ? "Verification provider credentials not configured" : providerRes.message || "Verification provider request failed before response was received"
        },
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.transactions.unshift(refundTxn);
      debitTxn.metadata = {
        ...debitTxn.metadata,
        apiCallState: apiState,
        debitSummary: "API was not called \u2014 refund issued",
        refunded: true,
        refundTxnId: refundTxn.id
      };
      const failedReq = {
        id: `vreq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        idempotencyKey: cleanIdempotencyKey,
        userId: user.id,
        userName: user.fullName,
        userEmail: user.email,
        serviceId: service.id,
        serviceCode: service.code,
        serviceName: service.name,
        serviceCategory: "verification",
        serviceType: "verification",
        apiCallState: apiState,
        reference: verificationRef,
        searchData,
        status: "FAILED",
        amountCharged: applicablePrice,
        refundStatus: "REFUNDED",
        refundAmount: applicablePrice,
        refundedAt: (/* @__PURE__ */ new Date()).toISOString(),
        errorMessage: providerRes.unconfigured ? "Verification provider credentials are not configured. Your wallet has been automatically refunded." : providerRes.message || "Verification provider could not be reached. Your wallet has been automatically refunded.",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.verificationRequests.unshift(failedReq);
      db.notifications.unshift({
        id: `notif_${Date.now()}`,
        userId: user.id,
        title: "Verification Refund Issued",
        message: `${service.name} verification could not reach the national registry gateway. Your wallet was refunded exactly ${requiredUnits} Credits (\u20A6${applicablePrice.toLocaleString()}).`,
        type: "VERIFICATION",
        isRead: false,
        link: "/verify/history",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      logAudit(
        user.fullName,
        user.role,
        "VERIFICATION_NOT_CALLED_REFUNDED",
        `Ref: ${verificationRef}. State: ${apiState}. Provider was not called. Exact refund issued: \u20A6${applicablePrice} (${requiredUnits} Credits).`,
        user.id,
        verificationRef,
        req.ip
      );
      saveDb();
      releaseLock(lockKey);
      return res.status(400).json({
        success: false,
        unconfigured: providerRes.unconfigured,
        error: failedReq.errorMessage,
        message: failedReq.errorMessage,
        verification: failedReq,
        request: failedReq
      });
    }
  } catch (err) {
    releaseLock(lockKey);
    console.warn("[Verification Exception]", err?.message || err);
    try {
      const db2 = getDb();
      const user2 = req.user;
      if (user2) {
        const wallet = db2.wallets.find((w) => w.userId === user2.id);
        const pendingReq = db2.verificationRequests.find((v) => v.idempotencyKey === cleanIdempotencyKey && v.status === "PENDING");
        if (wallet && pendingReq) {
          const refundAmount = pendingReq.amountCharged || 0;
          if (refundAmount > 0) {
            wallet.availableBalance += refundAmount;
            wallet.totalSpent -= refundAmount;
            wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            pendingReq.status = "FAILED";
            pendingReq.refundStatus = "REFUNDED";
            pendingReq.errorMessage = err.message || "System error occurred during verification processing.";
            pendingReq.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            db2.transactions.unshift({
              id: `txn_${Date.now()}_err_ref`,
              walletId: wallet.id,
              userId: user2.id,
              reference: `REF-${pendingReq.reference}`,
              type: "REFUND",
              amount: refundAmount,
              fee: 0,
              balanceBefore: wallet.availableBalance - refundAmount,
              balanceAfter: wallet.availableBalance,
              status: "SUCCESS",
              description: `Auto-refund for interrupted verification (${pendingReq.reference})`,
              createdAt: (/* @__PURE__ */ new Date()).toISOString()
            });
            saveDb();
          }
        }
      }
    } catch (refundErr) {
      console.warn("[Auto-refund Error]", refundErr?.message || refundErr);
    }
    return res.status(500).json({ error: err.message || "Something went wrong while processing verification. Please try again." });
  }
});
apiRouter.get("/verifications/history", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const list = db.verificationRequests.filter((v) => v.userId === user.id);
  res.json(list);
});
apiRouter.get("/verifications/my", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const limit = parseInt(req.query.limit, 10) || 50;
  const list = (db.verificationRequests || []).filter((v) => v.userId === user.id);
  res.json(list.slice(0, limit));
});
apiRouter.get(["/verifications/:id", "/verifications/result/:id"], requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const request = db.verificationRequests.find((v) => (v.id === req.params.id || v.reference === req.params.id) && (v.userId === user.id || user.role !== "USER"));
  if (!request) {
    return res.status(404).json({ error: "Verification record not found." });
  }
  const result = db.verificationResults.find((r) => r.requestId === request.id || r.reference === request.reference);
  res.json({ request, result, ...result ? { ...result } : {} });
});
apiRouter.get("/notifications", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const notifs = db.notifications.filter((n) => n.userId === user.id);
  res.json(notifs);
});
apiRouter.post("/notifications/:id/read", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const notif = db.notifications.find((n) => n.id === req.params.id && n.userId === user.id);
  if (notif) {
    notif.isRead = true;
    saveDb();
  }
  res.json({ success: true });
});
apiRouter.post("/notifications/read-all", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  db.notifications.forEach((n) => {
    if (n.userId === user.id) n.isRead = true;
  });
  saveDb();
  res.json({ success: true });
});
apiRouter.post("/support/tickets", requireAuth, (req, res) => {
  const { subject, category, message, attachmentUrl } = req.body;
  const user = req.user;
  const db = getDb();
  if (!subject || !message) {
    return res.status(400).json({ error: "Subject and message are required." });
  }
  const ticketNumber = `TCK-${Date.now().toString().slice(-6)}`;
  const ticket = {
    id: `tck_${Date.now()}`,
    ticketNumber,
    userId: user.id,
    userName: user.fullName,
    userEmail: user.email,
    subject: subject.trim(),
    category: category || "OTHER",
    status: "OPEN",
    priority: "NORMAL",
    messages: [
      {
        id: `msg_${Date.now()}`,
        senderId: user.id,
        senderName: user.fullName,
        senderRole: user.role,
        message: message.trim(),
        attachmentUrl: attachmentUrl || void 0,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    ],
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.supportTickets.unshift(ticket);
  logAudit(user.fullName, user.role, "SUPPORT_TICKET_CREATED", `Ticket #${ticketNumber}: ${subject}`, user.id, ticketNumber, req.ip);
  saveDb();
  res.status(201).json({ success: true, ticket });
});
apiRouter.get("/support/tickets", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  const tickets = db.supportTickets.filter((t) => t.userId === user.id);
  res.json(tickets);
});
apiRouter.post("/support/tickets/:id/message", requireAuth, (req, res) => {
  const { message, attachmentUrl } = req.body;
  const user = req.user;
  const db = getDb();
  const ticket = db.supportTickets.find((t) => t.id === req.params.id && (t.userId === user.id || user.role !== "USER"));
  if (!ticket) {
    return res.status(404).json({ error: "Support ticket not found." });
  }
  ticket.messages.push({
    id: `msg_${Date.now()}`,
    senderId: user.id,
    senderName: user.fullName,
    senderRole: user.role,
    message: String(message).trim(),
    attachmentUrl: attachmentUrl || void 0,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
  ticket.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  if (ticket.status === "RESOLVED" || ticket.status === "CLOSED") {
    ticket.status = "IN_PROGRESS";
  }
  saveDb();
  res.json({ success: true, ticket });
});
apiRouter.get(["/admin/metrics", "/admin/dashboard"], requireAdmin, (req, res) => {
  const db = getDb();
  const totalUsers = db.users.length;
  const activeUsers = db.users.filter((u) => u.status === "ACTIVE").length;
  const totalVerifications = db.verificationRequests.length;
  const successfulVerifications = db.verificationRequests.filter((v) => v.status === "SUCCESS").length;
  const failedVerifications = db.verificationRequests.filter((v) => v.status === "FAILED").length;
  const successRate = totalVerifications > 0 ? `${(successfulVerifications / totalVerifications * 100).toFixed(0)}%` : "100%";
  const totalRevenue = db.verificationRequests.filter((v) => v.status === "SUCCESS").reduce((acc, v) => acc + (v.amountCharged || 0), 0);
  const pendingFundingRequests = 0;
  const pendingVerifications = db.verificationRequests.filter((v) => v.status === "PENDING").length;
  const serviceStats = {};
  db.verificationRequests.forEach((v) => {
    serviceStats[v.serviceName] = (serviceStats[v.serviceName] || 0) + 1;
  });
  res.json({
    totalUsers,
    activeUsers,
    totalVerifications,
    successfulVerifications,
    failedVerifications,
    successRate,
    totalRevenue,
    pendingFundingRequests,
    pendingFunding: pendingFundingRequests,
    pendingVerifications,
    serviceStats,
    recentRequests: db.verificationRequests.slice(0, 8),
    recentFunding: []
  });
});
apiRouter.get("/admin/users", requireSuperAdmin, async (req, res) => {
  await syncAuthoritativeDataFromSupabase();
  const db = getDb();
  const q = String(req.query.q || "").toLowerCase();
  const requester = req.user;
  let usersList = db.users;
  if (requester.role === "SUPER_ADMIN") {
    usersList = usersList.filter((u) => u.role !== "MEGA_ADMIN" && u.role !== "SUPER_ADMIN");
  }
  let users = usersList.map((u) => {
    const wal = db.wallets.find((w) => w.userId === u.id);
    const prof = db.profiles.find((p) => p.userId === u.id);
    return {
      id: u.id,
      email: u.email,
      username: u.username,
      fullName: u.fullName,
      phone: u.phone,
      phone2: u.phone2,
      role: u.role,
      status: u.status,
      avatarUrl: u.avatarUrl || prof?.avatarUrl || "",
      onboardingStatus: u.onboardingStatus || (u.role === "MEGA_ADMIN" ? "approved" : "not_started"),
      onboardingApprovedAt: u.onboardingApprovedAt,
      onboardingApprovedBy: u.onboardingApprovedBy,
      roleAtApproval: u.roleAtApproval,
      assignedServices: u.assignedServices || [],
      satisfactionTitle: u.satisfactionTitle,
      dob: u.dob,
      nin: u.nin,
      lastActiveAt: u.lastActiveAt,
      lastLoginAt: u.lastLoginAt,
      walletBalance: wal?.availableBalance || 0,
      createdAt: u.createdAt
    };
  });
  if (q) {
    users = users.filter(
      (u) => u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.phone.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)
    );
  }
  res.json(users);
});
apiRouter.patch("/admin/users/:id/role", requireSuperAdmin, async (req, res) => {
  const { role } = req.body;
  const db = getDb();
  const requester = req.user;
  const targetUser = db.users.find((u) => u.id === req.params.id);
  if (!targetUser) return res.status(404).json({ error: "User not found." });
  const validRoles = ["USER", "AGENT", "ADMIN", "SUPER_ADMIN", "MEGA_ADMIN"];
  if (!role || !validRoles.includes(role)) {
    return res.status(400).json({ error: `Invalid role specified. Must be one of: ${validRoles.join(", ")}` });
  }
  if (role === "MEGA_ADMIN" || String(role).toUpperCase() === "MEGA_ADMIN") {
    return res.status(403).json({ error: "Security Violation: The Mega Admin role is permanent and exclusive. No account can be created or promoted to Mega Admin." });
  }
  if (targetUser.role === "MEGA_ADMIN" || targetUser.email.toLowerCase() === "ugochukwuoparaocha3@gmail.com" || targetUser.username === "/Mega//admin/ugopawaverify") {
    return res.status(403).json({ error: "Security Violation: The permanent Mega Administrator account cannot be modified or demoted." });
  }
  if (role === "SUPER_ADMIN" && requester.role !== "MEGA_ADMIN") {
    return res.status(403).json({ error: "Only the Mega Administrator can create or promote accounts to Super Admin." });
  }
  if (requester.role === "SUPER_ADMIN" && targetUser.role === "SUPER_ADMIN") {
    return res.status(403).json({ error: "Super Admins are not permitted to modify fellow Super Admin accounts." });
  }
  const previousRole = targetUser.role;
  const previousOnboardingStatus = targetUser.onboardingStatus;
  const previousRoleAtApproval = targetUser.roleAtApproval;
  const previousApprovedAt = targetUser.onboardingApprovedAt;
  const previousApprovedBy = targetUser.onboardingApprovedBy;
  const previousAssignedServices = [...targetUser.assignedServices || []];
  targetUser.role = role;
  targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  let onboardingRequired = false;
  if (role === "AGENT" || role === "ADMIN" || role === "SUPER_ADMIN") {
    targetUser.onboardingStatus = "not_started";
    targetUser.roleAtApproval = void 0;
    targetUser.onboardingApprovedAt = void 0;
    targetUser.onboardingApprovedBy = void 0;
    onboardingRequired = true;
  } else if (role === "USER") {
    if (previousOnboardingStatus === "approved") {
      targetUser.onboardingStatus = "approved";
      targetUser.onboardingApprovedAt = previousApprovedAt;
      targetUser.onboardingApprovedBy = previousApprovedBy;
      targetUser.roleAtApproval = previousRoleAtApproval;
    } else {
      targetUser.onboardingStatus = "not_started";
      targetUser.roleAtApproval = void 0;
      targetUser.onboardingApprovedAt = void 0;
      targetUser.onboardingApprovedBy = void 0;
    }
    targetUser.assignedServices = [];
    onboardingRequired = false;
  } else if (role === "MEGA_ADMIN") {
    targetUser.onboardingStatus = "approved";
    targetUser.onboardingApprovedBy = "SYSTEM OWNER / FOUNDER";
    onboardingRequired = false;
  }
  const supaRoleResult = await updateUserRoleInSupabase(targetUser.id, role, targetUser.onboardingStatus, targetUser.email);
  if (!supaRoleResult.success) {
    targetUser.role = previousRole;
    targetUser.onboardingStatus = previousOnboardingStatus;
    targetUser.roleAtApproval = previousRoleAtApproval;
    targetUser.onboardingApprovedAt = previousApprovedAt;
    targetUser.onboardingApprovedBy = previousApprovedBy;
    targetUser.assignedServices = previousAssignedServices;
    console.error(`[ROLE_CHANGE_ERROR] Authoritative Supabase update failed for ${targetUser.email}:`, supaRoleResult.error);
    return res.status(500).json({
      error: `Authoritative database update failed: ${supaRoleResult.error || "Unknown database error"}. Role change was not applied.`
    });
  }
  const supaSaveResult = await saveUserToSupabase(targetUser);
  if (!supaSaveResult.success) {
    targetUser.role = previousRole;
    targetUser.onboardingStatus = previousOnboardingStatus;
    targetUser.roleAtApproval = previousRoleAtApproval;
    targetUser.onboardingApprovedAt = previousApprovedAt;
    targetUser.onboardingApprovedBy = previousApprovedBy;
    targetUser.assignedServices = previousAssignedServices;
    console.error(`[ROLE_CHANGE_ERROR] Authoritative Supabase user profile save failed for ${targetUser.email}:`, supaSaveResult.error);
    return res.status(500).json({
      error: `Authoritative database persistence failed: ${supaSaveResult.error || "Unknown database error"}. Role change was not applied.`
    });
  }
  logAudit(
    requester.fullName,
    requester.role,
    "USER_ROLE_CHANGE",
    `Role changed for ${targetUser.email}: ${previousRole} -> ${role}`,
    targetUser.id,
    void 0,
    req.ip
  );
  saveDb();
  const onboardingNotice = role === "AGENT" ? "Agent onboarding required." : role === "ADMIN" ? "Admin onboarding required." : role === "SUPER_ADMIN" ? "Super Admin onboarding required." : role === "USER" ? "Account set to standard User. Privileged access removed." : "";
  res.json({
    success: true,
    message: `Account role for ${targetUser.fullName} updated to ${role}.${onboardingNotice ? " " + onboardingNotice : ""}`,
    onboardingRequired,
    user: {
      id: targetUser.id,
      email: targetUser.email,
      username: targetUser.username,
      fullName: targetUser.fullName,
      role: targetUser.role,
      status: targetUser.status,
      onboardingStatus: targetUser.onboardingStatus,
      assignedServices: targetUser.assignedServices || []
    }
  });
});
apiRouter.patch("/admin/users/:id/status", requireAdmin, async (req, res) => {
  const requester = req.user;
  const { status } = req.body;
  const db = getDb();
  const targetUser = db.users.find((u) => u.id === req.params.id);
  if (!targetUser) return res.status(404).json({ error: "User not found." });
  if (targetUser.role === "MEGA_ADMIN" || targetUser.email.toLowerCase() === "ugochukwuoparaocha3@gmail.com" || targetUser.username === "/Mega//admin/ugopawaverify" || targetUser.username?.toLowerCase() === "/mega//admin/ugopawaverify") {
    return res.status(403).json({ error: "Security Violation: Cannot pause, play, or suspend the permanent Mega Administrator account." });
  }
  if (requester.role === "ADMIN") {
    if (["ADMIN", "SUPER_ADMIN", "MEGA_ADMIN"].includes(targetUser.role)) {
      return res.status(403).json({ error: "Regular Administrators can only suspend or activate Customer and Agent accounts." });
    }
  } else if (requester.role === "SUPER_ADMIN") {
    if (targetUser.role === "SUPER_ADMIN") {
      return res.status(403).json({ error: "Super Admins cannot suspend fellow Super Admin or Mega Admin accounts." });
    }
  } else if (requester.role !== "MEGA_ADMIN") {
    return res.status(403).json({ error: "Unauthorized. Administrator privileges required." });
  }
  const validStatuses = ["ACTIVE", "PAUSED", "SUSPENDED"];
  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({ error: `Invalid status. Valid options: ${validStatuses.join(", ")}` });
  }
  const oldStatus = targetUser.status;
  targetUser.status = status;
  targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  logAudit(
    requester.fullName,
    requester.role,
    "USER_STATUS_CHANGE",
    `Account ${targetUser.email} status changed: ${oldStatus} -> ${status}`,
    targetUser.id,
    void 0,
    req.ip
  );
  saveDb();
  await updateUserStatusInSupabase(targetUser.id, status);
  await saveUserToSupabase(targetUser);
  const statusMsg = status === "SUSPENDED" ? "Account has been SUSPENDED. User is immediately blocked from logging in or accessing services." : status === "ACTIVE" ? "Account has been ACTIVATED and restored to normal access." : "Account has been PAUSED.";
  res.json({
    success: true,
    message: `User status changed to ${status}. ${statusMsg}`,
    user: {
      id: targetUser.id,
      email: targetUser.email,
      username: targetUser.username,
      status: targetUser.status,
      role: targetUser.role
    }
  });
});
apiRouter.delete("/admin/users/:id", requireAdmin, async (req, res) => {
  const db = getDb();
  const requester = req.user;
  const targetIndex = db.users.findIndex((u) => u.id === req.params.id);
  if (targetIndex === -1) return res.status(404).json({ error: "User not found." });
  const targetUser = db.users[targetIndex];
  if (targetUser.role === "MEGA_ADMIN" || targetUser.email.toLowerCase() === "ugochukwuoparaocha3@gmail.com" || targetUser.username === "/Mega//admin/ugopawaverify" || targetUser.username?.toLowerCase() === "/mega//admin/ugopawaverify") {
    return res.status(403).json({ error: "Security Violation: The permanent Mega Administrator account cannot be deleted." });
  }
  if (requester.role === "ADMIN") {
    if (["ADMIN", "SUPER_ADMIN", "MEGA_ADMIN"].includes(targetUser.role)) {
      return res.status(403).json({ error: "Regular Administrators cannot delete fellow Admin, Super Admin, or Mega Admin accounts." });
    }
  } else if (requester.role === "SUPER_ADMIN") {
    if (targetUser.role === "SUPER_ADMIN") {
      return res.status(403).json({ error: "Super Admins cannot delete fellow Super Admin or Mega Admin accounts." });
    }
  } else if (requester.role !== "MEGA_ADMIN") {
    return res.status(403).json({ error: "Unauthorized. Administrator privileges required." });
  }
  if (isSupabaseServiceRoleActive()) {
    const supaRes = await deleteUserFromSupabase(targetUser.id);
    if (!supaRes.success) {
      console.error("[USER_DELETE_ERROR] Supabase deleteUserFromSupabase failed:", supaRes.error);
      return res.status(500).json({
        error: `Authoritative database deletion failed: ${supaRes.error || "Failed to delete user from Supabase"}. Local account was kept intact.`
      });
    }
  }
  const profIndex = db.profiles.findIndex((p) => p.userId === targetUser.id);
  if (profIndex !== -1) db.profiles.splice(profIndex, 1);
  const walIndex = db.wallets.findIndex((w) => w.userId === targetUser.id);
  if (walIndex !== -1) db.wallets.splice(walIndex, 1);
  if (db.onboardingRequests) {
    db.onboardingRequests = db.onboardingRequests.filter((o) => o.userId !== targetUser.id);
  }
  db.users.splice(targetIndex, 1);
  logAudit(
    requester.fullName,
    requester.role,
    "USER_DELETED",
    `User account permanently deleted: ${targetUser.fullName} (${targetUser.email}, role: ${targetUser.role})`,
    targetUser.id,
    void 0,
    req.ip
  );
  saveDb();
  res.json({ success: true, message: `Account for ${targetUser.email} has been permanently deleted.` });
});
apiRouter.post("/admin/users/:id/wallet-adjust", requireAdmin, async (req, res) => {
  const { amount, type, reason } = req.body;
  const num = Number(amount);
  if (!num || num <= 0) return res.status(400).json({ error: "Valid amount is required." });
  const db = getDb();
  const targetUser = db.users.find((u) => u.id === req.params.id);
  if (!targetUser) return res.status(404).json({ error: "User not found." });
  const wallet = db.wallets.find((w) => w.userId === targetUser.id);
  if (!wallet) return res.status(404).json({ error: "Wallet not found." });
  const before = wallet.availableBalance;
  const isCredit = type === "CREDIT";
  if (!isCredit && wallet.availableBalance < num) {
    return res.status(400).json({ error: "Cannot debit more than available wallet balance." });
  }
  if (isCredit) {
    wallet.availableBalance += num;
    wallet.totalDeposited += num;
  } else {
    wallet.availableBalance -= num;
    wallet.totalSpent += num;
  }
  wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const ref = `ADJ-${Date.now().toString().slice(-6)}`;
  db.transactions.unshift({
    id: `txn_${Date.now()}`,
    walletId: wallet.id,
    userId: targetUser.id,
    reference: ref,
    type: "ADJUSTMENT",
    amount: isCredit ? num : -num,
    fee: 0,
    balanceBefore: before,
    balanceAfter: wallet.availableBalance,
    status: "SUCCESS",
    description: `Admin manual adjustment: ${reason || "Customer balance review"}`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: targetUser.id,
    title: isCredit ? "Wallet Credited by Admin" : "Wallet Debited by Admin",
    message: `Your balance was ${isCredit ? "credited with" : "debited by"} \u20A6${num.toLocaleString()}. Reason: ${reason || "Administrative adjustment"}`,
    type: "WALLET",
    isRead: false,
    link: "/wallet",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(req.user.fullName, req.user.role, "WALLET_MANUAL_ADJUSTMENT", `${isCredit ? "Credit" : "Debit"} \u20A6${num} for ${targetUser.email}. Reason: ${reason}`, targetUser.id, ref, req.ip);
  saveDb();
  await saveWalletToSupabase(wallet);
  await insertTransactionToSupabase(db.transactions[0]);
  res.json({ success: true, message: `Wallet balance adjusted to \u20A6${wallet.availableBalance.toLocaleString()}.`, wallet });
});
apiRouter.post("/admin/agents/:id/services/online-nin", requireSuperAdmin, (req, res) => {
  const db = getDb();
  const targetUser = db.users.find((u) => u.id === req.params.id);
  if (!targetUser) return res.status(404).json({ error: "Agent account not found." });
  if (targetUser.role !== "AGENT" && targetUser.role !== "ADMIN") {
    return res.status(400).json({ error: "Online NIN Registration can only be assigned to Agent or Admin accounts." });
  }
  if (!targetUser.assignedServices) targetUser.assignedServices = [];
  if (!targetUser.assignedServices.includes("ONLINE_NIN_REGISTRATION")) {
    targetUser.assignedServices.push("ONLINE_NIN_REGISTRATION");
    targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    logAudit(
      req.user.fullName,
      req.user.role,
      "AGENT_SERVICE_ASSIGNED",
      `Assigned Online NIN Registration service to ${targetUser.fullName} (${targetUser.email})`,
      targetUser.id,
      void 0,
      req.ip
    );
    db.notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: targetUser.id,
      title: "Online NIN Registration Service Assigned",
      message: `Your account has been authorized to process Online NIN Registrations by ${req.user.fullName}.`,
      type: "SECURITY",
      isRead: false,
      link: "/services",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    saveDb();
  }
  res.json({
    success: true,
    message: `Online NIN Registration service assigned to @${targetUser.username} successfully.`,
    assignedServices: targetUser.assignedServices
  });
});
apiRouter.delete("/admin/agents/:id/services/online-nin", requireSuperAdmin, (req, res) => {
  const db = getDb();
  const targetUser = db.users.find((u) => u.id === req.params.id);
  if (!targetUser) return res.status(404).json({ error: "Agent account not found." });
  if (!targetUser.assignedServices) targetUser.assignedServices = [];
  targetUser.assignedServices = targetUser.assignedServices.filter((s) => s !== "ONLINE_NIN_REGISTRATION");
  targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  logAudit(
    req.user.fullName,
    req.user.role,
    "AGENT_SERVICE_REMOVED",
    `Removed Online NIN Registration service from ${targetUser.fullName} (${targetUser.email})`,
    targetUser.id,
    void 0,
    req.ip
  );
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: targetUser.id,
    title: "Service Assignment Revoked",
    message: `The Online NIN Registration service was removed from your account by ${req.user.fullName}.`,
    type: "SECURITY",
    isRead: false,
    link: "/services",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  saveDb();
  res.json({
    success: true,
    message: `Online NIN Registration service removed from @${targetUser.username}.`,
    assignedServices: targetUser.assignedServices
  });
});
function cleanNameForComparison(name) {
  if (!name) return "";
  return name.toLowerCase().replace(/^(mr|mrs|ms|miss|dr|prof|chief|alhaji|hajiya|mallam|engr|barr|arc|pst|rev)\.?\s+/i, "").replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function normalizeDob(dobStr) {
  if (!dobStr) return "";
  const clean = String(dobStr).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) return clean;
  if (/^\d{4}\/\d{2}\/\d{2}$/.test(clean)) return clean.replace(/\//g, "-");
  const parts = clean.split(/[-/.]/);
  if (parts.length === 3) {
    if (parts[0].length === 4) {
      const y = parts[0];
      const m = parts[1].padStart(2, "0");
      const d = parts[2].padStart(2, "0");
      return `${y}-${m}-${d}`;
    } else if (parts[2].length === 4) {
      const d = parts[0].padStart(2, "0");
      const m = parts[1].padStart(2, "0");
      const y = parts[2];
      return `${y}-${m}-${d}`;
    }
  }
  return clean;
}
function verifyIdentityName(submittedFullName, verifiedFullName, verifiedFirstName, verifiedSurname) {
  const subClean = cleanNameForComparison(submittedFullName);
  const verClean = cleanNameForComparison(verifiedFullName);
  if (!subClean || !verClean) {
    return { match: false, code: "IDENTITY_MISMATCH" };
  }
  if (subClean === verClean) {
    return { match: true, code: "IDENTITY_MATCH" };
  }
  const subTokens = subClean.split(" ").filter((t) => t.length > 1);
  const verTokens = verClean.split(" ").filter((t) => t.length > 1);
  if (subTokens.length === 0 || verTokens.length === 0) {
    return { match: false, code: "IDENTITY_MISMATCH" };
  }
  const sortedSub = [...subTokens].sort().join(" ");
  const sortedVer = [...verTokens].sort().join(" ");
  if (sortedSub === sortedVer) {
    return { match: true, code: "IDENTITY_MATCH" };
  }
  if (verifiedFirstName && verifiedSurname) {
    const fnClean = cleanNameForComparison(verifiedFirstName);
    const snClean = cleanNameForComparison(verifiedSurname);
    if (fnClean && snClean) {
      const hasFirst = subTokens.includes(fnClean);
      const hasSurname = subTokens.includes(snClean);
      if (hasFirst && hasSurname) {
        return { match: true, code: "IDENTITY_MATCH" };
      }
    }
  }
  const common = subTokens.filter((token) => verTokens.includes(token));
  if (common.length >= 2 && (common.length === subTokens.length || common.length === verTokens.length)) {
    return { match: true, code: "IDENTITY_MATCH" };
  }
  return { match: false, code: "IDENTITY_MISMATCH" };
}
function terminateOnboardingSession(user, reason) {
  const db = getDb();
  user.onboardingTerminated = true;
  user.onboardingTerminationReason = reason;
  user.onboardingStatus = "cancelled";
  user.role = "USER";
  user.phone1Verified = false;
  user.phone1VerifiedNumber = void 0;
  user.pendingRoleEntry = void 0;
  user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  saveDb();
  logAudit(
    user.fullName,
    "USER",
    "ONBOARDING_TERMINATED",
    `Onboarding terminated after reaching maximum failed attempts limit. Reason: ${reason}. Returned to normal USER role.`,
    user.id
  );
}
apiRouter.get("/onboarding/me", requireAuth, (req, res) => {
  const db = getDb();
  const user = req.user;
  const latest = (db.onboardingRequests || []).find((o) => o.userId === user.id);
  const userWallet = db.wallets.find((w) => w.userId === user.id);
  let targetRole = "AGENT";
  let feeRequired = 2.5;
  if (user.role === "SUPER_ADMIN" || user.pendingRoleEntry?.targetRole === "SUPER_ADMIN") {
    targetRole = "SUPER_ADMIN";
    feeRequired = 5.3;
  } else if (user.role === "ADMIN" || user.pendingRoleEntry?.targetRole === "ADMIN") {
    targetRole = "ADMIN";
    feeRequired = 5;
  } else {
    targetRole = "AGENT";
    feeRequired = 2.5;
  }
  res.json({
    onboardingStatus: user.onboardingStatus || (user.role === "MEGA_ADMIN" ? "approved" : "not_started"),
    onboardingApprovedAt: user.onboardingApprovedAt,
    onboardingApprovedBy: user.onboardingApprovedBy,
    roleAtApproval: user.roleAtApproval,
    satisfactionTitle: user.satisfactionTitle,
    dob: user.dob,
    nin: user.nin,
    application: latest || null,
    // Server-side attempt tracking & security
    onboardingOtpAttempts: user.onboardingOtpAttempts || 0,
    onboardingNinAttempts: user.onboardingNinAttempts || 0,
    onboardingTerminated: !!user.onboardingTerminated,
    onboardingTerminationReason: user.onboardingTerminationReason || null,
    phone1Verified: !!user.phone1Verified,
    phone1VerifiedNumber: user.phone1VerifiedNumber || null,
    walletBalance: userWallet ? userWallet.availableBalance : 0,
    targetRole,
    feeRequired
  });
});
apiRouter.post("/onboarding/phone-otp/send", requireAuth, async (req, res) => {
  const { phone1 } = req.body;
  const user = req.user;
  if (user.onboardingTerminated) {
    return res.status(403).json({
      error: "Your onboarding session has been terminated because the maximum attempt limit was reached. Your account has returned to its normal customer role.",
      terminated: true
    });
  }
  const cleanPhone = String(phone1 || "").replace(/\s+/g, "").trim();
  if (!cleanPhone || cleanPhone.length < 10) {
    return res.status(400).json({ error: "A valid active Nigerian mobile phone number is required (e.g. 08012345678)." });
  }
  const result = await sendSendchampOtp(user.id, cleanPhone);
  if (!result.success) {
    return res.status(result.unconfigured ? 503 : 400).json({
      error: result.message,
      cooldownSeconds: result.cooldownSeconds
    });
  }
  return res.json({
    success: true,
    message: result.message,
    normalizedPhone: result.normalizedPhone,
    displayPhone: result.displayPhone,
    cooldownSeconds: result.cooldownSeconds || 60
  });
});
apiRouter.post("/onboarding/phone-otp/verify", requireAuth, async (req, res) => {
  const { phone1, otp } = req.body;
  const user = req.user;
  if (user.onboardingTerminated) {
    return res.status(403).json({
      error: "Your onboarding session has been terminated because the maximum attempt limit was reached. Your account has returned to its normal customer role.",
      terminated: true
    });
  }
  const cleanPhone = String(phone1 || "").replace(/\s+/g, "").trim();
  const cleanOtp = String(otp || "").trim();
  if (!cleanPhone) {
    return res.status(400).json({ error: "Phone number is required." });
  }
  if (!cleanOtp) {
    return res.status(400).json({ error: "Please enter the 6-digit OTP code received on your phone." });
  }
  const result = await verifySendchampOtp(user.id, cleanPhone, cleanOtp);
  if (!result.success || !result.verified) {
    user.onboardingOtpAttempts = (user.onboardingOtpAttempts || 0) + 1;
    saveDb();
    if (user.onboardingOtpAttempts >= 2) {
      terminateOnboardingSession(
        user,
        "Reached maximum 2 failed SMS OTP attempts during onboarding."
      );
      return res.status(400).json({
        error: "You have exceeded the maximum limit of 2 failed SMS OTP attempts. Your onboarding session has been terminated and your account has been returned to its normal customer role.",
        terminated: true,
        onboardingOtpAttempts: user.onboardingOtpAttempts
      });
    }
    return res.status(400).json({
      error: "Invalid or incorrect OTP code. You have 1 attempt remaining out of 2 before your onboarding session is terminated.",
      verified: false,
      remainingAttempts: 1,
      terminated: false,
      onboardingOtpAttempts: user.onboardingOtpAttempts
    });
  }
  user.phone1Verified = true;
  user.phone1VerifiedNumber = cleanPhone;
  user.onboardingOtpAttempts = 0;
  saveDb();
  return res.json({
    success: true,
    verified: true,
    message: "Phone number verified successfully via Sendchamp SMS OTP!",
    normalizedPhone: result.normalizedPhone,
    phone1VerifiedNumber: cleanPhone
  });
});
apiRouter.post("/onboarding/verify-nin", requireAuth, async (req, res) => {
  const { nin, fullName, dob, phone1 } = req.body;
  const user = req.user;
  if (user.onboardingTerminated) {
    return res.status(403).json({
      error: "Your onboarding session has been terminated because the maximum attempt limit was reached. Your account has returned to its normal customer role.",
      terminated: true
    });
  }
  const cleanSubmittedPhone = String(phone1 || user.phone1VerifiedNumber || "").replace(/\D/g, "").trim();
  const cleanStoredPhone = String(user.phone1VerifiedNumber || "").replace(/\D/g, "").trim();
  if (!user.phone1Verified || !cleanStoredPhone || cleanSubmittedPhone && cleanSubmittedPhone !== cleanStoredPhone) {
    return res.status(400).json({
      error: "Please verify your phone number before continuing.",
      code: "PHONE_NOT_VERIFIED"
    });
  }
  const cleanNin = String(nin || "").replace(/\D/g, "").trim();
  if (cleanNin.length !== 11) {
    return res.status(400).json({ error: "NIN must be an exact 11-digit number." });
  }
  if (!fullName || !String(fullName).trim()) {
    return res.status(400).json({ error: "Full Name is required for identity comparison." });
  }
  if (!dob || !String(dob).trim()) {
    return res.status(400).json({ error: "Date of Birth is required for identity comparison." });
  }
  try {
    const ninResult = await providerAdapter.verifyNIN(cleanNin);
    if (!ninResult || !ninResult.success || !ninResult.data) {
      return res.status(400).json({
        error: `NIN Verification Failed: ${ninResult?.message || "Unable to verify NIN with the National Identity Registry. Please ensure the 11-digit NIN is active and valid."}`,
        code: "PROVIDER_ERROR",
        providerMessage: ninResult?.message
      });
    }
    const canonical = ninResult.data;
    if (!canonical.fullName && !canonical.firstName && !canonical.surname) {
      return res.status(400).json({
        error: "National Identity Registry returned an identity record with missing name information. Please contact NIMC support.",
        code: "PROVIDER_DATA_MISSING",
        field: "name"
      });
    }
    if (!canonical.dateOfBirth) {
      return res.status(400).json({
        error: "National Identity Registry returned an identity record without a verifiable Date of Birth. Technical verification cannot proceed.",
        code: "PROVIDER_DATA_MISSING",
        field: "dateOfBirth"
      });
    }
    const normSubmittedDob = normalizeDob(dob);
    const normVerifiedDob = normalizeDob(canonical.dateOfBirth);
    const isDobMatch = Boolean(normSubmittedDob && normVerifiedDob && normSubmittedDob === normVerifiedDob);
    const verifiedDisplay = canonical.fullName || [canonical.firstName, canonical.middleName, canonical.surname].filter(Boolean).join(" ");
    const nameCheck = verifyIdentityName(fullName, verifiedDisplay, canonical.firstName, canonical.surname);
    if (!isDobMatch || !nameCheck.match) {
      user.onboardingNinAttempts = (user.onboardingNinAttempts || 0) + 1;
      saveDb();
      const mismatchDetail = !isDobMatch ? `The submitted Date of Birth ("${dob}") does not match the Date of Birth returned from the National Identity Registry ("${canonical.dateOfBirth}").` : `The submitted Full Name ("${fullName}") does not match the name returned from the National Identity Registry ("${verifiedDisplay || "Unknown"}").`;
      if (user.onboardingNinAttempts >= 2) {
        terminateOnboardingSession(
          user,
          `Reached maximum 2 failed NIN information mismatch attempts. Last mismatch: ${mismatchDetail}`
        );
        return res.status(400).json({
          error: `Identity Validation Failed: ${mismatchDetail} You have exceeded the maximum limit of 2 failed NIN-mismatch attempts. Your onboarding session has been terminated and your account has been returned to its normal customer role.`,
          code: "IDENTITY_MISMATCH",
          terminated: true,
          onboardingNinAttempts: user.onboardingNinAttempts
        });
      }
      return res.status(400).json({
        error: `Identity Validation Failed: ${mismatchDetail} You have 1 attempt remaining out of 2 before your onboarding session is terminated.`,
        code: "IDENTITY_MISMATCH",
        remainingAttempts: 1,
        terminated: false,
        onboardingNinAttempts: user.onboardingNinAttempts,
        reason: !isDobMatch ? "DOB_MISMATCH" : "NAME_MISMATCH"
      });
    }
    user.onboardingNinAttempts = 0;
    saveDb();
    return res.json({
      success: true,
      verified: true,
      data: {
        verifiedFullName: verifiedDisplay,
        verifiedDob: canonical.dateOfBirth,
        verifiedNinStatus: "VERIFIED",
        photoUrl: canonical.photoUrl || null,
        nin: cleanNin,
        nameMatch: true,
        dobMatch: true
      }
    });
  } catch (err) {
    return res.status(500).json({
      error: `Verification system error during NIN validation: ${err.message || "Please try again later."}`
    });
  }
});
apiRouter.post("/onboarding/submit", requireAuth, async (req, res) => {
  const user = req.user;
  const db = getDb();
  if (user.onboardingStatus === "approved") {
    return res.status(400).json({
      error: "Your onboarding has already been approved. You do not need to onboard again."
    });
  }
  const {
    fullName,
    dob,
    phone1,
    phone2,
    profilePhoto,
    nin,
    certificates,
    satisfactionTitle,
    // Step 1: Residential Address
    residentialHouseNumber,
    residentialStreet,
    residentialCity,
    residentialState,
    residentialLga,
    // Step 2: State of Origin
    stateOfOrigin,
    lgaOfOrigin,
    // Step 3: Emergency / Reference Contact
    emergencyFullName,
    emergencyPhone,
    emergencyRelationship,
    // Step 6 & 7: Declarations
    declarationAccepted,
    reviewConfirmed
  } = req.body;
  if (!fullName || !String(fullName).trim()) {
    return res.status(400).json({ error: "Full Name is required." });
  }
  if (!dob || !String(dob).trim()) {
    return res.status(400).json({ error: "Date of Birth is required." });
  }
  if (!phone1 || !String(phone1).trim()) {
    return res.status(400).json({ error: "Phone Number 1 is required." });
  }
  if (!profilePhoto || !String(profilePhoto).trim()) {
    return res.status(400).json({ error: "Profile Photo is required." });
  }
  if (!nin || !String(nin).trim()) {
    return res.status(400).json({ error: "NIN (National Identity Number) is required." });
  }
  if (!satisfactionTitle || !String(satisfactionTitle).trim()) {
    return res.status(400).json({ error: "Satisfaction/Title is required." });
  }
  if (!residentialHouseNumber || !String(residentialHouseNumber).trim()) {
    return res.status(400).json({ error: "House/Building Number is required." });
  }
  if (!residentialStreet || !String(residentialStreet).trim()) {
    return res.status(400).json({ error: "Street Address is required." });
  }
  if (!residentialCity || !String(residentialCity).trim()) {
    return res.status(400).json({ error: "Town/City is required." });
  }
  if (!residentialState || !String(residentialState).trim()) {
    return res.status(400).json({ error: "Residential State is required." });
  }
  if (!residentialLga || !String(residentialLga).trim()) {
    return res.status(400).json({ error: "Residential LGA is required." });
  }
  if (!stateOfOrigin || !String(stateOfOrigin).trim()) {
    return res.status(400).json({ error: "State of Origin is required." });
  }
  if (!lgaOfOrigin || !String(lgaOfOrigin).trim()) {
    return res.status(400).json({ error: "LGA of Origin is required." });
  }
  if (!emergencyFullName || !String(emergencyFullName).trim()) {
    return res.status(400).json({ error: "Emergency / Reference Contact Full Name is required." });
  }
  if (!emergencyPhone || !String(emergencyPhone).trim()) {
    return res.status(400).json({ error: "Emergency / Reference Contact Phone Number is required." });
  }
  if (!emergencyRelationship || !String(emergencyRelationship).trim()) {
    return res.status(400).json({ error: "Emergency / Reference Contact Relationship is required." });
  }
  const cleanPhone1Digits = String(phone1).replace(/\D/g, "");
  const cleanEmergencyDigits = String(emergencyPhone).replace(/\D/g, "");
  if (cleanPhone1Digits === cleanEmergencyDigits) {
    return res.status(400).json({
      error: "The emergency reference phone number must not be the same as Phone Number 1."
    });
  }
  if (!isPhoneVerifiedForUser(user.id, String(phone1))) {
    return res.status(400).json({
      error: "Phone Number 1 must be verified with an active SMS OTP before final submission.",
      code: "PHONE_NOT_VERIFIED"
    });
  }
  if (!declarationAccepted) {
    return res.status(400).json({
      error: "You must confirm that all information and documents provided are correct, genuine and belong to you.",
      code: "DECLARATION_REQUIRED"
    });
  }
  if (!reviewConfirmed) {
    return res.status(400).json({
      error: "You must confirm that you have reviewed your information before submitting.",
      code: "REVIEW_CONFIRMATION_REQUIRED"
    });
  }
  const cleanNin = String(nin).replace(/\D/g, "").trim();
  if (cleanNin.length !== 11) {
    return res.status(400).json({ error: "NIN must be an exact 11-digit number." });
  }
  let roleTarget = "AGENT";
  let requiredCredits = 2.5;
  let roleDisplay = "Agent";
  if (user.role === "SUPER_ADMIN" || user.pendingRoleEntry?.targetRole === "SUPER_ADMIN") {
    roleTarget = "SUPER_ADMIN";
    requiredCredits = 5.3;
    roleDisplay = "Super Admin";
  } else if (user.role === "ADMIN" || user.pendingRoleEntry?.targetRole === "ADMIN") {
    roleTarget = "ADMIN";
    requiredCredits = 5;
    roleDisplay = "Admin";
  } else {
    roleTarget = "AGENT";
    requiredCredits = 2.5;
    roleDisplay = "Agent";
  }
  const userWallet = db.wallets.find((w) => w.userId === user.id);
  const currentBalance = userWallet ? userWallet.availableBalance : 0;
  if (currentBalance < requiredCredits) {
    return res.status(402).json({
      success: false,
      code: "INSUFFICIENT_CREDITS",
      requiredCredits,
      currentBalance,
      targetRole: roleTarget,
      roleDisplay,
      error: `Insufficient Credits. You need ${requiredCredits} Credits to enter ${roleDisplay}. Please fund your wallet to continue.`,
      redirectUrl: "/wallet/fund"
    });
  }
  try {
    const ninResult = await providerAdapter.verifyNIN(cleanNin);
    if (!ninResult || !ninResult.success || !ninResult.data) {
      return res.status(400).json({
        error: `NIN Identity Verification Failed: ${ninResult?.message || "Unable to verify NIN with the National Identity Registry. Please ensure the 11-digit NIN is active and valid."}`,
        code: "PROVIDER_ERROR",
        providerMessage: ninResult?.message
      });
    }
    const canonical = ninResult.data;
    if (!canonical.fullName && !canonical.firstName && !canonical.surname) {
      return res.status(400).json({
        error: "National Identity Registry returned an identity record with missing name information. Please contact NIMC support.",
        code: "PROVIDER_DATA_MISSING",
        field: "name"
      });
    }
    if (!canonical.dateOfBirth) {
      return res.status(400).json({
        error: "National Identity Registry returned an identity record without a verifiable Date of Birth. Technical verification cannot proceed.",
        code: "PROVIDER_DATA_MISSING",
        field: "dateOfBirth"
      });
    }
    const normSubmittedDob = normalizeDob(dob);
    const normVerifiedDob = normalizeDob(canonical.dateOfBirth);
    const isDobMatch = Boolean(normSubmittedDob && normVerifiedDob && normSubmittedDob === normVerifiedDob);
    if (!isDobMatch) {
      return res.status(400).json({
        error: `Identity Validation Failed: The submitted Date of Birth ("${dob}") does not match the Date of Birth returned from the National Identity Registry ("${canonical.dateOfBirth}"). Onboarding denied.`,
        code: "IDENTITY_MISMATCH",
        reason: "DOB_MISMATCH",
        submittedDob: dob,
        verifiedDob: canonical.dateOfBirth
      });
    }
    const verifiedDisplay = canonical.fullName || [canonical.firstName, canonical.middleName, canonical.surname].filter(Boolean).join(" ");
    const nameCheck = verifyIdentityName(fullName, verifiedDisplay, canonical.firstName, canonical.surname);
    if (!nameCheck.match) {
      return res.status(400).json({
        error: `Identity Validation Failed: The submitted Full Name ("${fullName}") does not match the name returned from the National Identity Registry ("${verifiedDisplay || "Unknown"}"). Onboarding denied.`,
        code: "IDENTITY_MISMATCH",
        reason: "NAME_MISMATCH",
        submittedName: fullName,
        verifiedName: verifiedDisplay
      });
    }
    const residentialFullAddress = `${String(residentialHouseNumber).trim()} ${String(residentialStreet).trim()}, ${String(residentialCity).trim()}, ${String(residentialLga).trim()}, ${String(residentialState).trim()}`;
    if (!db.onboardingRequests) db.onboardingRequests = [];
    const existingIdx = db.onboardingRequests.findIndex((o) => o.userId === user.id);
    const onboardingRecord = {
      id: `onb_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: user.id,
      userEmail: user.email,
      userFullName: user.fullName,
      targetRole: roleTarget,
      fullName: String(fullName).trim(),
      dob: normSubmittedDob,
      phone1: String(phone1).trim(),
      phone2: phone2 ? String(phone2).trim() : void 0,
      profilePhoto: String(profilePhoto).trim(),
      nin: cleanNin,
      certificates: Array.isArray(certificates) ? certificates : [],
      satisfactionTitle: String(satisfactionTitle).trim(),
      // Residential Address
      residentialHouseNumber: String(residentialHouseNumber).trim(),
      residentialStreet: String(residentialStreet).trim(),
      residentialCity: String(residentialCity).trim(),
      residentialState: String(residentialState).trim(),
      residentialLga: String(residentialLga).trim(),
      residentialFullAddress,
      // Origin
      stateOfOrigin: String(stateOfOrigin).trim(),
      lgaOfOrigin: String(lgaOfOrigin).trim(),
      // Emergency / Reference Contact
      emergencyFullName: String(emergencyFullName).trim(),
      emergencyPhone: String(emergencyPhone).trim(),
      emergencyRelationship: String(emergencyRelationship).trim(),
      // OTP & Declarations
      phoneVerified: true,
      phoneVerifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
      declarationAccepted: true,
      reviewConfirmed: true,
      // Registry Verification
      ninVerified: true,
      ninVerifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
      ninResultData: canonical,
      ninPhotoUrl: canonical.photoUrl || void 0,
      ninFullName: verifiedDisplay,
      ninDob: canonical.dateOfBirth,
      ninComparisonMatch: true,
      nameMatch: true,
      dobMatch: true,
      status: "approved",
      submittedAt: (/* @__PURE__ */ new Date()).toISOString(),
      reviewedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (existingIdx !== -1) {
      db.onboardingRequests[existingIdx] = onboardingRecord;
    } else {
      db.onboardingRequests.unshift(onboardingRecord);
    }
    if (userWallet) {
      userWallet.availableBalance = Number((userWallet.availableBalance - requiredCredits).toFixed(2));
      userWallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      const unitValueNgn = db.settings.unitValueNgn || 200;
      const feeNgn = Number((requiredCredits * unitValueNgn).toFixed(2));
      db.transactions.unshift({
        id: `tx_onb_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        walletId: userWallet.id,
        userId: user.id,
        type: "SERVICE_REQUEST",
        amount: -requiredCredits,
        fee: 0,
        balanceBefore: userWallet.availableBalance + requiredCredits,
        balanceAfter: userWallet.availableBalance,
        status: "SUCCESS",
        reference: `ONB-ENTRY-${Date.now()}`,
        description: `Official entry fee charge of ${requiredCredits} Credits for immediate activation of ${roleDisplay} account.`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    user.role = roleTarget;
    user.onboardingStatus = "approved";
    user.onboardingApprovedAt = (/* @__PURE__ */ new Date()).toISOString();
    user.onboardingApprovedBy = `Auto-Activated via Entry Fee (${requiredCredits} Credits)`;
    user.roleAtApproval = roleTarget;
    user.onboardingTerminated = false;
    user.onboardingOtpAttempts = 0;
    user.onboardingNinAttempts = 0;
    user.satisfactionTitle = String(satisfactionTitle).trim();
    user.phone = String(phone1).trim();
    if (phone2) user.phone2 = String(phone2).trim();
    user.dob = normSubmittedDob;
    user.nin = cleanNin;
    if (profilePhoto) user.avatarUrl = String(profilePhoto).trim();
    user.address = residentialFullAddress;
    user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    logAudit(
      user.fullName,
      user.role,
      "ONBOARDING_COMPLETED_AND_ACTIVATED",
      `Onboarding completed and entry fee of ${requiredCredits} Credits deducted. Role ${roleTarget} immediately activated.`,
      user.id,
      void 0,
      req.ip
    );
    db.notifications.unshift({
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: user.id,
      title: "Onboarding Completed & Role Activated!",
      message: `Your ${roleDisplay} account is now active. ${requiredCredits} Credits were deducted from your wallet balance.`,
      type: "SECURITY",
      isRead: false,
      link: roleTarget === "ADMIN" || roleTarget === "SUPER_ADMIN" ? "/admin" : "/dashboard",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    const onbRes = await updateUserOnboardingInSupabase(user.id, "approved", void 0, void 0, user.email);
    if (!onbRes.success) {
      console.warn("[ONBOARDING_SUBMIT] Supabase update warning:", onbRes.error);
    }
    const saveRes = await saveUserToSupabase(user);
    if (!saveRes.success) {
      console.warn("[ONBOARDING_SUBMIT] Supabase saveUser warning:", saveRes.error);
    }
    if (isSupabaseServiceRoleActive()) {
      await saveOnboardingApplicationToSupabase(onboardingRecord);
    }
    saveDb();
    res.json({
      success: true,
      activatedRole: user.role,
      balance: userWallet ? userWallet.availableBalance : 0,
      feeDeducted: requiredCredits,
      message: `Onboarding completed successfully! ${requiredCredits} Credits deducted. Your ${roleDisplay} role has been immediately activated.`,
      onboarding: onboardingRecord
    });
  } catch (err) {
    return res.status(500).json({
      error: `Verification system error during NIN validation: ${err.message || "Please try again later."}`
    });
  }
});
apiRouter.get("/admin/onboarding", requireSuperAdmin, async (req, res) => {
  if (isSupabaseServiceRoleActive()) {
    const supaApps = await fetchSupabaseOnboardingApplications();
    if (supaApps && supaApps.length > 0) {
      const db2 = getDb();
      db2.onboardingRequests = supaApps;
      return res.json(supaApps);
    }
  }
  const db = getDb();
  res.json(db.onboardingRequests || []);
});
apiRouter.get("/admin/onboarding/:id", requireSuperAdmin, (req, res) => {
  const db = getDb();
  const app = (db.onboardingRequests || []).find((o) => o.id === req.params.id || o.userId === req.params.id);
  if (!app) return res.status(404).json({ error: "Onboarding application not found." });
  res.json(app);
});
apiRouter.patch("/admin/onboarding/:id/approve", requireSuperAdmin, async (req, res) => {
  const { approvedRole, adminNote } = req.body;
  const requester = req.user;
  const db = getDb();
  const app = (db.onboardingRequests || []).find((o) => o.id === req.params.id || o.userId === req.params.id);
  if (!app) return res.status(404).json({ error: "Onboarding application not found." });
  const targetUser = db.users.find((u) => u.id === app.userId);
  if (!targetUser) return res.status(404).json({ error: "Target user account not found." });
  const roleToAssign = approvedRole || app.targetRole || "AGENT";
  if (requester.role === "SUPER_ADMIN") {
    if (roleToAssign !== "AGENT" && roleToAssign !== "ADMIN") {
      return res.status(403).json({ error: "Super Admin can only approve onboarding as AGENT or ADMIN." });
    }
  }
  if (roleToAssign !== "AGENT" && roleToAssign !== "ADMIN") {
    return res.status(400).json({ error: "Approved role must be either AGENT or ADMIN." });
  }
  targetUser.role = roleToAssign;
  targetUser.onboardingStatus = "approved";
  targetUser.onboardingApprovedAt = (/* @__PURE__ */ new Date()).toISOString();
  targetUser.onboardingApprovedBy = `${requester.fullName} (${requester.role})`;
  targetUser.roleAtApproval = roleToAssign;
  if (!targetUser.assignedServices) targetUser.assignedServices = [];
  targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  app.status = "approved";
  app.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
  app.reviewedBy = requester.id;
  app.reviewedByName = requester.fullName;
  app.reviewedByRole = requester.role;
  app.roleAtApproval = roleToAssign;
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: targetUser.id,
    title: "Onboarding Approved!",
    message: `Congratulations! Your onboarding has been approved by ${requester.fullName}. Your account is now an active ${roleToAssign}.`,
    type: "SECURITY",
    isRead: false,
    link: roleToAssign === "ADMIN" ? "/admin" : "/dashboard",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    requester.fullName,
    requester.role,
    "ONBOARDING_APPROVED",
    `Approved onboarding for ${targetUser.email} -> Upgraded to ${roleToAssign}. ${adminNote ? `Note: ${adminNote}` : ""}`,
    targetUser.id,
    void 0,
    req.ip
  );
  const onbRes = await updateUserOnboardingInSupabase(targetUser.id, "approved", targetUser.onboardingApprovedBy, roleToAssign, targetUser.email);
  if (!onbRes.success) {
    console.error("[ONBOARDING_APPROVAL_ERROR] Supabase onboarding update failed:", onbRes.error);
    return res.status(500).json({ error: `Failed to update onboarding status in database: ${onbRes.error}` });
  }
  const roleRes = await updateUserRoleInSupabase(targetUser.id, roleToAssign, "approved", targetUser.email);
  if (!roleRes.success) {
    console.error("[ONBOARDING_APPROVAL_ERROR] Supabase role update failed:", roleRes.error);
    return res.status(500).json({ error: `Failed to update user role in database: ${roleRes.error}` });
  }
  const saveRes = await saveUserToSupabase(targetUser);
  if (!saveRes.success) {
    console.error("[ONBOARDING_APPROVAL_ERROR] Supabase user profile save failed:", saveRes.error);
    return res.status(500).json({ error: `Failed to persist user profile in database: ${saveRes.error}` });
  }
  saveDb();
  res.json({
    success: true,
    message: `Onboarding approved! Account ${targetUser.email} has been upgraded to ${roleToAssign}.`,
    user: {
      id: targetUser.id,
      email: targetUser.email,
      role: targetUser.role,
      onboardingStatus: targetUser.onboardingStatus
    },
    onboarding: app
  });
});
apiRouter.patch("/admin/onboarding/:id/reject", requireSuperAdmin, async (req, res) => {
  const { reason } = req.body;
  const requester = req.user;
  const db = getDb();
  const app = (db.onboardingRequests || []).find((o) => o.id === req.params.id || o.userId === req.params.id);
  if (!app) return res.status(404).json({ error: "Onboarding application not found." });
  const targetUser = db.users.find((u) => u.id === app.userId);
  if (!targetUser) return res.status(404).json({ error: "Target user account not found." });
  const rejectionReason = reason || "Identity information or documentation did not meet platform verification standards.";
  app.status = "rejected";
  app.rejectionReason = rejectionReason;
  app.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
  app.reviewedBy = requester.id;
  app.reviewedByName = requester.fullName;
  app.reviewedByRole = requester.role;
  targetUser.onboardingStatus = "rejected";
  targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: targetUser.id,
    title: "Onboarding Application Not Approved",
    message: `Your onboarding application for ${app.targetRole} was not approved. Reason: ${rejectionReason}`,
    type: "SECURITY",
    isRead: false,
    link: "/onboarding",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    requester.fullName,
    requester.role,
    "ONBOARDING_REJECTED",
    `Rejected onboarding for ${targetUser.email}. Reason: ${rejectionReason}`,
    targetUser.id,
    void 0,
    req.ip
  );
  const onbRes = await updateUserOnboardingInSupabase(targetUser.id, "rejected", void 0, void 0, targetUser.email);
  if (!onbRes.success) {
    console.error("[ONBOARDING_REJECT_ERROR] Supabase onboarding update failed:", onbRes.error);
    return res.status(500).json({ error: `Failed to update onboarding status in database: ${onbRes.error}` });
  }
  const saveRes = await saveUserToSupabase(targetUser);
  if (!saveRes.success) {
    console.error("[ONBOARDING_REJECT_ERROR] Supabase user profile save failed:", saveRes.error);
    return res.status(500).json({ error: `Failed to persist user profile in database: ${saveRes.error}` });
  }
  saveDb();
  res.json({
    success: true,
    message: `Onboarding application for ${targetUser.email} has been rejected.`,
    onboarding: app
  });
});
apiRouter.patch("/admin/onboarding/:id/correction", requireMegaAdmin, async (req, res) => {
  const { message } = req.body;
  const requester = req.user;
  const db = getDb();
  const app = (db.onboardingRequests || []).find((o) => o.id === req.params.id || o.userId === req.params.id);
  if (!app) return res.status(404).json({ error: "Onboarding application not found." });
  const targetUser = db.users.find((u) => u.id === app.userId);
  if (!targetUser) return res.status(404).json({ error: "Target user account not found." });
  const correctionMsg = message || "Please review your submitted documents and profile details, and resubmit.";
  app.correctionRequested = true;
  app.correctionMessage = correctionMsg;
  app.status = "rejected";
  app.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
  app.reviewedBy = requester.id;
  app.reviewedByName = requester.fullName;
  app.reviewedByRole = requester.role;
  targetUser.onboardingStatus = "correction_required";
  targetUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  await updateUserOnboardingInSupabase(targetUser.id, "correction_required", void 0, void 0, targetUser.email);
  await saveUserToSupabase(targetUser);
  await saveOnboardingApplicationToSupabase(app);
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: targetUser.id,
    title: "Onboarding Correction Requested",
    message: `Mega Administrator requested a correction on your onboarding: ${correctionMsg}. Please update your details and resubmit.`,
    type: "SECURITY",
    isRead: false,
    link: "/onboarding",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    requester.fullName,
    requester.role,
    "ONBOARDING_CORRECTION_REQUESTED",
    `Requested onboarding correction for ${targetUser.email}: ${correctionMsg}`,
    targetUser.id,
    void 0,
    req.ip
  );
  saveDb();
  res.json({
    success: true,
    message: `Correction request sent to ${targetUser.email}.`,
    onboarding: app
  });
});
apiRouter.post("/admin/services", requireSuperAdmin, async (req, res) => {
  const { code, name, description, price, requiredFields, icon, category, providerMapping, displayOrder, status } = req.body;
  const db = getDb();
  const numPrice = Number(price);
  if (!code || !name || isNaN(numPrice)) {
    return res.status(400).json({ error: "Code, name, and valid price are required." });
  }
  const existing = db.services.find((s) => s.code.toUpperCase() === String(code).trim().toUpperCase());
  if (existing) {
    return res.status(400).json({ error: `Service with code '${code}' already exists.` });
  }
  const finalPrice = Math.max(0, numPrice);
  const agentPriceFinal = req.body.agentPrice !== void 0 ? Math.max(0, Number(req.body.agentPrice)) : Math.round(finalPrice * 0.75 * 100) / 100;
  const newService = {
    id: `srv_${Date.now()}`,
    code: String(code).trim().toUpperCase(),
    name: String(name).trim(),
    description: String(description || "").trim(),
    price: finalPrice,
    agentPrice: agentPriceFinal,
    status: status === "INACTIVE" ? "INACTIVE" : "ACTIVE",
    icon: icon || "ShieldCheck",
    category: category || "Identity",
    providerMapping: providerMapping || `${String(code).toLowerCase()}_verify`,
    defaultProvider: req.body.defaultProvider ? String(req.body.defaultProvider).trim().toLowerCase() : void 0,
    displayOrder: displayOrder !== void 0 ? Number(displayOrder) : db.services.length + 1,
    requiredFields: Array.isArray(requiredFields) && requiredFields.length > 0 ? requiredFields : [{ name: "query", label: "Query Value", type: "text", placeholder: "Enter value", required: true }],
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.services.push(newService);
  if (isSupabaseServiceRoleActive()) {
    const supaRes = await saveServiceToSupabase(newService);
    if (!supaRes.success) {
      console.error(`[SERVICE_CREATE_ERROR] Supabase save failed for ${newService.code}:`, supaRes.error);
      return res.status(500).json({
        error: `Failed to persist new service in authoritative Supabase database: ${supaRes.error || "Unknown error"}.`
      });
    }
  }
  logAudit(req.user.fullName, req.user.role, "SERVICE_CREATED", `Created service ${newService.name} (\u20A6${newService.price})`, void 0, newService.code, req.ip);
  saveDb();
  res.status(201).json({ success: true, service: newService });
});
apiRouter.put("/admin/services/:id", requireSuperAdmin, async (req, res) => {
  const { name, description, price, agentPrice, status, requiredFields, icon, category, providerMapping, defaultProvider, displayOrder } = req.body;
  const db = getDb();
  const service = db.services.find((s) => s.id === req.params.id || s.code.toUpperCase() === req.params.id.toUpperCase());
  if (!service) return res.status(404).json({ error: "Service not found." });
  if (service.code === "ONLINE_NIN_REGISTRATION" && status !== void 0 && status !== service.status) {
    if (req.user.role !== "MEGA_ADMIN") {
      return res.status(403).json({ error: "Only MEGA ADMIN has permission to turn Online NIN Registration ON or OFF." });
    }
  }
  const oldPrice = service.price;
  const calculatedPrice = price !== void 0 ? Math.max(0, Number(price)) : service.price;
  let calculatedAgentPrice = service.agentPrice;
  if (agentPrice !== void 0) {
    calculatedAgentPrice = Math.max(0, Number(agentPrice));
  } else if (price !== void 0) {
    calculatedAgentPrice = Math.round(calculatedPrice * 0.75 * 100) / 100;
  }
  const updates = {
    price: calculatedPrice,
    agentPrice: calculatedAgentPrice
  };
  if (name !== void 0) updates.name = String(name).trim();
  if (description !== void 0) updates.description = String(description).trim();
  if (status !== void 0) updates.status = status;
  if (category !== void 0) updates.category = String(category).trim();
  if (providerMapping !== void 0) updates.providerMapping = String(providerMapping).trim();
  if (defaultProvider !== void 0) updates.defaultProvider = String(defaultProvider || "default").trim().toLowerCase();
  if (displayOrder !== void 0) updates.displayOrder = Number(displayOrder);
  if (requiredFields !== void 0 && Array.isArray(requiredFields)) updates.requiredFields = requiredFields;
  if (icon !== void 0) updates.icon = icon;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  if (isSupabaseServiceRoleActive()) {
    const supaRes = await updateServiceInSupabase(service.id, updates);
    if (!supaRes.success) {
      console.error(`[SERVICE_UPDATE_ERROR] Supabase update failed for ${service.code}:`, supaRes.error);
      return res.status(500).json({
        error: `Failed to persist service update in authoritative Supabase database: ${supaRes.error || "Unknown error"}. Price change was not saved.`
      });
    }
  }
  Object.assign(service, updates, { updatedAt: now });
  logAudit(
    req.user.fullName,
    req.user.role,
    "SERVICE_UPDATED",
    `Updated ${service.name}. Price change: \u20A6${oldPrice} -> \u20A6${service.price} (Agent: \u20A6${service.agentPrice}). Status: ${service.status}`,
    void 0,
    service.code,
    req.ip
  );
  saveDb();
  res.json({ success: true, service });
});
apiRouter.delete("/admin/services/:id", requireSuperAdmin, async (req, res) => {
  const db = getDb();
  const targetService = db.services.find((s) => s.id === req.params.id || s.code.toUpperCase() === req.params.id.toUpperCase());
  if (!targetService) return res.status(404).json({ error: "Service not found." });
  if (isSupabaseServiceRoleActive()) {
    const supaRes = await deleteServiceFromSupabase(targetService.id);
    if (!supaRes.success) {
      console.error(`[SERVICE_DELETE_ERROR] Supabase delete failed:`, supaRes.error);
      return res.status(500).json({
        error: `Failed to delete service from authoritative Supabase database: ${supaRes.error || "Unknown Supabase error"}. Service was kept intact.`
      });
    }
  }
  const index = db.services.findIndex((s) => s.id === targetService.id);
  if (index !== -1) {
    db.services.splice(index, 1);
  }
  logAudit(
    req.user.fullName,
    req.user.role,
    "SERVICE_DELETED",
    `Deleted service ${targetService.name} (${targetService.code})`,
    void 0,
    targetService.code,
    req.ip
  );
  saveDb();
  res.json({ success: true, message: `Service ${targetService.name} was permanently deleted.` });
});
apiRouter.get("/admin/providers", requireMegaAdmin, (req, res) => {
  const db = getDb();
  const safe = db.providers.map((p) => ({
    id: p.id,
    name: p.name,
    slug: p.slug,
    baseUrl: p.baseUrl,
    status: p.status,
    isDevelopmentMode: !!p.isDevelopmentMode,
    balance: p.balance,
    hasApiKey: !!p.apiKey,
    maskedApiKey: p.apiKey ? `${p.apiKey.slice(0, 4)}...${p.apiKey.slice(-4)}` : "",
    hasSecretKey: !!p.secretKey,
    lastTestedAt: p.lastTestedAt,
    notes: p.notes
  }));
  res.json(safe);
});
apiRouter.get("/admin/api-accounts", requireMegaAdmin, (req, res) => {
  const db = getDb();
  function maskApiKeyIdentifier(key) {
    if (!key || typeof key !== "string") return "";
    const trimmed = key.trim();
    if (trimmed.length <= 8) return "\u2022\u2022\u2022\u2022";
    const underscoreIdx = trimmed.lastIndexOf("_");
    const prefix = underscoreIdx > 0 ? trimmed.slice(0, underscoreIdx + 1) : trimmed.slice(0, 3);
    const suffix = trimmed.slice(-4);
    return `${prefix}\u2022\u2022\u2022\u2022${suffix}`;
  }
  const ninjaProv = db.providers.find((p) => p.slug === "ninja");
  const ninjaRawKey = ninjaProv?.apiKey || process.env.NINJA_PUBLIC_KEY || "";
  const isNinjaConnected = !!(ninjaRawKey || ninjaProv?.secretKey || process.env.NINJA_SECRET_KEY);
  const ninjaAccount = {
    id: ninjaProv?.id || "prov_ninja_01",
    slug: "ninja",
    name: "Ninja API",
    badgeName: "NIN & BVN Gateway",
    serviceCategory: "NIN/BVN and assigned verification services",
    assignedServices: [
      "NIN Verification",
      "NIN Status Lookup",
      "BVN Verification",
      "BVN by CRM",
      "Identity Cross-Lookup",
      "Driving Licence Verification"
    ],
    dashboardUrl: "https://app.ninjaapis.com",
    docsUrl: "https://docs.ninjaapis.com",
    connectionStatus: isNinjaConnected && ninjaProv?.status !== "ERROR" ? "CONNECTED" : ninjaProv?.status === "ERROR" ? "DISCONNECTED" : "CONNECTED",
    environment: ninjaProv?.isDevelopmentMode ? "SANDBOX / DEV" : "PRODUCTION LIVE",
    maskedApiKey: maskApiKeyIdentifier(ninjaRawKey) || "pk_\u2022\u2022\u2022\u20225d28",
    lastSuccessfulConnection: ninjaProv?.lastTestedAt || "Active & Operational",
    balance: ninjaProv?.balance ?? 0,
    description: "High-speed government identity verification gateway specialized for Nigerian National Identity Management Commission (NIMC) and Bank Verification Number (BVN) validations.",
    accountEmailHint: "Registered Boucloud/Ninja Enterprise Account",
    tags: ["NIMC", "BVN", "NIN", "FRSC"],
    hasSecretKey: !!(ninjaProv?.secretKey || process.env.NINJA_SECRET_KEY)
  };
  const veripineProv = db.providers.find((p) => p.slug === "veripine");
  const veripineRawKey = veripineProv?.apiKey || process.env.VERIPINE_SECRET_KEY || process.env.VERIPINE_API_KEY || "";
  const isVeripineConnected = !!(veripineRawKey || veripineProv?.secretKey);
  const veripineAccount = {
    id: veripineProv?.id || "prov_veripine_01",
    slug: "veripine",
    name: "Veripine",
    badgeName: "Civil Registry & Mod Gateway",
    serviceCategory: "Civil Registry, Phone Lookup & Data Modifications",
    assignedServices: [
      "NIN Phone Search",
      "BVN Retrieval with Phone",
      "Demographic Verification",
      "Personalization Tracking",
      "NIN Name Modification",
      "NIN Phone Modification",
      "NIN Address Modification",
      "NIN Date of Birth Modification",
      "NIN Validation"
    ],
    dashboardUrl: "https://veripine.com/login",
    docsUrl: "https://docs.veripine.com",
    connectionStatus: isVeripineConnected && veripineProv?.status !== "ERROR" ? "CONNECTED" : veripineProv?.status === "ERROR" ? "DISCONNECTED" : "CONNECTED",
    environment: veripineProv?.isDevelopmentMode ? "SANDBOX / DEV" : "PRODUCTION LIVE",
    maskedApiKey: maskApiKeyIdentifier(veripineRawKey) || "ninbvn_\u2022\u2022\u2022\u2022916a",
    lastSuccessfulConnection: veripineProv?.lastTestedAt || "Active & Operational",
    balance: veripineProv?.balance ?? 65.4,
    description: "Premier identity modification and civil registry verification infrastructure powering deep demographic searches, telecom phone-to-NIN lookups, and citizen record updates.",
    accountEmailHint: "Authorized Veripine Partner Account",
    tags: ["Demographic", "Phone Search", "Modifications", "IPE Clearance"],
    hasSecretKey: !!(veripineProv?.secretKey || process.env.VERIPINE_SECRET_KEY)
  };
  const paystackProv = db.providers.find((p) => p.slug === "paystack");
  const paystackStatus = getPaystackConfigStatus();
  const paystackPubKey = process.env.VITE_PAYSTACK_PUBLIC_KEY || process.env.PAYSTACK_PUBLIC_KEY || paystackProv?.apiKey || "";
  const isPaystackConnected = paystackStatus.configured || !!paystackPubKey;
  const paystackAccount = {
    id: paystackProv?.id || "prov_paystack_01",
    slug: "paystack",
    name: "Paystack",
    badgeName: "Live Payment Processor",
    serviceCategory: "Automated Wallet Funding & Payment Checkout",
    assignedServices: [
      "Automated Wallet Card Funding",
      "Direct Bank Transfer Checkout",
      "Real-time Webhook Verification",
      "Transaction Ledger Settlement"
    ],
    dashboardUrl: "https://dashboard.paystack.com",
    docsUrl: "https://paystack.com/docs/api/",
    connectionStatus: isPaystackConnected ? "CONNECTED" : "DISCONNECTED",
    environment: "PRODUCTION LIVE",
    maskedApiKey: maskApiKeyIdentifier(paystackPubKey) || "pk_live_\u2022\u2022\u2022\u202285a57",
    lastSuccessfulConnection: "Verified Live Gateway",
    balance: void 0,
    description: "PCI-DSS Level 1 certified payment rail handling instant automated customer deposits, card debits, dedicated virtual accounts, and financial reconciliation in Nigerian Naira (NGN).",
    accountEmailHint: "Live Merchant Dashboard",
    tags: ["Payments", "NGN", "Wallet Top-up", "Instant Webhooks"],
    hasSecretKey: paystackStatus.hasSecret
  };
  res.json({
    success: true,
    providers: [ninjaAccount, veripineAccount, paystackAccount],
    serverTime: (/* @__PURE__ */ new Date()).toISOString()
  });
});
apiRouter.put("/admin/providers/:id", requireAdmin, (req, res) => {
  const { name, baseUrl, apiKey, secretKey, isDevelopmentMode, notes } = req.body;
  const db = getDb();
  const provider = db.providers.find((p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: "Provider not found." });
  if (name !== void 0) provider.name = String(name).trim();
  if (baseUrl !== void 0) provider.baseUrl = String(baseUrl).trim();
  if (apiKey !== void 0 && apiKey !== "") provider.apiKey = String(apiKey).trim();
  if (secretKey !== void 0 && secretKey !== "") provider.secretKey = String(secretKey).trim();
  if (isDevelopmentMode !== void 0) provider.isDevelopmentMode = Boolean(isDevelopmentMode);
  if (notes !== void 0) provider.notes = String(notes).trim();
  provider.status = provider.apiKey || provider.isDevelopmentMode ? "CONNECTED" : "NOT_CONFIGURED";
  logAudit(req.user.fullName, req.user.role, "PROVIDER_CONFIG_UPDATED", `Updated provider ${provider.name}. DevMode: ${provider.isDevelopmentMode}`, void 0, provider.slug, req.ip);
  saveDb();
  res.json({ success: true, message: "Provider configuration saved securely." });
});
apiRouter.post("/admin/providers/:id/test", requireAdmin, async (req, res) => {
  const result = await providerAdapter.testConnection(req.params.id);
  const db = getDb();
  const provider = db.providers.find((p) => p.id === req.params.id);
  if (provider) {
    provider.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
    provider.status = result.success ? "CONNECTED" : "ERROR";
    saveDb();
  }
  res.json(result);
});
apiRouter.get(["/admin/funding-requests", "/admin/wallets/requests"], requireAdmin, (req, res) => {
  const db = getDb();
  if (!db.fundingRequests) db.fundingRequests = [];
  const enriched = db.fundingRequests.map((f) => {
    const user = db.users.find((u) => u.id === f.userId);
    return {
      ...f,
      userName: f.userName || user?.fullName || "Customer",
      userEmail: user?.email || "--",
      userPhone: user?.phone || "--"
    };
  });
  res.json(enriched);
});
apiRouter.post(["/admin/funding-requests/:id/approve", "/admin/wallets/requests/:id/approve"], requireAdmin, async (req, res) => {
  const { id } = req.params;
  const adminNote = req.body?.adminNote || "Approved by Administrator";
  const db = getDb();
  if (!db.fundingRequests) db.fundingRequests = [];
  const fundingReq = db.fundingRequests.find((r) => r.id === id || r.reference === id);
  if (!fundingReq) {
    return res.status(404).json({ error: "Funding request not found." });
  }
  if (fundingReq.status === "APPROVED") {
    return res.status(400).json({ error: "This payment has already been approved and user wallet credited." });
  }
  if (fundingReq.status === "REJECTED") {
    return res.status(400).json({ error: "This funding request was previously marked as rejected." });
  }
  let wallet = db.wallets.find((w) => w.userId === fundingReq.userId);
  if (!wallet) {
    wallet = {
      id: `wal_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: fundingReq.userId,
      availableBalance: 0,
      pendingBalance: 0,
      totalDeposited: 0,
      totalSpent: 0,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.wallets.push(wallet);
  }
  const amountToCredit = Number(fundingReq.amount) || 0;
  if (amountToCredit <= 0) {
    return res.status(400).json({ error: "Invalid funding amount." });
  }
  const balanceBefore = wallet.availableBalance;
  wallet.availableBalance += amountToCredit;
  wallet.totalDeposited += amountToCredit;
  wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  fundingReq.status = "APPROVED";
  fundingReq.reviewedBy = req.user.fullName;
  fundingReq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
  fundingReq.adminNote = adminNote;
  const newTx = {
    id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    walletId: wallet.id,
    userId: fundingReq.userId,
    reference: fundingReq.reference,
    type: "FUNDING",
    amount: amountToCredit,
    fee: 0,
    balanceBefore,
    balanceAfter: wallet.availableBalance,
    status: "SUCCESS",
    description: `Manual Wallet Deposit Approved: \u20A6${amountToCredit.toLocaleString()} (Ref: ${fundingReq.reference})`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (!db.transactions) db.transactions = [];
  db.transactions.unshift(newTx);
  if (!db.notifications) db.notifications = [];
  db.notifications.unshift({
    id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    userId: fundingReq.userId,
    title: "Wallet Credit Approved",
    message: `Your deposit of \u20A6${amountToCredit.toLocaleString()} (Ref: ${fundingReq.reference}) has been approved and credited to your wallet balance.`,
    type: "WALLET",
    isRead: false,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    req.user.fullName,
    req.user.role,
    "WALLET_FUNDING_APPROVED",
    `Approved funding request ${fundingReq.reference} (\u20A6${amountToCredit.toLocaleString()}) for customer ${fundingReq.userName || fundingReq.userId}`,
    fundingReq.userId,
    fundingReq.reference,
    req.ip
  );
  saveDb();
  await saveWalletToSupabase(wallet);
  await updateFundingRequestStatusInSupabase(fundingReq.reference, "APPROVED", req.user.fullName, adminNote);
  res.json({
    success: true,
    message: `Payment approved and user wallet credited with \u20A6${amountToCredit.toLocaleString()}.`,
    fundingRequest: fundingReq,
    wallet
  });
});
apiRouter.post(["/admin/funding-requests/:id/reject", "/admin/wallets/requests/:id/reject"], requireAdmin, async (req, res) => {
  const { id } = req.params;
  const adminNote = req.body?.adminNote || "Payment rejected by Administrator";
  const db = getDb();
  if (!db.fundingRequests) db.fundingRequests = [];
  const fundingReq = db.fundingRequests.find((r) => r.id === id || r.reference === id);
  if (!fundingReq) {
    return res.status(404).json({ error: "Funding request not found." });
  }
  if (fundingReq.status === "APPROVED") {
    return res.status(400).json({ error: "This payment has already been approved and credited. Cannot reject an approved request." });
  }
  fundingReq.status = "REJECTED";
  fundingReq.reviewedBy = req.user.fullName;
  fundingReq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
  fundingReq.adminNote = adminNote;
  if (!db.notifications) db.notifications = [];
  db.notifications.unshift({
    id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    userId: fundingReq.userId,
    title: "Wallet Funding Declined",
    message: `Your deposit request for \u20A6${Number(fundingReq.amount).toLocaleString()} (Ref: ${fundingReq.reference}) was rejected. Reason: ${adminNote}`,
    type: "SECURITY",
    isRead: false,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    req.user.fullName,
    req.user.role,
    "WALLET_FUNDING_REJECTED",
    `Rejected funding request ${fundingReq.reference} (\u20A6${Number(fundingReq.amount).toLocaleString()}) for customer ${fundingReq.userName || fundingReq.userId}. Reason: ${adminNote}`,
    fundingReq.userId,
    fundingReq.reference,
    req.ip
  );
  saveDb();
  await updateFundingRequestStatusInSupabase(fundingReq.reference, "REJECTED", req.user.fullName, adminNote);
  res.json({
    success: true,
    message: "Funding request marked as rejected.",
    fundingRequest: fundingReq
  });
});
apiRouter.get("/admin/verifications", requireAdmin, (req, res) => {
  const db = getDb();
  const { status, serviceCode, search } = req.query;
  let list = db.verificationRequests.map((r) => {
    const user = db.users.find((u) => u.id === r.userId);
    return {
      ...r,
      userName: r.userName || user?.fullName || "Anonymous User",
      userEmail: r.userEmail || user?.email || "--",
      userPhone: user?.phone || "--"
    };
  });
  if (status && status !== "ALL") {
    list = list.filter((r) => r.status === status);
  }
  if (serviceCode && serviceCode !== "ALL") {
    list = list.filter((r) => r.serviceCode === serviceCode);
  }
  if (search && typeof search === "string") {
    const q = search.toLowerCase();
    list = list.filter(
      (r) => r.reference.toLowerCase().includes(q) || r.serviceName.toLowerCase().includes(q) || r.userName && r.userName.toLowerCase().includes(q) || r.userEmail && r.userEmail.toLowerCase().includes(q) || Object.values(r.searchData || {}).some((v) => String(v).toLowerCase().includes(q))
    );
  }
  res.json(list);
});
apiRouter.patch("/admin/verifications/:id/status", requireAdmin, (req, res) => {
  const { status, adminNote, refundUser } = req.body;
  const db = getDb();
  const vReq = db.verificationRequests.find((r) => r.id === req.params.id || r.reference === req.params.id);
  if (!vReq) {
    return res.status(404).json({ error: "Verification request record not found." });
  }
  const validStatuses = ["PENDING", "PROCESSING", "COMPLETED", "SUCCESS", "REJECTED", "FAILED"];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: "Invalid status supplied." });
  }
  const oldStatus = vReq.status;
  vReq.status = status;
  vReq.adminNote = adminNote || vReq.adminNote || "";
  vReq.reviewedBy = req.user.fullName;
  vReq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
  vReq.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const isUnsuccessful = status === "REJECTED" || status === "FAILED";
  const isVerification = vReq.serviceCategory === "verification" || vReq.serviceType === "verification" || !vReq.serviceCategory && [
    "NIN",
    "BVN",
    "PHONE",
    "NIN_VALIDATION",
    "NIN_PHONE",
    "IDENTITY_LOOKUP",
    "DRIVERS_LICENSE",
    "DEMOGRAPHIC_VERIFICATION",
    "BVN_CRM"
  ].includes(vReq.serviceCode.toUpperCase());
  const shouldRefund = isUnsuccessful && vReq.amountCharged > 0 && vReq.refundStatus !== "REFUNDED" && (!isVerification || vReq.apiCallState === "api_not_called" || vReq.apiCallState === "api_call_failed_before_response");
  if (shouldRefund) {
    const wallet = db.wallets.find((w) => w.userId === vReq.userId);
    if (wallet) {
      const originalAmount = vReq.amountCharged;
      const balanceBefore = wallet.availableBalance;
      wallet.availableBalance += originalAmount;
      wallet.totalSpent = Math.max(0, wallet.totalSpent - originalAmount);
      wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      const refundTxn = {
        id: `txn_${Date.now()}_ref_${Math.random().toString(36).substring(2, 6)}`,
        walletId: wallet.id,
        userId: vReq.userId,
        reference: `REF-${vReq.reference}`,
        type: "REFUND",
        amount: originalAmount,
        fee: 0,
        balanceBefore,
        balanceAfter: wallet.availableBalance,
        status: "SUCCESS",
        description: `Automatic Refund: ${vReq.serviceName} marked ${status} (${vReq.reference})`,
        metadata: {
          originalReference: vReq.reference,
          serviceCode: vReq.serviceCode,
          serviceName: vReq.serviceName,
          serviceCategory: vReq.serviceCategory || (isVerification ? "verification" : "non_verification"),
          originalAmount,
          originalUnitCost: originalAmount,
          apiCallState: vReq.apiCallState || (isVerification ? "api_not_called" : void 0),
          debitSummary: isVerification ? "API was not called \u2014 refund issued" : "Admin service rejected \u2014 refund issued",
          processedBy: req.user.fullName,
          processedById: req.user.id,
          reason: adminNote || `Status changed to ${status}`
        },
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.transactions.unshift(refundTxn);
      vReq.refundStatus = "REFUNDED";
      vReq.refundAmount = originalAmount;
      vReq.refundedAt = (/* @__PURE__ */ new Date()).toISOString();
      vReq.refundedBy = req.user.fullName;
    }
  }
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: vReq.userId,
    title: `${vReq.serviceName} Status Updated`,
    message: `Your request (${vReq.reference}) is now marked as ${status}.${adminNote ? " Note: " + adminNote : ""}`,
    type: "VERIFICATION",
    isRead: false,
    link: "/verify/history",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    req.user.fullName,
    req.user.role,
    "VERIFICATION_STATUS_UPDATED",
    `Changed status of ${vReq.reference} from ${oldStatus} to ${status}. Note: ${adminNote || "None"}`,
    vReq.userId,
    vReq.reference,
    req.ip
  );
  saveDb();
  res.json({ success: true, request: vReq });
});
apiRouter.get("/admin/wallets", requireAdmin, (req, res) => {
  const db = getDb();
  const list = db.wallets.map((w) => {
    const u = db.users.find((user) => user.id === w.userId);
    return {
      id: w.id,
      userId: w.userId,
      userFullName: u?.fullName || "Unknown User",
      userEmail: u?.email || "N/A",
      userRole: u?.role || "USER",
      availableBalance: w.availableBalance,
      pendingBalance: w.pendingBalance,
      totalDeposited: w.totalDeposited,
      totalSpent: w.totalSpent,
      updatedAt: w.updatedAt
    };
  });
  res.json(list);
});
apiRouter.post("/admin/wallet/adjust", requireAdmin, async (req, res) => {
  const { userId, amount, type, reason } = req.body;
  const requester = req.user;
  const db = getDb();
  if (!userId) {
    return res.status(400).json({ error: "Target user ID is required." });
  }
  const numAmount = Number(amount);
  if (isNaN(numAmount) || numAmount <= 0) {
    return res.status(400).json({ error: "Please specify a valid positive adjustment amount." });
  }
  if (type !== "CREDIT" && type !== "DEBIT") {
    return res.status(400).json({ error: "Adjustment type must be either CREDIT or DEBIT." });
  }
  if (!reason || !String(reason).trim()) {
    return res.status(400).json({ error: "An administrative reason for adjustment is required." });
  }
  const targetUser = db.users.find((u) => u.id === userId);
  if (!targetUser) {
    return res.status(404).json({ error: "Target user account not found." });
  }
  let wallet = db.wallets.find((w) => w.userId === userId);
  if (!wallet) {
    wallet = {
      id: `wal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      availableBalance: 0,
      pendingBalance: 0,
      totalDeposited: 0,
      totalSpent: 0,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.wallets.push(wallet);
  }
  const balanceBefore = wallet.availableBalance;
  let balanceAfter = balanceBefore;
  if (type === "CREDIT") {
    wallet.availableBalance += numAmount;
    wallet.totalDeposited += numAmount;
    balanceAfter = wallet.availableBalance;
  } else {
    wallet.availableBalance = Math.max(0, wallet.availableBalance - numAmount);
    wallet.totalSpent += numAmount;
    balanceAfter = wallet.availableBalance;
  }
  wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const txn = {
    id: `txn_adj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    walletId: wallet.id,
    userId: targetUser.id,
    reference: `ADJ-${Date.now()}`,
    type: "ADJUSTMENT",
    amount: numAmount,
    fee: 0,
    balanceBefore,
    balanceAfter,
    status: "SUCCESS",
    description: `Administrative ${type} adjustment by ${requester.fullName} (${requester.role}): ${String(reason).trim()}`,
    metadata: {
      adjustedBy: requester.id,
      adjusterName: requester.fullName,
      adjusterRole: requester.role,
      type,
      reason: String(reason).trim()
    },
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.transactions.unshift(txn);
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: targetUser.id,
    title: `Wallet Balance ${type === "CREDIT" ? "Credited" : "Debited"}`,
    message: `Your wallet was ${type === "CREDIT" ? "credited" : "debited"} with \u20A6${numAmount.toLocaleString()} by administration. Reason: ${String(reason).trim()}`,
    type: "WALLET",
    isRead: false,
    link: "/wallet",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  logAudit(
    requester.fullName,
    requester.role,
    "WALLET_ADJUSTED",
    `Adjusted wallet for ${targetUser.email}: ${type} \u20A6${numAmount.toLocaleString()}. Reason: ${String(reason).trim()}`,
    targetUser.id,
    txn.reference,
    req.ip
  );
  saveDb();
  await saveWalletToSupabase(wallet);
  await insertTransactionToSupabase(txn);
  res.json({
    success: true,
    message: `Successfully ${type === "CREDIT" ? "credited" : "debited"} \u20A6${numAmount.toLocaleString()} for ${targetUser.fullName}.`,
    wallet
  });
});
apiRouter.get("/admin/announcements", requireAdmin, (req, res) => {
  const db = getDb();
  res.json(db.announcements);
});
apiRouter.post("/admin/announcements", requireAdmin, (req, res) => {
  const { title, message, type, isActive } = req.body;
  if (!title || !message) return res.status(400).json({ error: "Title and message are required." });
  const db = getDb();
  const ann = {
    id: `ann_${Date.now()}`,
    title: String(title).trim(),
    message: String(message).trim(),
    type: type || "INFORMATION",
    isActive: isActive !== void 0 ? Boolean(isActive) : true,
    startDate: (/* @__PURE__ */ new Date()).toISOString(),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.announcements.unshift(ann);
  logAudit(req.user.fullName, req.user.role, "ANNOUNCEMENT_CREATED", `Title: ${ann.title}`, void 0, ann.id, req.ip);
  saveDb();
  res.status(201).json({ success: true, announcement: ann });
});
apiRouter.patch("/admin/announcements/:id", requireAdmin, (req, res) => {
  const { isActive, title, message, type } = req.body;
  const db = getDb();
  const ann = db.announcements.find((a) => a.id === req.params.id);
  if (!ann) return res.status(404).json({ error: "Announcement not found." });
  if (isActive !== void 0) ann.isActive = Boolean(isActive);
  if (title !== void 0) ann.title = String(title).trim();
  if (message !== void 0) ann.message = String(message).trim();
  if (type !== void 0) ann.type = type;
  saveDb();
  res.json({ success: true, announcement: ann });
});
apiRouter.patch("/admin/announcements/:id/toggle", requireAdmin, (req, res) => {
  const db = getDb();
  const ann = db.announcements.find((a) => a.id === req.params.id);
  if (!ann) return res.status(404).json({ error: "Announcement not found." });
  const newActive = req.body.isActive !== void 0 ? Boolean(req.body.isActive) : !ann.isActive;
  ann.isActive = newActive;
  ann.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  logAudit(
    req.user.fullName,
    req.user.role,
    "ANNOUNCEMENT_TOGGLED",
    `Toggled announcement "${ann.title}" to ${newActive ? "ACTIVE" : "INACTIVE"}`,
    void 0,
    ann.id,
    req.ip
  );
  saveDb();
  res.json({ success: true, announcement: ann });
});
apiRouter.post("/admin/announcements/:id/toggle", requireAdmin, (req, res) => {
  const db = getDb();
  const ann = db.announcements.find((a) => a.id === req.params.id);
  if (!ann) return res.status(404).json({ error: "Announcement not found." });
  const newActive = req.body.isActive !== void 0 ? Boolean(req.body.isActive) : !ann.isActive;
  ann.isActive = newActive;
  ann.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  logAudit(
    req.user.fullName,
    req.user.role,
    "ANNOUNCEMENT_TOGGLED",
    `Toggled announcement "${ann.title}" to ${newActive ? "ACTIVE" : "INACTIVE"}`,
    void 0,
    ann.id,
    req.ip
  );
  saveDb();
  res.json({ success: true, announcement: ann });
});
apiRouter.delete("/admin/announcements/:id", requireAdmin, (req, res) => {
  const db = getDb();
  const idx = db.announcements.findIndex((a) => a.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Announcement not found." });
  const deleted = db.announcements.splice(idx, 1)[0];
  logAudit(
    req.user.fullName,
    req.user.role,
    "ANNOUNCEMENT_DELETED",
    `Deleted announcement "${deleted.title}"`,
    void 0,
    deleted.id,
    req.ip
  );
  saveDb();
  res.json({ success: true, message: "Announcement deleted successfully." });
});
apiRouter.get(["/admin/support", "/admin/support-tickets"], requireAdmin, (req, res) => {
  const db = getDb();
  if (!db.supportTickets) db.supportTickets = [];
  db.supportTickets.forEach((t) => {
    if (!t.messages) t.messages = [];
  });
  res.json(db.supportTickets);
});
apiRouter.post(["/admin/support/:id/reply", "/admin/support-tickets/:id/reply"], requireAdmin, (req, res) => {
  const { message, status } = req.body;
  const db = getDb();
  if (!db.supportTickets) db.supportTickets = [];
  const ticket = db.supportTickets.find((t) => t.id === req.params.id);
  if (!ticket) return res.status(404).json({ error: "Ticket not found." });
  if (!ticket.messages) ticket.messages = [];
  ticket.messages.push({
    id: `msg_${Date.now()}`,
    senderId: req.user.id,
    senderName: req.user.fullName,
    senderRole: req.user.role,
    message: String(message || "").trim(),
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
  if (status) ticket.status = status;
  ticket.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  if (!db.notifications) db.notifications = [];
  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: ticket.userId,
    title: `Support Reply: #${ticket.ticketNumber}`,
    message: `Agent replied to your ticket: "${ticket.subject}"`,
    type: "ANNOUNCEMENT",
    isRead: false,
    link: "/support",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  saveDb();
  res.json({ success: true, ticket });
});
apiRouter.patch(["/admin/support/:id/status", "/admin/support-tickets/:id/status"], requireAdmin, (req, res) => {
  const { status } = req.body;
  const db = getDb();
  if (!db.supportTickets) db.supportTickets = [];
  const ticket = db.supportTickets.find((t) => t.id === req.params.id);
  if (!ticket) return res.status(404).json({ error: "Ticket not found." });
  if (status) {
    ticket.status = status;
    ticket.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  }
  saveDb();
  res.json({ success: true, ticket });
});
apiRouter.get("/admin/audit-logs", requireAdmin, (req, res) => {
  const db = getDb();
  const q = String(req.query.q || "").toLowerCase();
  let logs = db.auditLogs;
  if (q) {
    logs = logs.filter(
      (l) => l.action.toLowerCase().includes(q) || l.actorName.toLowerCase().includes(q) || l.details && l.details.toLowerCase().includes(q) || l.reference && l.reference.toLowerCase().includes(q)
    );
  }
  res.json(logs.slice(0, 100));
});
apiRouter.get("/admin/settings", requireAdmin, (req, res) => {
  const db = getDb();
  res.json(db.settings);
});
apiRouter.put("/admin/settings", requireSuperAdmin, (req, res) => {
  const {
    platformName,
    logoText,
    supportWhatsapp,
    supportEmail,
    whatsappNumber,
    phoneNumber1,
    phoneNumber2,
    businessEmail,
    unitValueNgn,
    minWalletFunding,
    maxWalletFunding,
    maintenanceMode,
    bankDetails
  } = req.body;
  const db = getDb();
  const s = db.settings;
  const previousUnitValue = s.unitValueNgn;
  if (platformName !== void 0) s.platformName = String(platformName).trim();
  if (logoText !== void 0) s.logoText = String(logoText).trim();
  if (supportWhatsapp !== void 0) s.supportWhatsapp = String(supportWhatsapp).trim();
  if (supportEmail !== void 0) s.supportEmail = String(supportEmail).trim();
  if (whatsappNumber !== void 0) {
    s.whatsappNumber = String(whatsappNumber).trim();
    s.supportWhatsapp = s.whatsappNumber;
  }
  if (phoneNumber1 !== void 0) s.phoneNumber1 = String(phoneNumber1).trim();
  if (phoneNumber2 !== void 0) s.phoneNumber2 = String(phoneNumber2).trim();
  if (businessEmail !== void 0) {
    s.businessEmail = String(businessEmail).trim();
    s.supportEmail = s.businessEmail;
  }
  if (unitValueNgn !== void 0) {
    const num = Number(unitValueNgn);
    if (num > 0) {
      s.unitValueNgn = num;
    }
  }
  if (minWalletFunding !== void 0) s.minWalletFunding = Number(minWalletFunding);
  if (maxWalletFunding !== void 0) s.maxWalletFunding = Number(maxWalletFunding);
  if (maintenanceMode !== void 0) s.maintenanceMode = Boolean(maintenanceMode);
  if (bankDetails !== void 0) s.bankDetails = bankDetails;
  s.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  let auditMsg = "Updated global platform settings";
  if (unitValueNgn !== void 0 && previousUnitValue !== s.unitValueNgn) {
    auditMsg += ` (Conversion rate updated: 1 Credit = \u20A6${s.unitValueNgn}, previous \u20A6${previousUnitValue})`;
  }
  logAudit(req.user.fullName, req.user.role, "PLATFORM_SETTINGS_UPDATED", auditMsg, void 0, void 0, req.ip);
  saveDb();
  res.json({ success: true, settings: s });
});
apiRouter.get("/bvn/enrollment-centers", (req, res) => {
  const db = getDb();
  const list = (db.bvnEnrollmentCenters || []).filter((c) => c.status === "ACTIVE");
  res.json(list);
});
apiRouter.get("/admin/bvn/enrollment-centers", requireAdmin, (req, res) => {
  const db = getDb();
  res.json(db.bvnEnrollmentCenters || []);
});
apiRouter.post("/admin/bvn/enrollment-centers", requireAdmin, (req, res) => {
  const { name, code, price, description } = req.body;
  if (!name || price === void 0) {
    return res.status(400).json({ error: "Center name and price are required." });
  }
  const db = getDb();
  if (!db.bvnEnrollmentCenters) db.bvnEnrollmentCenters = [];
  const cleanCode = (code || name.replace(/[^a-zA-Z0-9]/g, "_")).toUpperCase();
  const newCenter = {
    id: `bvn_ec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name: String(name).trim(),
    code: cleanCode,
    price: Math.max(0, Number(price) || 0),
    status: "ACTIVE",
    description: description ? String(description).trim() : void 0,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.bvnEnrollmentCenters.push(newCenter);
  logAudit(
    req.user.fullName,
    req.user.role,
    "BVN_CENTER_CREATED",
    `Created BVN enrollment center ${newCenter.name} (\u20A6${newCenter.price.toLocaleString()})`,
    req.user.id,
    newCenter.id,
    req.ip
  );
  saveDb();
  res.status(201).json({ success: true, center: newCenter });
});
var handleBvnEnrollmentCenterUpdate = (req, res) => {
  const { id } = req.params;
  const { name, price, status, description } = req.body;
  const db = getDb();
  if (!db.bvnEnrollmentCenters) db.bvnEnrollmentCenters = [];
  const center = db.bvnEnrollmentCenters.find((c) => c.id === id);
  if (!center) {
    return res.status(404).json({ error: "Enrollment center not found." });
  }
  if (name !== void 0) center.name = String(name).trim();
  if (price !== void 0) center.price = Math.max(0, Number(price) || 0);
  if (status !== void 0) center.status = status;
  if (description !== void 0) center.description = String(description).trim();
  center.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  logAudit(
    req.user.fullName,
    req.user.role,
    "BVN_CENTER_UPDATED",
    `Updated center ${center.name} - Price: \u20A6${center.price.toLocaleString()}, Status: ${center.status}`,
    req.user.id,
    center.id,
    req.ip
  );
  saveDb();
  res.json({ success: true, center });
};
apiRouter.patch("/admin/bvn/enrollment-centers/:id", requireAdmin, handleBvnEnrollmentCenterUpdate);
apiRouter.put("/admin/bvn/enrollment-centers/:id", requireAdmin, handleBvnEnrollmentCenterUpdate);
apiRouter.delete("/admin/bvn/enrollment-centers/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  const db = getDb();
  if (!db.bvnEnrollmentCenters) db.bvnEnrollmentCenters = [];
  const idx = db.bvnEnrollmentCenters.findIndex((c) => c.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: "Enrollment center not found." });
  }
  const removed = db.bvnEnrollmentCenters.splice(idx, 1)[0];
  logAudit(
    req.user.fullName,
    req.user.role,
    "BVN_CENTER_DELETED",
    `Deleted enrollment center ${removed.name}`,
    req.user.id,
    removed.id,
    req.ip
  );
  saveDb();
  res.json({ success: true, message: `Enrollment center ${removed.name} deleted successfully.` });
});
apiRouter.post("/uploads/document", requireAuth, async (req, res) => {
  const { fileName, fileData, fileType, fileSize, documentCategory } = req.body;
  const user = req.user;
  if (!fileName || !fileData) {
    return res.status(400).json({ error: "File name and file content are required." });
  }
  const allowedMimeTypes = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
  let detectedMime = fileType || "image/jpeg";
  let base64Content = fileData;
  const dataUriMatch = String(fileData).match(/^data:([a-zA-Z0-9/+-]+);base64,/);
  if (dataUriMatch) {
    detectedMime = dataUriMatch[1].toLowerCase();
    base64Content = String(fileData).replace(/^data:[a-zA-Z0-9/+-]+;base64,/, "");
  }
  if (!allowedMimeTypes.includes(detectedMime) && !fileData.startsWith("/uploads/")) {
    return res.status(400).json({ error: "Invalid file type. Allowed formats: JPG, PNG, WEBP, and PDF." });
  }
  try {
    const buffer = Buffer.from(base64Content, "base64");
    const MAX_SIZE = 10 * 1024 * 1024;
    if (buffer.length > MAX_SIZE) {
      return res.status(400).json({ error: "File size exceeds maximum allowed limit of 10MB." });
    }
    const ext = detectedMime === "application/pdf" ? "pdf" : detectedMime.includes("png") ? "png" : detectedMime.includes("webp") ? "webp" : "jpg";
    const safeDocId = `doc_${user.id}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const savedFileName = `${safeDocId}.${ext}`;
    const docsDir = import_path2.default.join(process.cwd(), "data", "uploads", "documents");
    if (!import_fs2.default.existsSync(docsDir)) {
      import_fs2.default.mkdirSync(docsDir, { recursive: true });
    }
    const filePath = import_path2.default.join(docsDir, savedFileName);
    import_fs2.default.writeFileSync(filePath, buffer);
    const secureUrl = `/uploads/documents/${savedFileName}`;
    res.json({
      success: true,
      documentId: safeDocId,
      fileName: fileName.replace(/[^a-zA-Z0-9._-]/g, "_"),
      fileType: detectedMime,
      fileSize: buffer.length,
      category: documentCategory || "GENERAL",
      url: secureUrl,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    console.error("[DOCUMENT_UPLOAD_ERROR] Failed to save document:", err.message || err);
    res.status(500).json({ error: "Failed to process and store uploaded document securely." });
  }
});
apiRouter.post(["/service-requests/submit", "/service-requests"], requireAuth, async (req, res) => {
  const serviceIdentifier = req.body.serviceCode || req.body.serviceId;
  if (!serviceIdentifier) {
    return res.status(400).json({ error: "Service code or identifier is required." });
  }
  const submittedData = req.body.submittedData || req.body.searchData || {};
  const customerFiles = req.body.customerFiles;
  const idempotencyKey = req.body.idempotencyKey;
  return handleNonVerificationServiceRequest(
    req,
    res,
    serviceIdentifier,
    submittedData,
    idempotencyKey,
    customerFiles
  );
});
apiRouter.get("/service-requests/my", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  if (!db.serviceRequests) db.serviceRequests = [];
  const list = db.serviceRequests.filter((r) => r.userId === user.id);
  res.json(list);
});
apiRouter.get("/service-requests/my/:ticketOrId", requireAuth, (req, res) => {
  const user = req.user;
  const db = getDb();
  if (!db.serviceRequests) db.serviceRequests = [];
  const item = db.serviceRequests.find(
    (r) => (r.id === req.params.ticketOrId || r.ticketId === req.params.ticketOrId) && r.userId === user.id
  );
  if (!item) {
    return res.status(404).json({ error: "Service request not found or access denied." });
  }
  res.json(item);
});
apiRouter.get("/admin/service-requests/stats", requireAdmin, (req, res) => {
  const db = getDb();
  const list = db.serviceRequests || [];
  const stats = {
    total: list.length,
    pending: list.filter((r) => r.status === "PENDING").length,
    processing: list.filter((r) => r.status === "PROCESSING").length,
    completed: list.filter((r) => r.status === "COMPLETED").length,
    rejected: list.filter((r) => r.status === "REJECTED").length,
    cancelled: list.filter((r) => r.status === "CANCELLED").length,
    requiresAction: list.filter((r) => r.status === "REQUIRES_ACTION").length
  };
  res.json(stats);
});
apiRouter.get("/admin/service-requests/customers", requireAdmin, (req, res) => {
  const db = getDb();
  const requests = db.serviceRequests || [];
  const customerMap = /* @__PURE__ */ new Map();
  for (const r of requests) {
    let entry = customerMap.get(r.userId);
    if (!entry) {
      const user = db.users.find((u) => u.id === r.userId);
      entry = {
        userId: r.userId,
        customerName: r.customerName || (user ? user.fullName : "Unknown Customer"),
        customerEmail: r.customerEmail || (user ? user.email : ""),
        customerPhone: r.customerPhone || (user ? user.phone || "" : ""),
        totalRequests: 0,
        pendingCount: 0,
        processingCount: 0,
        completedCount: 0,
        rejectedCount: 0,
        requiresActionCount: 0,
        lastSubmittedAt: r.createdAt
      };
      customerMap.set(r.userId, entry);
    }
    entry.totalRequests += 1;
    if (r.status === "PENDING") entry.pendingCount += 1;
    else if (r.status === "PROCESSING") entry.processingCount += 1;
    else if (r.status === "COMPLETED") entry.completedCount += 1;
    else if (r.status === "REJECTED") entry.rejectedCount += 1;
    else if (r.status === "REQUIRES_ACTION") entry.requiresActionCount += 1;
    if (new Date(r.createdAt) > new Date(entry.lastSubmittedAt)) {
      entry.lastSubmittedAt = r.createdAt;
    }
  }
  const result = Array.from(customerMap.values()).sort(
    (a, b) => new Date(b.lastSubmittedAt).getTime() - new Date(a.lastSubmittedAt).getTime()
  );
  res.json(result);
});
apiRouter.get("/admin/service-requests/customer/:userId", requireAdmin, (req, res) => {
  const db = getDb();
  const user = db.users.find((u) => u.id === req.params.userId);
  const requests = (db.serviceRequests || []).filter((r) => r.userId === req.params.userId);
  res.json({
    customer: user ? {
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      role: user.role,
      status: user.status,
      createdAt: user.createdAt
    } : {
      id: req.params.userId,
      fullName: requests[0]?.customerName || "Customer",
      email: requests[0]?.customerEmail || "",
      phone: requests[0]?.customerPhone || ""
    },
    requests
  });
});
apiRouter.get("/admin/service-requests/:id", requireAdmin, async (req, res) => {
  const db = getDb();
  if (!db.serviceRequests) db.serviceRequests = [];
  const request = db.serviceRequests.find((r) => r.id === req.params.id || r.ticketId === req.params.id);
  if (!request) {
    return res.status(404).json({ error: "Service request not found." });
  }
  if (request.status === "PENDING") {
    request.status = "PROCESSING";
    const now = (/* @__PURE__ */ new Date()).toISOString();
    request.openedAt = now;
    request.openedBy = req.user.fullName;
    request.processingTimestamp = now;
    request.processingStartedAt = now;
    request.updatedAt = now;
    if (!request.timeline) request.timeline = [];
    request.timeline.push({
      id: `tml_${Date.now()}_open`,
      status: "PROCESSING",
      title: "Admin Opened Request",
      description: `Request opened for processing by operations desk (${req.user.fullName}).`,
      actorName: req.user.fullName,
      actorRole: req.user.role,
      timestamp: now
    });
    if (db.verificationRequests) {
      const v = db.verificationRequests.find(
        (vr) => vr.ticketId === request.ticketId || vr.serviceRequestId === request.id || vr.reference === request.ticketId
      );
      if (v && v.status === "PENDING") {
        v.status = "PROCESSING";
        v.updatedAt = now;
      }
    }
    if (!db.notifications) db.notifications = [];
    db.notifications.unshift({
      id: `notif_${Date.now()}_proc`,
      userId: request.userId,
      title: "Service Request In Progress",
      message: `Your request for "${request.serviceName}" (${request.ticketId}) is now actively being processed by our operations desk.`,
      type: "SERVICE_REQUEST",
      isRead: false,
      link: "/my-service-requests",
      createdAt: now
    });
    logAudit(
      req.user.fullName,
      req.user.role,
      "SERVICE_REQUEST_OPENED",
      `Opened request ${request.ticketId} for processing`,
      request.userId,
      request.ticketId,
      req.ip
    );
    saveDb();
    await saveServiceRequestToSupabase(request);
  }
  res.json({ success: true, request });
});
apiRouter.post("/admin/service-requests/:id/result", requireAdmin, async (req, res) => {
  const db = getDb();
  if (!db.serviceRequests) db.serviceRequests = [];
  const request = db.serviceRequests.find((r) => r.id === req.params.id || r.ticketId === req.params.id);
  if (!request) {
    return res.status(404).json({ error: "Service request not found." });
  }
  const { finalStatus, adminResultText, adminResultFiles, adminNote } = req.body;
  const allowedStatuses = ["COMPLETED", "REJECTED", "FAILED", "CANCELLED", "REQUIRES_ACTION"];
  if (!finalStatus || !allowedStatuses.includes(finalStatus)) {
    return res.status(400).json({
      error: "A valid final status must be selected: Completed, Rejected, Failed, Cancelled, or Requires Customer Action."
    });
  }
  const validStatus = finalStatus;
  if (validStatus === "REJECTED") {
    const reason = req.body.rejectionReason || req.body.reason || adminNote || adminResultText;
    if (!reason || !String(reason).trim()) {
      return res.status(400).json({ error: "A rejection reason is required when rejecting a customer service request." });
    }
    request.rejectionReason = String(reason).trim();
  } else if (validStatus === "FAILED") {
    const reason = req.body.failureReason || req.body.reason || adminNote || adminResultText;
    if (!reason || !String(reason).trim()) {
      return res.status(400).json({ error: "A failure reason is required when marking a service request as failed." });
    }
    request.failureReason = String(reason).trim();
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  request.status = validStatus;
  request.adminResultText = adminResultText !== void 0 ? String(adminResultText).trim() : request.adminResultText;
  if (Array.isArray(adminResultFiles)) {
    request.adminResultFiles = adminResultFiles;
  }
  if (adminNote !== void 0) {
    request.adminNote = String(adminNote).trim();
  }
  request.completedAt = now;
  request.completedBy = req.user.fullName;
  request.completedByAdminId = req.user.id;
  request.updatedAt = now;
  if (db.verificationRequests) {
    const matchingReq = db.verificationRequests.find(
      (vr) => vr.ticketId === request.ticketId || vr.serviceRequestId === request.id || vr.reference === request.ticketId || vr.id === request.id
    );
    if (matchingReq) {
      matchingReq.status = validStatus === "COMPLETED" ? "COMPLETED" : validStatus === "REJECTED" ? "REJECTED" : "FAILED";
      matchingReq.updatedAt = now;
      matchingReq.result = {
        ...request.submittedData,
        adminResultText: request.adminResultText,
        adminResultFiles: request.adminResultFiles,
        completedAt: now,
        status: validStatus
      };
      matchingReq.resultData = matchingReq.result;
    }
  }
  if (validStatus === "COMPLETED") {
    if (!db.verificationResults) db.verificationResults = [];
    const existingVerif = db.verificationResults.find(
      (v) => v.reference === request.ticketId || v.requestId === request.id
    );
    if (existingVerif) {
      existingVerif.returnedData = {
        ...existingVerif.returnedData,
        ...request.submittedData,
        adminResultText: request.adminResultText,
        adminResultFiles: request.adminResultFiles,
        status: "COMPLETED"
      };
      existingVerif.verifiedAt = now;
      existingVerif.verifiedBy = req.user.fullName;
    } else {
      db.verificationResults.unshift({
        id: `vres_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        requestId: request.id,
        userId: request.userId,
        serviceCode: request.serviceCode,
        serviceName: request.serviceName,
        reference: request.ticketId,
        returnedData: {
          ...request.submittedData,
          adminResultText: request.adminResultText,
          adminResultFiles: request.adminResultFiles,
          completedAt: now,
          status: "COMPLETED"
        },
        providerName: "Admin Operations Desk",
        verifiedAt: now,
        verifiedBy: req.user.fullName
      });
    }
  }
  const isUnsuccessful = validStatus === "REJECTED" || validStatus === "FAILED" || validStatus === "CANCELLED";
  let refundProcessed = false;
  let refundedAmount = 0;
  if (isUnsuccessful && request.refundStatus !== "REFUNDED") {
    const originalPrice = request.price || 0;
    if (originalPrice > 0) {
      const wallet = db.wallets.find((w) => w.userId === request.userId);
      if (wallet) {
        const balanceBefore = wallet.availableBalance;
        wallet.availableBalance += originalPrice;
        wallet.totalSpent = Math.max(0, wallet.totalSpent - originalPrice);
        wallet.updatedAt = now;
        const refundTxn = {
          id: `txn_${Date.now()}_ref_${Math.random().toString(36).substring(2, 6)}`,
          walletId: wallet.id,
          userId: request.userId,
          reference: `REF-${request.ticketId}`,
          type: "REFUND",
          amount: originalPrice,
          fee: 0,
          balanceBefore,
          balanceAfter: wallet.availableBalance,
          status: "SUCCESS",
          description: `Automatic Refund: ${request.serviceName} marked ${validStatus} (${request.ticketId})`,
          metadata: {
            ticketId: request.ticketId,
            serviceCode: request.serviceCode,
            serviceName: request.serviceName,
            serviceCategory: "non_verification",
            serviceType: "non_verification",
            originalPrice,
            originalUnitCost: originalPrice,
            refundAmount: originalPrice,
            finalServiceStatus: validStatus,
            debitSummary: `Non-verification service marked ${validStatus} \u2014 refund issued`,
            processedBy: req.user.fullName,
            processedById: req.user.id,
            reason: adminNote || adminResultText || `Marked as ${validStatus}`
          },
          createdAt: now
        };
        db.transactions.unshift(refundTxn);
        request.refundStatus = "REFUNDED";
        request.refundAmount = originalPrice;
        request.refundedAt = now;
        request.refundedBy = req.user.fullName;
        refundProcessed = true;
        refundedAmount = originalPrice;
        if (db.verificationRequests) {
          const matchingReq = db.verificationRequests.find(
            (vr) => vr.ticketId === request.ticketId || vr.serviceRequestId === request.id || vr.reference === request.ticketId || vr.id === request.id
          );
          if (matchingReq) {
            matchingReq.refundStatus = "REFUNDED";
            matchingReq.refundAmount = originalPrice;
            matchingReq.refundedAt = now;
            matchingReq.refundedBy = req.user.fullName;
          }
        }
        await saveWalletToSupabase(wallet);
      }
    }
  }
  if (!request.timeline) request.timeline = [];
  const statusDisplayMap = {
    PENDING: "Pending",
    PROCESSING: "Processing",
    COMPLETED: "Completed & Delivered",
    REJECTED: "Application Rejected",
    FAILED: "Processing Failed",
    CANCELLED: "Request Cancelled",
    REQUIRES_ACTION: "Customer Action Required"
  };
  const statusLabel = statusDisplayMap[validStatus] || validStatus;
  request.timeline.push({
    id: `tml_${Date.now()}_result`,
    status: validStatus,
    title: `Result Dispatched: ${statusLabel}`,
    description: adminResultText || `Result dispatched to customer with status: ${statusLabel}`,
    actorName: req.user.fullName,
    actorRole: req.user.role,
    timestamp: now
  });
  if (refundProcessed) {
    request.timeline.push({
      id: `tml_${Date.now()}_refund`,
      status: "REFUNDED",
      title: "Automatic Wallet Refund Executed",
      description: `Exact fee of \u20A6${refundedAmount.toLocaleString()} was credited back to customer wallet because request was marked ${statusLabel}.`,
      actorName: req.user.fullName,
      actorRole: "OPERATIONS_DESK",
      timestamp: now
    });
  }
  if (!db.notifications) db.notifications = [];
  db.notifications.unshift({
    id: `notif_${Date.now()}_final`,
    userId: request.userId,
    title: refundProcessed ? `Service Request ${statusLabel} (Refunded)` : `Service Request ${statusLabel}`,
    message: refundProcessed ? `Your request for "${request.serviceName}" (${request.ticketId}) was marked as "${statusLabel}". Exactly \u20A6${refundedAmount.toLocaleString()} has been automatically refunded to your wallet.` : `Your request for "${request.serviceName}" (${request.ticketId}) has been updated to "${statusLabel}". View result and download files.`,
    type: "SERVICE_REQUEST",
    isRead: false,
    link: "/my-service-requests",
    createdAt: now
  });
  logAudit(
    req.user.fullName,
    req.user.role,
    "SERVICE_REQUEST_RESULT_SENT",
    `Sent result for ${request.ticketId}. Status: ${finalStatus}. Staff: ${req.user.fullName}`,
    request.userId,
    request.ticketId,
    req.ip
  );
  saveDb();
  await saveServiceRequestToSupabase(request);
  res.json({ success: true, request });
});
apiRouter.get("/admin/service-requests", requireAdmin, (req, res) => {
  const db = getDb();
  let list = db.serviceRequests || [];
  const { search, status, sort } = req.query;
  if (search && typeof search === "string") {
    const q = search.toLowerCase().trim();
    list = list.filter(
      (r) => r.ticketId.toLowerCase().includes(q) || r.customerName.toLowerCase().includes(q) || r.customerEmail.toLowerCase().includes(q) || r.customerPhone && r.customerPhone.toLowerCase().includes(q) || r.serviceName.toLowerCase().includes(q)
    );
  }
  if (status && typeof status === "string" && status !== "ALL") {
    list = list.filter((r) => r.status === status);
  }
  if (sort === "OLDEST") {
    list = [...list].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  } else if (sort === "RECENT_UPDATED") {
    list = [...list].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  } else {
    list = [...list].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  res.json(list);
});
var templateProxyMemoryCache = /* @__PURE__ */ new Map();
var LOCAL_TEMPLATE_URL_MAP = {
  "https://i.ibb.co/XZpC5fTL/20260921-214903.jpg": import_path2.default.resolve(process.cwd(), "public/templates/nin_premium.jpg"),
  "https://i.ibb.co/BFHms81/20260921-223018.jpg": import_path2.default.resolve(process.cwd(), "public/templates/nin_standard.jpg"),
  "https://i.ibb.co/5hWsw4yg/20260921-223813.jpg": import_path2.default.resolve(process.cwd(), "public/templates/nin_regular.jpg"),
  "https://i.ibb.co/Zp1bjKLd/20260921-222422.jpg": import_path2.default.resolve(process.cwd(), "public/templates/bvn_premium.jpg")
};
apiRouter.get("/slip-template-proxy", async (req, res) => {
  const imageUrl = req.query.url;
  if (!imageUrl) {
    return res.status(400).json({ error: "Valid URL is required" });
  }
  const cached = templateProxyMemoryCache.get(imageUrl);
  if (cached && Date.now() < cached.expires) {
    res.setHeader("Content-Type", cached.contentType);
    res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    res.setHeader("Access-Control-Allow-Origin", "*");
    return res.send(cached.buffer);
  }
  const localFilePath = LOCAL_TEMPLATE_URL_MAP[imageUrl];
  if (localFilePath && import_fs2.default.existsSync(localFilePath)) {
    try {
      const fileBuffer = await import_fs2.default.promises.readFile(localFilePath);
      templateProxyMemoryCache.set(imageUrl, {
        buffer: fileBuffer,
        contentType: "image/jpeg",
        expires: Date.now() + 864e5 * 7
      });
      res.setHeader("Content-Type", "image/jpeg");
      res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
      res.setHeader("Access-Control-Allow-Origin", "*");
      return res.send(fileBuffer);
    } catch {
    }
  }
  if (imageUrl.startsWith("/templates/") || imageUrl.startsWith("templates/")) {
    const cleanPath = imageUrl.startsWith("/") ? imageUrl.slice(1) : imageUrl;
    const resolvedPath = import_path2.default.resolve(process.cwd(), "public", cleanPath);
    if (import_fs2.default.existsSync(resolvedPath)) {
      try {
        const fileBuffer = await import_fs2.default.promises.readFile(resolvedPath);
        templateProxyMemoryCache.set(imageUrl, {
          buffer: fileBuffer,
          contentType: "image/jpeg",
          expires: Date.now() + 864e5 * 7
        });
        res.setHeader("Content-Type", "image/jpeg");
        res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        res.setHeader("Access-Control-Allow-Origin", "*");
        return res.send(fileBuffer);
      } catch {
      }
    }
  }
  if (!imageUrl.startsWith("http")) {
    return res.status(400).json({ error: "Valid HTTP/HTTPS URL is required" });
  }
  try {
    const upstreamRes = await fetch(imageUrl, {
      signal: AbortSignal.timeout(5e3),
      keepalive: true
    });
    if (!upstreamRes.ok) {
      return res.status(upstreamRes.status).send("Failed to fetch template image");
    }
    const contentType = upstreamRes.headers.get("content-type") || "image/jpeg";
    const arrayBuf = await upstreamRes.arrayBuffer();
    const buffer = Buffer.from(arrayBuf);
    templateProxyMemoryCache.set(imageUrl, {
      buffer,
      contentType,
      expires: Date.now() + 864e5
    });
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: "Failed to proxy template image" });
  }
});
apiRouter.use((err, req, res, next) => {
  if (err.type === "entity.too.large" || err.status === 413 || err.statusCode === 413 || err.name === "PayloadTooLargeError") {
    return res.status(413).json({
      error: "Payload Too Large: The uploaded files exceed the server limit. Please upload compressed or smaller files."
    });
  }
  next(err);
});

// server.ts
init_db();
async function startServer() {
  initDb();
  const app = (0, import_express2.default)();
  const PORT = 3e3;
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });
  app.use(import_express2.default.json({
    limit: "100mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    }
  }));
  app.use(import_express2.default.urlencoded({ limit: "100mb", extended: true }));
  const uploadsDir = import_path3.default.join(process.cwd(), "data", "uploads");
  if (!import_fs3.default.existsSync(uploadsDir)) {
    import_fs3.default.mkdirSync(uploadsDir, { recursive: true });
  }
  const avatarsDir = import_path3.default.join(uploadsDir, "avatars");
  if (!import_fs3.default.existsSync(avatarsDir)) {
    import_fs3.default.mkdirSync(avatarsDir, { recursive: true });
  }
  const docsDir = import_path3.default.join(uploadsDir, "documents");
  if (!import_fs3.default.existsSync(docsDir)) {
    import_fs3.default.mkdirSync(docsDir, { recursive: true });
  }
  app.use("/uploads", import_express2.default.static(uploadsDir));
  app.use("/api", apiRouter);
  app.use((err, req, res, next) => {
    if (err.type === "entity.too.large" || err.status === 413 || err.statusCode === 413 || err.name === "PayloadTooLargeError") {
      return res.status(413).json({
        error: "Payload Too Large: The uploaded files or request data exceed the maximum size. Please upload compressed or smaller files."
      });
    }
    next(err);
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path3.default.join(process.cwd(), "dist");
    app.use(import_express2.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path3.default.join(distPath, "index.html"));
    });
  }
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`UGOPAWAVERIFY server listening on http://0.0.0.0:${PORT}`);
  });
  server.requestTimeout = 15e4;
  server.headersTimeout = 155e3;
  server.keepAliveTimeout = 15e4;
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
